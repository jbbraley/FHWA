function CloseAndUnloadSt7API
try
    unloadlibrary('St7API');
catch
end


end