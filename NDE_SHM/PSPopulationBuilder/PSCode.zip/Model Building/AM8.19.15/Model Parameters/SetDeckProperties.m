function Parameters = SetDeckProperties(uID, Parameters)
global ptPLATEPROP
%% Check if deck is being updated
% Find Property index
ind = find(strncmp({Parameters.St7Prop.propName},'Deck',4));

% Get fc 
if isfield(Parameters.St7Prop(ind), 'update') && Parameters.St7Prop(ind).update
    switch Parameters.St7Prop(ind).AlphaScale
        case 'lin'
            fc = Parameters.Deck.fc * ...
                 Parameters.St7Prop(ind).Alphas(1);
        case 'log'
            fc = Parameters.Deck.fc * ...
                 10^Parameters.St7Prop(ind).Alphas(1);
    end
else
    fc = Parameters.Deck.fc;
end

% convert fc to E
Parameters.St7Prop(ind).MatData(1) = 57000*sqrt(fc);

%% Set Deck Properties
iErr = calllib('St7API', 'St7SetPlateIsotropicMaterial', uID, Parameters.St7Prop(ind).St7PropNum, Parameters.St7Prop(ind).MatData);
HandleError(iErr);
iErr = calllib('St7API','St7SetPlateThickness',uID, Parameters.St7Prop(ind).St7PropNum, [Parameters.Deck.t, Parameters.Deck.t]);
HandleError(iErr);
iErr = calllib('St7API', 'St7SetMaterialName', uID, ptPLATEPROP, Parameters.St7Prop(ind).St7PropNum, Parameters.St7Prop(ind).MatName);
HandleError(iErr);

end