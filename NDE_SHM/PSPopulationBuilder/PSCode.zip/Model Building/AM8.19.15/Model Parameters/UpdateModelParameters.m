function Parameters = UpdateModelParameters(uID, Parameters, Node)
%% Call GetBeamSection.m
if any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'Beam', 4)).update}))
    try
        SetBeamSection(uID, Parameters);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call GetDiaSection.m
if any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'Dia', 3)).update}))
    try
        SetDiaSection(uID, Parameters);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call DeckStiffness.m
if any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'Deck', 4)).update}))
    try
        Parameters = SetDeckProperties(uID, Parameters);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call SetNonstructuralMassProperties.m
if any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'Barrier', 7)).update})) || ...
   any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'Sidewalk', 8)).update}))
    try
        Parameters = SetNonstructuralMassProperties(uID, Parameters);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call BoundaryConditions.m
if any(Parameters.Bearing.Fixed.Update) || any(Parameters.Bearing.Expansion.Update)
    try
        FCaseNum = 1;
        BoundaryConditions(uID, Node, Parameters, FCaseNum);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call SetCompositeAction.m
if any(cell2mat({Parameters.St7Prop(strncmp({Parameters.St7Prop.fieldName}, 'compAction', 10)).update}))
    try
        SetCompositeAction(uID, Parameters);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end


%% Call UpdateModelDimension.m
% if Parameters.Updating.ModelDimUpdate
%     try
%         UpdateModelDimension(uID,NodeID,Node);
%     catch
%         CloseAndUnload(uID);
%         rethrow(lasterror);
%     end
% end
end %UpdateModelParameters