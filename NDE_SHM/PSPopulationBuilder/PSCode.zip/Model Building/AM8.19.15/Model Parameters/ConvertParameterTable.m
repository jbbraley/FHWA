function varargout = ConvertParameterTable(varargin)
%% Converts Parameters Structure to paraData or reverse
% Converts A to B format and updaates B format.
% B = ConvertParameterTable(A,B);
% Varargin -
% when inputname(1) = Parameters, converts to paraData
% when inputname(2) = paraData, converts to Parameters
% Varargout -
% inputname (2)

%% Convert
switch inputname(1)
    case 'paraData'
        paraData = varargin{1};
        Parameters = varargin{2};
        
        for i = 1:size(paraData,1)
            Parameters.St7Prop(i).St7PropNum = paraData{i,2};
            Parameters.St7Prop(i).UpdateGroup = paraData{i,4};
            Parameters.St7Prop(i).update = paraData{i,7};
            Parameters.St7Prop(i).Alphas = cell2mat(paraData(i,8:10));
            Parameters.St7Prop(i).AlphaScale = paraData{i,11};
            
            if ~isempty(Parameters.St7Prop(i).fieldName)
                fieldStops = strfind(Parameters.St7Prop(i).fieldName,'.');
                fieldStops(end+1:end+2) = [0, length(Parameters.St7Prop(i).fieldName)+1];
                fieldStops = sort(fieldStops);
                
                clear subField;
                subField{1} = Parameters;
                for j = 1 : length(fieldStops)-1
                    fieldName = Parameters.St7Prop(i).fieldName(fieldStops(j)+1:fieldStops(j+1)-1);
                    subField{j+1} = subField{j}.(fieldName);
                end
                
                subField{end}.(Parameters.St7Prop(i).updateType) = paraData{i,5};
                
                for j = length(subField)-1:-1:1
                    fieldName = Parameters.St7Prop(i).fieldName(fieldStops(j)+1:fieldStops(j+1)-1);
                    subField{j}.(fieldName) = subField{j+1};
                end
                
                Parameters=subField{1};
            end
        end
        
        varargout = {Parameters};
        
    case 'Parameters'
        Parameters = varargin{1};
        paraData = varargin{2};
        
        % Parameter data - can leave these as is
        paraData(:,1) = {Parameters.St7Prop.propName}';
        paraData(:,end+1) = {Parameters.St7Prop.St7PropNum}';
        paraData(:,end+1) = {Parameters.St7Prop.propType}';
        paraData(:,end+1) = {Parameters.St7Prop.UpdateGroup}';
        paraData(:,end+3) = num2cell(logical(cell2mat({Parameters.St7Prop.update})'));
        paraData(:,end+1:end+3) = num2cell(cell2mat({Parameters.St7Prop.Alphas}'));        
        paraData(:,end+1) = {Parameters.St7Prop.AlphaScale}';

        % parameter values
        for i = 1:length(Parameters.St7Prop)
            if ~isempty(Parameters.St7Prop(i).fieldName)
                fieldStops = strfind(Parameters.St7Prop(i).fieldName,'.');
                fieldStops(end+1:end+2) = [0, length(Parameters.St7Prop(i).fieldName)+1];
                fieldStops = sort(fieldStops);
                
                subField = Parameters;
                for j = 1 : length(fieldStops)-1
                    subField = subField.(Parameters.St7Prop(i).fieldName(fieldStops(j)+1:fieldStops(j+1)-1));
                end
            end
            paraData{i,5} = subField.(Parameters.St7Prop(i).updateType);
            paraData{i,6} = Parameters.St7Prop(i).updateType;
        end
        
        % min/max conversion
        logRows = strcmp(paraData(:,11), 'log');
        paraData(~logRows,end+1:end+2) = num2cell(repmat(cell2mat(paraData(~logRows,5)),1,2).*cell2mat(paraData(~logRows,end-2:end-1)));
        paraData(logRows,end-1:end) = num2cell(repmat(cell2mat(paraData(logRows,5)),1,2).*10.^cell2mat(paraData(logRows,end-4:end-3)));
        
        varargout = {paraData};
end