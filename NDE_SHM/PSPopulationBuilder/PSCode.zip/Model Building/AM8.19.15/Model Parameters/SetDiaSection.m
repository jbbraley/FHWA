function SetDiaSection(uID, Parameters)
global kSquareSolid ptBEAMPROP

%% Check if beam is being updated
% Find Property index
IND = find(strncmp({Parameters.St7Prop.fieldName},'Dia',3));
for j = 1:length(IND)
    ind = IND(j);
    % Get fc
    if Parameters.St7Prop(ind).update
        switch Parameters.St7Prop(ind).AlphaScale
            case 'lin'
                E = Parameters.Dia.E * ...
                    Parameters.St7Prop(ind).Alphas(1);
            case 'log'
                E = Parameters.Dia.E * ...
                    10^Parameters.St7Prop(ind).Alphas(1);
        end
    else
        E = Parameters.Dia.E;
    end
    
    % convert fc to E
    Parameters.St7Prop(ind).MatData(1) = E;
    
    % if strcmp(Parameters.Dia.Type,'Concrete')
    %     Doubles = [E 1659.52 0.2 149.827/(12^3) 5.55556*10^(-6) 0 0 0.210184 0.000219881];
    % else
    %     Doubles = [E 16030 0.25 490.061/(12^3) 6.5*10^(-6) 0 0 0.0086664 0.1111];
    % end
    
    %% Diaphragm Section Property Assignment
    for ii = 1:length(ind)
        % Set Material Data
        iErr = calllib('St7API', 'St7SetBeamMaterialData', uID, Parameters.St7Prop(ind).St7PropNum, Parameters.St7Prop(ind).MatData);
        HandleError(iErr);
        iErr = calllib('St7API', 'St7SetMaterialName', uID, ptBEAMPROP, Parameters.St7Prop(ind).St7PropNum, Parameters.St7Prop(ind).MatName);
        HandleError(iErr);
        
        switch Parameters.Dia.Type
            case 'Beam'
                SetSectionGeometry(uID, Parameters, Parameters.Dia, ind)
            case {'Cross', 'Chevron'}
                SetSectionGeometry(uID, Parameters, Parameters.Dia, ind)
            case 'Concrete'
                % Assign Section Geometry
                iErr = calllib('St7API', 'St7SetBeamSectionGeometry', uID, Parameters.St7Prop(ind).St7PropNum,...
                    kSquareSolid, Parameters.Dia.Section);
                HandleError(iErr);
                iErr  = calllib('St7API', 'St7CalculateBeamSectionProperties', uID, Parameters.St7Prop(ind).St7PropNum, 1, 1);
                HandleError(iErr);
                
                iErr  = calllib('St7API', 'St7SetBeamSectionName', uID, Parameters.St7Prop(ind).St7PropNum, Parameters.Dia.SectionName);
                HandleError(iErr)
                
        end
    end
end
end

function SetSectionGeometry(uID, Parameters, Dia, ind)
global kLipChannel kLSection

switch Dia.Type
    case 'Beam'
        sectionType = 'kLipChannel';
        
        % Set Section Geometry
        Slices = 1;
        ipArea = Dia.A;
        
        ipYBAR = Dia.d/2;
        ipXBAR = (2*Dia.bf^2*Dia.tf + (Dia.d-2*Dia.tf)*Dia.tw^2) / ...
                 (2*Dia.bf*Dia.d - 2*(Dia.d-2*Dia.tf)*(Dia.bf- Dia.tw));
        
        ipI22 = (Dia.bf*Dia.d^3 - (Dia.d-2*Dia.tf)^3*(Dia.bf-Dia.tw))/12;
        ipI11 = (2*Dia.tf*Dia.bf^3 + (Dia.d-2*Dia.tf)*Dia.tw^3)/3 - Dia.A*ipXBAR^2 ;
        
        ipJ =  Dia.tw^3*Dia.ind/3 + 2*Dia.bf*Dia.tf^3/3;
        ipSL2 = Dia.d/2;
        ipSL1 = -Dia.A/4;
   
        ipSA2 = 5/6*(2*Dia.bf*Dia.tf);
        ipSA1 = Dia.d*Dia.tw;
        
        % axis angle
        ipANGLE = pi/2;
    case {'Cross', 'Chevron'}
        sectionType = 'kLSection';
        
        % Set Section Geometry
        Slices = 1;
        ipArea = Dia.A;
        
        ipYBAR = (Dia.t*(2*(Dia.d-Dia.t)+Dia.B) + (Dia.d-Dia.t)^2) / ...
                 (2*((Dia.d-Dia.t) + Dia.B));
        ipXBAR = (Dia.t*(2*(Dia.B-Dia.t)+Dia.d) + (Dia.B-Dia.t)^2) / ...
                 (2*((Dia.B-Dia.t) + Dia.d));
        
        ipI22 = (1/3)*((Dia.t*(Dia.d-ipYBAR)^3 + Dia.B*ipYBAR^3) - ...
                        (Dia.B-Dia.t)*(ipYBAR-Dia.t)^3);
        ipI11 = (1/3)*((Dia.t*(Dia.B-ipXBAR)^3 + Dia.d*ipXBAR^3) - ...
                        (Dia.d-Dia.t)*(ipXBAR-Dia.t)^3);
        
        ipJ =  Dia.t^3*Dia.B/3 + Dia.t^3*(Dia.d-Dia.t)/3;
        ipSL2 = Dia.t/2;
        ipSL1 = Dia.t/2;
   
        ipSA2 = 2/3*Dia.d*Dia.t;
        ipSA1 = 2/3*Dia.B*Dia.t;
        
        % axis angle
        ipANGLE = 0;
end

Doubles = [ipArea, ipI11, ipI22, ipJ, ipSL1, ipSL2, ipSA1, ipSA2, ipXBAR,ipYBAR, ipANGLE]; 

iErr = calllib('St7API', 'St7SetBeamSectionGeometry', uID, Parameters.St7Prop(ind).St7PropNum, eval(sectionType), Dia.Section);
HandleError(iErr);
iErr = calllib('St7API', 'St7SetBeamSectionPropertyData', uID,Parameters.St7Prop(ind).St7PropNum, Slices, Doubles);
HandleError(iErr);
iErr  = calllib('St7API', 'St7SetBeamSectionName', uID, Parameters.St7Prop(ind).St7PropNum, Parameters.Dia.SectionName);
HandleError(iErr);

end %SetSectionGeo