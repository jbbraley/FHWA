% (10/19/14) NPR: Changed line 22 to fix error with scalar values.

function [Node, Parameters] = ModelGeneration(uID, Options, Parameters, Node)
%% Assign properties
% Assigns properties to beams, barrier, and deck
Parameters = InitializeSt7Properties(Options.St7.uID, Parameters);

%% Call GetBeamSection.m
try
    SetBeamSection(uID, Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

%% Call GetBeamSection.m
try
    SetDeckProperties(uID, Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

%% Set non-structural mass 
try
    Parameters = SetNonstructuralMassProperties(uID,Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end
        
%% Call GetDiaSection.m
try
    SetDiaSection(uID, Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

%% Call SetCompositeAction.m
try
    SetCompositeAction(uID, Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

%% Call BuildModel.m
try
    [Parameters, Node] = BuildModel(uID, Options, Parameters);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

%% Set wearing surface
if Parameters.Deck.WearingSurface > 0
    try
        DLCase = 2; % Hard coded until future developments
        AddOverlay(uID, Node, Parameters, DLCase);
    catch
        CloseAndUnload(uID);
        rethrow(lasterror);
    end
end

%% Call BoundaryConditions.m
try
    FCaseNum = 1;
    BoundaryConditions(uID, Node, Parameters, FCaseNum);
catch
    CloseAndUnload(uID);
    rethrow(lasterror);
end

end %ModelGeneration