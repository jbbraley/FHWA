function Parameters = SetNonstructuralMassProperties(uID, Parameters)
%% Check if barrier is being updated
% Find Property index
indBarrier = find(strncmp({Parameters.St7Prop.fieldName},'Barrier',7));

% Get fc 
if Parameters.St7Prop(indBarrier).update
    switch Parameters.St7Prop(indBarrier).AlphaScale
        case 'lin'
            fc = Parameters.Barrier.fc * ...
                 Parameters.St7Prop(indBarrier).Alphas(1);
        case 'log'
            fc = Parameters.Barrier.fc * ...
                 10^Parameters.St7Prop(indBarrier).Alphas(1);
    end
else
    fc = Parameters.Barrier.fc;
end

% convert fc to E
Parameters.St7Prop(indBarrier).MatData(1) = 57000*sqrt(fc);

%% Check if sidewalk is being updated
% Find Property index
indSW = find(strncmp({Parameters.St7Prop.fieldName},'Sidewalk',8));

% Get fc 
if Parameters.St7Prop(indSW).update
    switch Parameters.St7Prop(indSW).AlphaScale
        case 'lin'
            fc = Parameters.Sidewalk.fc * ...
                 Parameters.St7Prop(indSW).Alphas(1);
        case 'log'
            fc = Parameters.Sidewalk.fc * ...
                 10^Parameters.St7Prop(indSW).Alphas(1);
    end
else
    fc = Parameters.Sidewalk.fc;
end

% convert fc to E
Parameters.St7Prop(indSW).MatData(1) = 57000*sqrt(fc);

%% Barrier Section Property Assignment

global kSquareSolid ptPLATEPROP
side = {'Right';'Left'}; % Always right first, left second

for ii = 1:length(side)
    % BarrierSection Property Assignment
    if Parameters.Sidewalk.(side{ii}) > 0
        BarrierDim = [Parameters.Barrier.Width, Parameters.Barrier.Height, 0, 0, 0];
    else
        BarrierDim = [Parameters.Barrier.Width, Parameters.Barrier.Height+Parameters.Sidewalk.Height, 0, 0, 0];
    end

    % Assign
    iErr = calllib('St7API', 'St7SetBeamSectionGeometry', uID, Parameters.St7Prop(indBarrier).St7PropNum, kSquareSolid, BarrierDim);
    HandleError(iErr);
    iErr = calllib('St7API', 'St7SetBeamMaterialData', uID, Parameters.St7Prop(indBarrier).St7PropNum, Parameters.St7Prop(indBarrier).MatData);
    HandleError(iErr);

    Slices = 1;
    ipArea = BarrierDim(2)*Parameters.Barrier.Width;
    ipI11 = BarrierDim(2)^3*Parameters.Barrier.Width/12;
    ipI22 = BarrierDim(2)*Parameters.Barrier.Width^3/12;
    % approximate torionsal constant
    ipJ = BarrierDim(2)*Parameters.Barrier.Width^3*(1/3 - 0.21*Parameters.Barrier.Width/BarrierDim(2)*(1-Parameters.Barrier.Width^4/(12*BarrierDim(2)^4)));
    ipSL1 = 0;
    ipSL2 = 0;
    ipSA1 = 5/6*(BarrierDim(2)*Parameters.Barrier.Width);
    ipSA2 = 5/6*(BarrierDim(2)*Parameters.Barrier.Width);
    switch side{ii}
        case 'Right'
            xBARmulti = 1;
        case 'Left'
            xBARmulti = 0;
    end
    ipXBAR = Parameters.Barrier.Width*xBARmulti;
    ipYBAR =  BarrierDim(2)/2; 
    ipANGLE = pi/2;
    Doubles = [ipArea, ipI11, ipI22, ipJ, ipSL1, ipSL2, ipSA1, ipSA2, ipXBAR,ipYBAR, ipANGLE];
    Doubles(isnan(Doubles)) = 0;

    iErr = calllib('St7API', 'St7SetBeamSectionPropertyData', uID, Parameters.St7Prop(indBarrier).St7PropNum, Slices, Doubles);
    HandleError(iErr);
end

%% Sidewalk Section Property Assignment
if Parameters.Sidewalk.Right ~= 0 || Parameters.Sidewalk.Left ~= 0
    for ii = 1:length(side)
        % Find Property index
        iErr = calllib('St7API', 'St7SetPlateIsotropicMaterial', uID, Parameters.St7Prop(indSW).St7PropNum, Parameters.St7Prop(indSW).MatData);
        HandleError(iErr);
        iErr = calllib('St7API','St7SetPlateThickness',uID, Parameters.St7Prop(indSW).St7PropNum, [Parameters.Sidewalk.Height, Parameters.Sidewalk.Height]);
        HandleError(iErr);
        iErr = calllib('St7API', 'St7SetMaterialName', uID, ptPLATEPROP, Parameters.St7Prop(indSW).St7PropNum, Parameters.St7Prop(indSW).MatName);
        HandleError(iErr);
    end
end
end % SetNonstructuralMass()