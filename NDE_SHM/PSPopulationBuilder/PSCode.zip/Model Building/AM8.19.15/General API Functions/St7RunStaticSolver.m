function St7RunStaticSolver(uID, resultPath)
global stLinearStaticSolver smBackgroundRun

iErr = calllib('St7API', 'St7SetResultFileName', uID, resultPath);
HandleError(iErr);
iErr = calllib('St7API', 'St7RunSolver', uID, stLinearStaticSolver, smBackgroundRun, 1);
HandleError(iErr);

end % CreateLoadCase()