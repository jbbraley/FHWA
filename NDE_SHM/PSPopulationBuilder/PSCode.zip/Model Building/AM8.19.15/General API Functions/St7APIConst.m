function St7APIConst()

% ST7APICONST: ST7API.DLL constants.
%
% Constants are loaded as MATLAB global variables.

global kMaxStrLen
global kMaxEntityTotals
global kMaxElementNode
global kMaxBeamResult
global kNumBeamSectionData
global kNumMaterialData
global kMaxAttributeDoubles
global kMaxAttributeLogicals
global kMaxAttributeLongint
global kLastUnit
global ipLENGTHU
global ipFORCEU
global ipSTRESSU
global ipMASSU
global ipTEMPERU
global ipENERGYU
global luMETRE
global luCENTIMETRE
global luMILLIMETRE
global luFOOT
global luINCH
global fuNEWTON
global fuKILONEWTON
global fuMEGANEWTON
global fuKILOFORCE
global fuPOUNDFORCE
global fuTONNEFORCE
global fuKIPFORCE
global suPASCAL
global suKILOPASCAL
global suMEGAPASCAL
global suKSCm
global suPSI
global suKSI
global suPSF
global muKILOGRAM
global muTONNE
global muGRAM
global muPOUND
global muSLUG
global tuCELSIUS
global tuFAHRENHEIT
global tuKELVIN
global euJOULE
global euBTU
global euFTLBF
global euCALORIE
global tuMilliSec
global tuSec
global tuMin
global tuHour
global tuDay
global tyNULL
global tyNODE
global tyBEAM
global tyPLATE
global tyBRICK
global tyLINK
global tyVERTEX
global tyGEOMETRYEDGE
global tyGEOMETRYFACE
global tyLOADPATH
global ilMasterSlaveLink
global ilSectorSymmetryLink
global ilCouplingLink
global ilPinnedLink
global ilRigidLink
global ilShrinkLink
global ilTwoPointLink
global ilAttachmentLink
global ilMultiPointLink
global msFree
global msFix
global msFixNegate
global cpTranslational
global cpRotational
global cpBoth
global rgPlaneXYZ
global rgPlaneXY
global rgPlaneYZ
global rgPlaneZX
global ipTwoPointDOF1
global ipTwoPointDOF2
global ipTwoPointUCS1
global ipTwoPointUCS2
global ipTwoPointC0
global ipTwoPointC1
global ipTwoPointC2
global ipAttachmentElType
global ipAttachmentElNum
global ipAttachmentBrickFaceNum
global ipAttachmentCouple
global mpInterpolatedFactors
global mpUserFactors
global tReferenceTemperature
global tFixedTemperature
global tInitialTemperature
global tTableTemperature
global kBeamEndRelReleased
global kBeamEndRelFixed
global kBeamEndRelPartial
global ptBEAMPROP
global ptPLATEPROP
global ptBRICKPROP
global ptPLYPROP
global ipBeamPropTotal
global ipPlatePropTotal
global ipBrickPropTotal
global ipPlyPropTotal
global kIntegratedAlpha
global kInstantAlpha
global AtCentroid
global AtGaussPoints
global AtNodesAverageNever
global AtNodesAverageAll
global AtNodesAverageSame
global kBeamTypeNull
global kBeamTypeSpring
global kBeamTypeCable
global kBeamTypeTruss
global kBeamTypeCutoff
global kBeamTypeContact
global kBeamTypeBeam
global kBeamTypeUser
global kBeamTypePipe
global kBeamTypeConnection
global kZeroGapContact
global kNormalContact
global kTensionContact
global kTakeupContact
global kTensionTakeup
global kCompressionTakeup
global kBrittleGap
global kDuctileGap
global ipContactType
global ipDynamicStiffness
global ipUseInFirstIteration
global ipUpdateDirection
global ipContactSubType
global ipFrictionYieldType
global ipFrictionModel
global ipContactStiffness
global ipFrictionC1
global ipFrictionC2
global ipContactMaxTension
global ipCutoffType
global ipKeepMass
global lbMaterial
global lbBeamSection
global lbComposite
global lbReinforcementLayout
global lbCreepDefinition
global lbLoadPathTemplate
global kNullSection
global kCircularSolid
global kCircularHollow
global kSquareSolid
global kSquareHollow
global kLipChannel
global kTopHatChannel
global kISection
global kTSection
global kLSection
global kZSection
global kUserSection
global kTrapezoidSolid
global kTrapezoidHollow
global kTriangleSolid
global kTriangleHollow
global kCruciform
global kMirrorNone
global kMirrorTop
global kMirrorBot
global kMirrorLeft
global kMirrorRight
global kMirrorLeftAndTop
global kMirrorLeftAndBot
global kMirrorRightAndTop
global kMirrorRightAndBot
global kMirrorLeftTopOnly
global kMirrorLeftBotOnly
global kMirrorRightTopOnly
global kMirrorRightBotOnly
global ipAREA
global ipI11
global ipI22
global ipJ
global ipSL1
global ipSL2
global ipSA1
global ipSA2
global ipXBAR
global ipYBAR
global ipANGLE
global ipD1
global ipD2
global ipD3
global ipT1
global ipT2
global ipT3
global ipGapA
global ipGapB
global kMaxDLPerBeam
global kConstantDL
global kLinearDL
global kTriangularDL
global kThreePoint0DL
global kThreePoint1DL
global kTrapezoidalDL
global ptAuto4
global ptAuto3
global ptAuto2
global ptAuto1
global ptAngleSplit
global ptManual
global kPlateTypeNull
global kPlateTypePlaneStress
global kPlateTypePlaneStrain
global kPlateTypeAxisymmetric
global kPlateTypePlateShell
global kPlateTypeShearPanel
global kPlateTypeMembrane
global kPlateTypeLoadPatch
global suPlane
global suSphere
global suTorus
global suCone
global suBSpline
global suRotSur
global suPipeSur
global suSumSur
global suTabCyl
global suRuleSur
global suCubicSpline
global ipTHICKM
global ipTHICKB
global kMaterialTypeNull
global kMaterialTypeIsotropic
global kMaterialTypeOrthotropic
global kMaterialTypeAnisotropic
global kMaterialTypeRubber
global kMaterialTypeSoil
global kMaterialTypeLaminate
global kMaterialTypeUserDefined
global kMaterialTypePly
global kMaterialTypeFluid
global ycTresca
global ycVonMises
global ycMaxStress
global ycMohrCoulomb
global ycDruckerPrager
global ntNonlinElastic
global ntElastoPlastic
global kNeoHookean
global kMooneyRivlin
global kGeneralisedMooneyRivlin
global kOgden
global ipModulus
global ipPoisson
global ipDensity
global kNodeDisp
global kNodeVel
global kNodeAcc
global kNodePhase
global kNodeReact
global kNodeTemp
global kNodeFlux
global kNodeInfluence
global rtNodeDisp
global rtNodeVel
global rtNodeAcc
global rtNodePhase
global rtNodeReact
global rtNodeTemp
global rtNodeFlux
global rtNodeInfluence
global rtBeamForce
global rtBeamStrain
global rtBeamStress
global rtBeamTRelease
global rtBeamRRelease
global rtBeamCableXYZ
global rtBeamFlux
global rtBeamGradient
global rtBeamCreepStrain
global rtBeamEnergy
global rtBeamDisp
global rtBeamNodeReact
global ipSF1
global ipBM1
global ipSF2
global ipBM2
global ipAxialF
global ipTorque
global ipMinFibreStress
global ipMaxFibreStress
global ipMaxShearStress1
global ipMaxShearStress2
global ipAvShearStress1
global ipAvShearStress2
global ipTorqueStress
global ipMinPrincipalStress
global ipMaxPrincipalStress
global ipMinPipeHoopStress
global ipMaxPipeHoopStress
global ipMinAxialStress
global ipMaxAxialStress
global ipMinBendingStress1
global ipMaxBendingStress1
global ipMinBendingStress2
global ipMaxBendingStress2
global ipYieldRatio
global ipBeamFlux
global ipBeamTempGradient
global ipAxialStrain
global ipCurvature1
global ipCurvature2
global ipTwist
global ipRelEnd1Dir1
global ipRelEnd1Dir2
global ipRelEnd1Dir3
global ipRelEnd2Dir1
global ipRelEnd2Dir2
global ipRelEnd2Dir3
global ipBeamEnergyStored
global ipBeamEnergySpent
global rtPlateStress
global rtPlateStrain
global rtPlateEnergy
global rtPlateForce
global rtPlateMoment
global rtPlateCurvature
global rtPlatePlyStress
global rtPlatePlyStrain
global rtPlatePlyReserve
global rtPlateFlux
global rtPlateGradient
global rtPlateReoDesign
global rtPlateCreepStrain
global rtPlateSoil
global rtPlateUser
global rtPlateNodeReact
global rtPlateNodeDisp
global psPlateMidPlane
global psPlateZMinus
global psPlateZPlus
global rtBrickStress
global rtBrickStrain
global rtBrickEnergy
global rtBrickFlux
global rtBrickGradient
global rtBrickCreepStrain
global rtBrickSoil
global rtBrickUser
global rtBrickNodeReact
global rtBrickNodeDisp
global stBeamLocal
global stBeamPrincipal
global stBeamGlobal
global stPlateLocal
global stPlateGlobal
global stPlateCombined
global stPlateSupport
global stPlateDevLocal
global stPlateDevGlobal
global stPlateDevCombined
global stBrickLocal
global stBrickGlobal
global stBrickCombined
global stBrickSupport
global stBrickDevLocal
global stBrickDevGlobal
global stBrickDevCombined
global stLOCAL
global stGLOBAL
global stUCS
global stCOMBINED
global ipPlateLocalxx
global ipPlateLocalyy
global ipPlateLocalzz
global ipPlateLocalxy
global ipPlateLocalyz
global ipPlateLocalzx
global ipPlateLocalxz
global ipPlateLocalMean
global ipPlateLocalDevxx
global ipPlateLocalDevyy
global ipPlateEdgeSupport
global ipPlateFaceSupport
global ipPlateGlobalXX
global ipPlateGlobalYY
global ipPlateGlobalZZ
global ipPlateGlobalXY
global ipPlateGlobalYZ
global ipPlateGlobalZX
global ipPlateGlobalMean
global ipPlateGlobalDevXX
global ipPlateGlobalDevYY
global ipPlateGlobalDevZZ
global ipPlateUCSXX
global ipPlateUCSYY
global ipPlateUCSZZ
global ipPlateUCSXY
global ipPlateUCSYZ
global ipPlateUCSZX
global ipPlateCombPrincipal11
global ipPlateCombPrincipal22
global ipPlateCombPrincipalAngle
global ipPlateCombVonMises
global ipPlateCombTresca
global ipPlateCombMohrCoulomb
global ipPlateCombDruckerPrager
global ipPlateCombPlasticStrain
global ipPlateCombCreepEffRate
global ipPlateCombCreepShrinkage
global ipPlateCombYieldIndex
global ipPlateCombMean
global ipPlateCombDev11
global ipPlateCombDev22
global ipPlateAxiGlobalRR
global ipPlateAxiGlobalZZ
global ipPlateAxiGlobalTT
global ipPlateAxiGlobalRZ
global ipPlateAxiGlobalMean
global ipPlateAxiGlobalDevRR
global ipPlateAxiGlobalDevZZ
global ipPlateAxiGlobalDevTT
global ipPlateAxiCombPrincipal11
global ipPlateAxiCombPrincipal22
global ipPlateAxiCombPrincipal33
global ipPlateAxiCombVonMises
global ipPlateAxiCombTresca
global ipPlateAxiCombMohrCoulomb
global ipPlateAxiCombDruckerPrager
global ipPlateAxiCombPlasticStrain
global ipPlateAxiCombCreepEffRate
global ipPlateAxiCombCreepShrinkage
global ipPlateAxiCombYieldIndex
global ipPlateAxiCombMean
global ipPlateAxiCombDev11
global ipPlateAxiCombDev22
global ipPlateAxiCombDev33
global ipPlyStress11
global ipPlyStress22
global ipPlyStress12
global ipPlyILSx
global ipPlyILSy
global ipPlyStrain11
global ipPlyStrain22
global ipPlyStrain12
global ipPlyMaxStress
global ipPlyMaxStrain
global ipPlyTsaiHill
global ipPlyModTsaiWu
global ipPlyHoffman
global ipPlyInterlam
global ipPlateSoilTotalPorePressure
global ipPlateSoilExcessPorePressure
global ipPlateSoilOCRIndex
global ipPlateSoilStateIndex
global ipPlateSoilVoidRatio
global ipPlateFluxLocalx
global ipPlateFluxLocaly
global ipPlateFluxLocalxy
global ipPlateFluxGlobalX
global ipPlateFluxGlobalY
global ipPlateFluxGlobalZ
global ipPlateFluxGlobalXY
global ipPlateFluxGlobalYZ
global ipPlateFluxGlobalZX
global ipPlateFluxGlobalSRSS
global ipPlateFluxUCSX
global ipPlateFluxUCSY
global ipPlateFluxUCSZ
global ipPlateFluxUCSXY
global ipPlateFluxUCSYZ
global ipPlateFluxUCSZX
global ipPlateFluxUCSSRSS
global ipPlateRCWoodArmerMoment
global ipPlateRCWoodArmerForce
global ipPlateRCSteelArea
global ipPlateRCSteelAreaLessBase
global ipPlateRCSteelStress
global ipPlateRCConcreteStrain
global ipPlateRCBlockRatio
global ipPlateNodeReactFX
global ipPlateNodeReactFY
global ipPlateNodeReactFZ
global ipPlateNodeReactMX
global ipPlateNodeReactMY
global ipPlateNodeReactMZ
global ipPlateEnergyStored
global ipPlateEnergySpent
global ipBrickLocalxx
global ipBrickLocalyy
global ipBrickLocalzz
global ipBrickLocalxy
global ipBrickLocalyz
global ipBrickLocalzx
global ipBrickLocalMean
global ipBrickLocalDevxx
global ipBrickLocalDevyy
global ipBrickLocalDevzz
global ipBrickFaceSupport
global ipBrickGlobalXX
global ipBrickGlobalYY
global ipBrickGlobalZZ
global ipBrickGlobalXY
global ipBrickGlobalYZ
global ipBrickGlobalZX
global ipBrickGlobalMean
global ipBrickGlobalDevXX
global ipBrickGlobalDevYY
global ipBrickGlobalDevZZ
global ipBrickUCSXX
global ipBrickUCSYY
global ipBrickUCSZZ
global ipBrickUCSXY
global ipBrickUCSYZ
global ipBrickUCSZX
global ipBrickCombPrincipal11
global ipBrickCombPrincipal22
global ipBrickCombPrincipal33
global ipBrickCombVonMises
global ipBrickCombTresca
global ipBrickCombMohrCoulomb
global ipBrickCombDruckerPrager
global ipBrickCombPlasticStrain
global ipBrickCombCreepEffRate
global ipBrickCombCreepShrinkage
global ipBrickCombYieldIndex
global ipBrickCombMean
global ipBrickCombDev11
global ipBrickCombDev22
global ipBrickCombDev33
global ipBrickSoilTotalPorePressure
global ipBrickSoilExcessPorePressure
global ipBrickSoilOCRIndex
global ipBrickSoilStateIndex
global ipBrickSoilVoidRatio
global ipBrickFluxLocalx
global ipBrickFluxLocaly
global ipBrickFluxLocalz
global ipBrickFluxLocalxy
global ipBrickFluxLocalyz
global ipBrickFluxLocalzx
global ipBrickFluxLocalRMS
global ipBrickFluxGlobalX
global ipBrickFluxGlobalY
global ipBrickFluxGlobalZ
global ipBrickFluxGlobalXY
global ipBrickFluxGlobalYZ
global ipBrickFluxGlobalZX
global ipBrickFluxGlobalRMS
global ipBrickFluxUCSX
global ipBrickFluxUCSY
global ipBrickFluxUCSZ
global ipBrickFluxUCSXY
global ipBrickFluxUCSYZ
global ipBrickFluxUCSZX
global ipBrickFluxUCSRMS
global ipBrickNodeReactFX
global ipBrickNodeReactFY
global ipBrickNodeReactFZ
global ipBrickEnergyStored
global ipBrickEnergySpent
global ipFrequencyNFA
global ipModalMassNFA
global ipModalStiffNFA
global ipModalDampNFA
global ipModalTMassP1
global ipModalTMassP2
global ipModalTMassP3
global ipModalRMassP1
global ipModalRMassP2
global ipModalRMassP3
global ipMassXIRA
global ipMassYIRA
global ipMassZIRA
global ipXcIRA
global ipYcIRA
global ipZcIRA
global ipAccXIRA
global ipAccYIRA
global ipAccZIRA
global ipAngAccXIRA
global ipAngAccYIRA
global ipAngAccZIRA
global UCSCartesian
global UCSCylindrical
global UCSSpherical
global UCSToroidal
global mtCompliance
global mtStiffness
global ATTRFreedom
global ATTRForce
global ATTRMoment
global ATTRTemperature
global ATTRMTranslation
global ATTRMRotation
global ATTRKTranslation
global ATTRKRotation
global ATTRDamping
global ATTRNSMass
global ATTRNodeInfluence
global ATTRNodeHeatSource
global ATTRNodeVelocity
global ATTRNodeAcceleration
global vtFree
global vtFixed
global ATTRBeamAngle
global ATTRBeamOffset
global ATTRBeamTEndRelease
global ATTRBeamREndRelease
global ATTRBeamSupport
global ATTRBeamPreTension
global ATTRCableFreeLength
global ATTRBeamDLL
global ATTRBeamDLG
global ATTRBeamCFL
global ATTRBeamCFG
global ATTRBeamCML
global ATTRBeamCMG
global ATTRBeamTempGradient
global ATTRBeamConvection
global ATTRBeamRadiation
global ATTRBeamFlux
global ATTRBeamHeatSource
global ATTRBeamRadius
global ATTRPipePressure
global ATTRBeamNSMass
global ATTRPipeTemperature
global ATTRBeamDML
global ATTRBeamStringGroup
global ATTRBeamTaper
global ATTRBeamInfluence
global ATTRBeamSectionFactor
global ATTRBeamCreepLoadingAge
global ATTRBeamEndAttachment
global ATTRBeamConnectionUCS
global ATTRBeamStageProperty
global ATTRPlateAngle
global ATTRPlateOffset
global ATTRPlatePreLoad
global ATTRPlateFacePressure
global ATTRPlateFaceShear
global ATTRPlateEdgePressure
global ATTRPlateEdgeShear
global ATTRPlateEdgeNormalShear
global ATTRPlateTempGradient
global ATTRPlateEdgeSupport
global ATTRPlateFaceSupport
global ATTRPlateEdgeConvection
global ATTRPlateEdgeRadiation
global ATTRPlateFlux
global ATTRPlateHeatSource
global ATTRPlateGlobalPressure
global ATTRPlateEdgeRelease
global ATTRPlateThickness
global ATTRPlateNSMass
global ATTRLoadPatch
global ATTRPlatePointForce
global ATTRPlatePointMoment
global ATTRPlateFaceConvection
global ATTRPlateFaceRadiation
global ATTRPlateInfluence
global ATTRPlateSoilStress
global ATTRPlateSoilRatio
global ATTRPlateCreepLoadingAge
global ATTRPlateEdgeAttachment
global ATTRPlateFaceAttachment
global ATTRPlateStageProperty
global etInterpolated
global etNonInterpolated
global pfNone
global pfProjResultant
global pfProjComponents
global ATTRBrickPressure
global ATTRBrickShear
global ATTRBrickFaceFoundation
global ATTRBrickConvection
global ATTRBrickRadiation
global ATTRBrickFlux
global ATTRBrickHeatSource
global ATTRBrickGlobalPressure
global ATTRBrickNSMass
global ATTRBrickLocalAxes
global ATTRBrickPreLoad
global ATTRBrickPointForce
global ATTRBrickInfluence
global ATTRBrickSoilStress
global ATTRBrickSoilRatio
global ATTRBrickCreepLoadingAge
global ATTRBrickFaceAttachment
global ATTRBrickStageProperty
global TITLEModel
global TITLEProject
global TITLEReference
global TITLEAuthor
global TITLECreated
global TITLEModified
global ttVsTime
global ttVsTemperature
global ttVsFrequency
global ttStressStrain
global ttForceDisplacement
global ttMomentCurvature
global ttMomentRotation
global ttAccVsTime
global ttForceVelocity
global ttVsPosition
global ttStrainTime
global tyPeriod
global tyFrequency
global ptBeamStiffModVsTemp
global ptBeamAlphaVsTemp
global ptBeamConductVsTemp
global ptBeamCpVsTemp
global ptBeamStiffModVsTime
global ptBeamConductVsTime
global ptSpringAxialVsDisp
global ptSpringTorqueVsTwist
global ptSpringAxialVsVelocity
global ptTrussAxialStressVsStrain
global ptBeamAxialStressVsStrain
global ptBeamMomentK1
global ptBeamMomentK2
global ptConnectionShear1
global ptConnectionShear2
global ptConnectionAxial
global ptConnectionBend1
global ptConnectionBend2
global ptConnectionTorque
global ptBeamYieldVsTemp
global ptPlateModVsTemp
global ptPlateAlphaVsTemp
global ptPlateConductVsTemp
global ptPlateCpVsTemp
global ptPlateModVsTime
global ptPlateConductVsTime
global ptPlateStressVsStrain
global ptPlateYieldVsTemp
global ptBrickModVsTemp
global ptBrickAlphaVsTemp
global ptBrickConductVsTemp
global ptBrickCpVsTemp
global ptBrickModVsTime
global ptBrickConductVsTime
global ptBrickStressVsStrain
global ptBrickYieldVsTemp
global clConcreteHyperbolic
global clConcreteViscoChain
global clConcreteUserDefined
global clPrimaryPower
global clSecondaryPower
global clPrimarySecondaryPower
global clSecondaryHyperbolic
global clSecondaryExponential
global clThetaProjection
global clGenGraham
global clGenBlackburn
global clUserDefined
global kNoInertia
global kGravity
global kAccelerations
global kNormalFreedom
global kFreeBodyInertiaRelief
global kSingleSymmetryInertiaXY
global kSingleSymmetryInertiaYZ
global kSingleSymmetryInertiaZX
global kDoubleSymmetryInertiaX
global kDoubleSymmetryInertiaY
global kDoubleSymmetryInertiaZ
global ipRefTemp
global ipGlobOrigX
global ipGlobOrigY
global ipGlobOrigZ
global ipGlobAccX
global ipGlobAccY
global ipGlobAccZ
global ipGlobAngVelX
global ipGlobAngVelY
global ipGlobAngVelZ
global ipGlobAngAccX
global ipGlobAngAccY
global ipGlobAngAccZ
global dtNoDamping
global dtRayleighDamping
global dtModalDamping
global dtViscousDamping
global rmSetFrequencies
global rmSetAlphaBeta
global hrNodeFlux
global hrBeamFlux
global hrPlateFlux
global hrBrickFlux
global frBeamForcePattern
global frBeamStrainPattern
global frPlateStressPattern
global frPlateStrainPattern
global frBrickStressPattern
global frBrickStrainPattern
global srNodeReaction
global srNodeVelocity
global srNodeAcceleration
global srBeamForce
global srBeamMNLStress
global srBeamStrain
global srPlateStress
global srPlateStrain
global srBrickStress
global srBrickStrain
global srElementNodeForce
global spDoSturm
global spNonlinearMaterial
global spNonlinearGeometry
global spAddKg
global spCalcDampingRatios
global spIncludeLinkReactions
global spFullSystemTransient
global spNonlinearHeat
global spLumpedLoadBeam
global spLumpedLoadPlate
global spLumpedLoadBrick
global spLumpedMassBeam
global spLumpedMassPlate
global spLumpedMassBrick
global spForceDrillCheck
global spSaveRestartFile
global spSaveIntermediate
global spExcludeMassX
global spExcludeMassY
global spExcludeMassZ
global spSaveSRSSSpectral
global spSaveCQCSpectral
global spDoResidualsCheck
global spSuppressAllSingularities
global spSaveModalResults
global spSpectralReactionAsInertia
global spReducedLogFile
global spIncludeRotationalMass
global spIgnoreCompressiveBeamKg
global spAutoScaleKg
global spDynamicAutoStepping
global spScaleSupports
global spAutoShift
global spSaveTableInsertedSteps
global spSaveLastRestartStep
global spAutoAssignPathDivisions
global spTreeStartNumber
global spNumFrequency
global spNumBucklingModes
global spMaxIterationEig
global spMaxIterationNonlin
global spNumBeamSlicesSpectral
global spMaxConjugateGradientIter
global spMaxNumWarnings
global spFiniteStrainDefinition
global spBeamLength
global spFormStiffMatrix
global spMaxUpdateInterval
global spFormNonlinHeatStiffMatrix
global spExpandWorkingSet
global spMinNumViscoUnits
global spMaxNumViscoUnits
global spCurveFitTimeUnit
global spStaticAutoStepping
global spBeamKgType
global spEigenTolerance
global spFrequencyShift
global spBucklingShift
global spNonlinDispTolerance
global spNonlinResidualTolerance
global spTransientReferenceTemperature
global spRelaxationFactor
global spNonlinHeatTolerance
global spMinimumTimeStep
global spWilsonTheta
global spNewmarkBeta
global spGlobalZeroDiagonal
global spConjugateGradientTol
global spMinimumDimension
global spMinimumInternalAngle
global spZeroForce
global spZeroDiagonal
global spZeroContactFactor
global spFrictionCutoffStrain
global spZeroTranslation
global spZeroRotation
global spDrillStiffFactor
global spMaxNormalsAngle
global spMaximumRotation
global spZeroDisplacement
global spMaximumDispRatio
global spMinimumLoadReductionFactor
global spMaxDispChange
global spMaxResidualChange
global spZeroFrequency
global spZeroBucklingEigen
global spCurveFitTime
global spSpacingBias
global spTimeStepParam
global spSlidingFrictionFactor
global spMNLTangentRatio
global spStickingFrictionFactor
global spMinArcLengthFactor
global spMaxFibreStrainInc
global mtBaseAcc
global mtBaseVel
global mtBaseDisp
global mtAppliedLoad
global stSkyline
global stSparse
global stIterativePCG
global tdNone
global tdCombined
global htVsFrequency
global htVsTime
global rnNone
global rnTree
global rnGeometry
global rnAMD
global ztAbsolute
global ztRelative
global btFalse
global btTrue
global ERR7_InvalidRegionalSettings
global ERR7_InvalidDLLsPresent
global ERR7_APINotInitialised
global ERR7_InvalidErrorCode
global ERR7_APINotLicensed
global ERR7_UnknownError
global ERR7_NoError
global ERR7_FileAlreadyOpen
global ERR7_FileNotFound
global ERR7_FileNotSt7
global ERR7_InvalidFileName
global ERR7_FileIsNewer
global ERR7_CannotReadFile
global ERR7_InvalidScratchPath
global ERR7_FileNotOpen
global ERR7_ExceededTotal
global ERR7_DataNotFound
global ERR7_InvalidResultFile
global ERR7_ResultFileNotOpen
global ERR7_ExceededResultCase
global ERR7_UnknownResultType
global ERR7_UnknownResultLocation
global ERR7_UnknownSurfaceLocation
global ERR7_UnknownProperty
global ERR7_InvalidEntity
global ERR7_InvalidBeamPosition
global ERR7_InvalidLoadCase
global ERR7_InvalidFreedomCase
global ERR7_UnknownTitle
global ERR7_UnknownUCS
global ERR7_TooManyBeamStations
global ERR7_UnknownSubType
global ERR7_GroupIdDoesNotExist
global ERR7_InvalidFileUnit
global ERR7_CannotSaveFile
global ERR7_ResultFileIsOpen
global ERR7_InvalidUnits
global ERR7_InvalidEntityNodes
global ERR7_InvalidUCSType
global ERR7_InvalidUCSID
global ERR7_UCSIDAlreadyExists
global ERR7_CaseNameAlreadyExists
global ERR7_InvalidEntityNumber
global ERR7_InvalidBeamEnd
global ERR7_InvalidBeamDir
global ERR7_InvalidPlateEdge
global ERR7_InvalidBrickFace
global ERR7_InvalidBeamType
global ERR7_InvalidPlateType
global ERR7_InvalidMaterialType
global ERR7_PropertyAlreadyExists
global ERR7_InvalidBeamSectionType
global ERR7_PropertyNotSpring
global ERR7_PropertyNotCable
global ERR7_PropertyNotTruss
global ERR7_PropertyNotCutOffBar
global ERR7_PropertyNotPointContact
global ERR7_PropertyNotBeam
global ERR7_PropertyNotPipe
global ERR7_PropertyNotConnectionBeam
global ERR7_InvalidSectionParameters
global ERR7_PropertyNotUserDefinedBeam
global ERR7_MaterialIsUserDefined
global ERR7_MaterialNotIsotropic
global ERR7_MaterialNotOrthotropic
global ERR7_InvalidRubberModel
global ERR7_MaterialNotRubber
global ERR7_InvalidSectionProperties
global ERR7_PlateDoesNotHaveThickness
global ERR7_IncompatibleMaterialCombination
global ERR7_UnknownSolver
global ERR7_InvalidSolverMode
global ERR7_InvalidMirrorOption
global ERR7_SectionCannotBeMirrored
global ERR7_InvalidTableType
global ERR7_InvalidTableName
global ERR7_TableNameAlreadyExists
global ERR7_InvalidNumberOfEntries
global ERR7_InvalidZipType
global ERR7_TableDoesNotExist
global ERR7_NotFrequencyTable
global ERR7_InvalidFrequencyType
global ERR7_InvalidTableSetting
global ERR7_IncompatibleTableType
global ERR7_IncompatibleCriterionCombination
global ERR7_InvalidModalFile
global ERR7_InvalidCombinationCaseNumber
global ERR7_InvalidInitialCaseNumber
global ERR7_InvalidInitialFile
global ERR7_InvalidModeNumber
global ERR7_BeamIsNotBXS
global ERR7_InvalidDampingType
global ERR7_InvalidRayleighMode
global ERR7_CannotReadBXS
global ERR7_InvalidResultType
global ERR7_InvalidSolverParameter
global ERR7_InvalidModalLoadType
global ERR7_InvalidTimeRow
global ERR7_SparseSolverNotLicenced
global ERR7_InvalidSolverScheme
global ERR7_InvalidSortOption
global ERR7_IncompatibleResultFile
global ERR7_InvalidLinkType
global ERR7_InvalidLinkData
global ERR7_OnlyOneLoadCase
global ERR7_OnlyOneFreedomCase
global ERR7_InvalidLoadID
global ERR7_InvalidBeamLoadType
global ERR7_InvalidStringID
global ERR7_InvalidPatchType
global ERR7_IncrementDoesNotExist
global ERR7_InvalidLoadCaseType
global ERR7_InvalidFreedomCaseType
global ERR7_InvalidHarmonicLoadType
global ERR7_InvalidTemperatureType
global ERR7_InvalidPatchTypeForPlate
global ERR7_InvalidAttributeType
global ERR7_MaterialNotAnisotropic
global ERR7_InvalidMatrixType
global ERR7_MaterialNotUserDefined
global ERR7_InvalidIndex
global ERR7_InvalidContactType
global ERR7_InvalidContactSubType
global ERR7_InvalidCutoffType
global ERR7_ResultQuantityNotAvailable
global ERR7_YieldNotMCDP
global ERR7_CombinationDoesNotExist
global ERR7_InvalidSeismicCase
global ERR7_InvalidImportExportMode
global ERR7_CannotReadImportFile
global ERR7_InvalidAnsysImportFormat
global ERR7_InvalidAnsysArrayStatus
global ERR7_CannotWriteExportFile
global ERR7_InvalidAnsysExportFormat
global ERR7_InvalidAnsysEndReleaseOption
global ERR7_InvalidAnsysExportUnits
global ERR7_InvalidSt7ExportFormat
global ERR7_InvalidUVPos
global ERR7_InvalidResponseType
global ERR7_InvalidLayoutID
global ERR7_InvalidPlateSurface
global ERR7_MeshingErrors
global ERR7_InvalidZipTolerance
global ERR7_InvalidTaperAxis
global ERR7_InvalidTaperType
global ERR7_InvalidTaperRatio
global ERR7_InvalidPositionType
global ERR7_InvalidPreLoadType
global ERR7_InvalidVertexType
global ERR7_InvalidVertexMeshSize
global ERR7_InvalidGeometryEdgeType
global ERR7_InvalidPropertyNumber
global ERR7_InvalidFaceSurface
global ERR7_InvalidModType
global ERR7_MaterialNotSoil
global ERR7_MaterialNotFluid
global ERR7_SoilTypeNotDC
global ERR7_SoilTypeNotCC
global ERR7_MaterialNotLaminate
global ERR7_InvalidLaminateID
global ERR7_LaminateNameAlreadyExists
global ERR7_LaminateIDAlreadyExists
global ERR7_PlyDoesNotExist
global ERR7_ExceededMaxNumPlies
global ERR7_LayoutIDAlreadyExists
global ERR7_InvalidNumModes
global ERR7_InvalidLTAMethod
global ERR7_InvalidLTASolutionType
global ERR7_ExceededMaxNumStages
global ERR7_StageDoesNotExist
global ERR7_ExceededMaxNumSpectralCases
global ERR7_InvalidSpectralCase
global ERR7_InvalidSpectrumType
global ERR7_InvalidResultsSign
global ERR7_InvalidPositionTableAxis
global ERR7_InvalidInitialConditionsType
global ERR7_ExceededMaxNumNodeHistory
global ERR7_NodeHistoryDoesNotExist
global ERR7_InvalidTransientTempType
global ERR7_InvalidTimeUnit
global ERR7_InvalidLoadPath
global ERR7_InvalidTempDependenceType
global ERR7_InvalidTrigType
global ERR7_InvalidUserEquation
global ERR7_InvalidCreepID
global ERR7_CreepIDAlreadyExists
global ERR7_InvalidCreepLaw
global ERR7_InvalidCreepHardeningLaw
global ERR7_InvalidCreepViscoChainRow
global ERR7_InvalidCreepFunctionType
global ERR7_InvalidCreepShrinkageType
global ERR7_InvalidTableRow
global ERR7_ExceededMaxNumRows
global ERR7_InvalidLoadPathTemplateID
global ERR7_LoadPathTemplateIDAlreadyExists
global ERR7_InvalidLoadPathLane
global ERR7_ExceededMaxNumLoadPathTemplates
global ERR7_ExceededMaxNumLoadPathVehicles
global ERR7_InvalidLoadPathVehicle
global ERR7_InvalidMobilityType
global ERR7_InvalidAxisSystem
global ERR7_InvalidLoadPathID
global ERR7_LoadPathIDAlreadyExists
global ERR7_InvalidPathDefinition
global ERR7_InvalidLoadPathShape
global ERR7_InvalidLoadPathSurface
global ERR7_InvalidNumPathDivs
global ERR7_InvalidGeometryCavityLoop
global ERR7_InvalidLimitEnvelope
global ERR7_ExceededMaxNumLimitEnvelopes
global ERR7_InvalidCombEnvelope
global ERR7_ExceededMaxNumCombEnvelopes
global ERR7_InvalidFactorsEnvelope
global ERR7_ExceededMaxNumFactorsEnvelopes
global ERR7_InvalidLimitEnvelopeType
global ERR7_InvalidCombEnvelopeType
global ERR7_InvalidFactorsEnvelopeType
global ERR7_InvalidCombEnvelopeAccType
global ERR7_InvalidEnvelopeSet
global ERR7_ExceededMaxNumEnvelopeSets
global ERR7_InvalidEnvelopeSetType
global ERR7_InvalidCombResFile
global ERR7_ExceededMaxNumCombResFiles
global ERR7_CannotCombResFiles
global ERR7_InvalidStartEndTimes
global ERR7_InvalidNumSteps
global ERR7_InvalidLibraryPath
global ERR7_InvalidLibraryType
global ERR7_InvalidLibraryID
global ERR7_InvalidLibraryName
global ERR7_InvalidLibraryItemID
global ERR7_InvalidLibraryItemName
global ERR7_InvalidDisplayOptionsPath
global ERR7_InvalidSolverPath
global ERR7_InvalidCementHardeningType
global ERR7_ZeroPlateElements
global ERR7_CannotMakeBXS
global ERR7_CannotCalculateBXSData
global ERR7_InvalidSurfaceMeshTargetType
global ERR7_InvalidModalNodeReactType
global ERR7_InvalidAxis
global ERR7_InvalidBeamAxisType
global ERR7_InvalidStaadCountryCodeOption
global ERR7_InvalidGeometryFormatProtocol
global ERR7_InvalidDXFBeamOption
global ERR7_InvalidDXFPlateOption
global ERR7_InvalidLoadPathLaneFactorType
global ERR7_InvalidLoadPathVehicleInstance
global ERR7_InvalidNumBeamStations
global ERR7_ResFileUnsupportedType
global ERR7_ResFileAlreadyOpen
global ERR7_ResFileInvalidNumCases
global ERR7_ResFileNotOpen
global ERR7_ResFileInvalidCase
global ERR7_ResFileDoesNotHaveEntity
global ERR7_ResFileInvalidQuantity
global ERR7_ResFileQuantityNotExist
global ERR7_ResFileCantSave
global ERR7_ResFileCantClearQuantity
global ERR7_ResFileContainsNoElements
global ERR7_ResFileContainsNoNodes
global ERR7_ResFileInvalidName
global ERR7_ResFileAssociationNotAllowed
global ERR7_ResFileIncompatibleQuantity
global ERR7_CannotEditSolverFiles
global ERR7_CannotOpenResultFile
global ERR7_CouldNotShowModelWindow
global ERR7_ModelWindowWasNotShowing
global ERR7_CantDoWithModalWindows
global ERR7_InvalidSelectionEndEdgeFace
global ERR7_CouldNotCreateModelWindow
global ERR7_ModelWindowWasNotCreated
global ERR7_InvalidImageType
global ERR7_InvalidImageDimensions
global ERR7_InsufficientRamToCreateImage
global ERR7_CannotSaveImageFile
global ERR7_InvalidWindowDimensions
global ERR7_InvalidResultQuantity
global ERR7_InvalidResultSubQuantity
global ERR7_InvalidComponent
global ERR7_ResultIsNotAvailable
global ERR7_InvalidUCSIndex
global ERR7_InvalidDiagramAxis
global ERR7_InvalidVectorComponents
global ERR7_TableTypeIsNotTimeBased
global ERR7_InvalidTableID
global ERR7_LinkNotMasterSlave
global ERR7_LinkNotSectorSymmetry
global ERR7_LinkNotCoupling
global ERR7_LinkNotPinned
global ERR7_LinkNotRigid
global ERR7_LinkNotShrink
global ERR7_LinkNotTwoPoint
global ERR7_LinkNotAttachment
global ERR7_LinkNotMultiPoint
global ERR7_InvalidCoupleType
global ERR7_InvalidRigidPlane
global ERR7_InvalidMultiPointFactorsType
global ERR7_InvalidMultiPointLink
global ERR7_InvalidAttachmentType
global ERR7_ExceededMaxNumColumns
global ERR7_CouldNotDestroyModelWindow
global ERR7_CannotSetWindowParent
global ERR7_InvalidLoadCaseFilePath
global ERR7_InvalidStaadLengthUnit
global ERR7_InvalidStaadForceUnit
global ERR7_InvalidDuplicateFaceType
global ERR7_InvalidNodeCoordinateKeepType
global ERR7_CommentDoesNotExist
global ERR7_InvalidFilePath
global ERR7_InvalidContactYieldType
global ERR7_InvalidNumMeshingLoops
global ERR7_InvalidMeshPositionOnUCS
global ERR7_InvalidK0Expression
global ERR7_InvalidK1Expression
global ERR7_NoPatchLoadsCreated
global ERR7_InvalidResOptsBeamEnvelope
global ERR7_InvalidResOptsRotationUnit
global ERR7_InvalidResOptsHRASetting
global ERR7_InvalidResOptsStageDisplacement
global ERR7_InvalidToolOptsZipOptions
global ERR7_InvalidToolOptsSubdivideOptions
global ERR7_InvalidToolOptsCopyOptions
global ERR7_InvalidToleranceType
global ERR7_InvalidAttachPartsParams
global ERR7_InvalidDrawParameters
global ERR7_FilesStillOpen
global ERR7_SolverStillRunning
global ERR7_InvalidPolygonToFaceParameters
global ERR7_InvalidResOptsStrainUnit
global ERR7_FunctionNotSupported
global ERR7_SoilTypeNotMC
global ERR7_SoilTypeNotDP
global ERR7_TooManyAnimations
global ERR7_InvalidAnimationFile
global ERR7_InvalidAnimationMode
global ERR7_InsufficientFrames
global ERR7_AnimationDimensionsTooSmall
global ERR7_AnimationDimensionsTooLarge
global ERR7_ReducedAnimation
global ERR7_InvalidAnimationType
global ERR7_CannotFindStubFile
global ERR7_CouldNotSaveAnimationFile
global ERR7_AnimationHandleOutOfRange
global ERR7_AnimationNotRunning
global ERR7_SoilTypeNotLS
global ERR7_NoPolygonWasConverted
global ERR7_InvalidAlphaTempType
global ERR7_InvalidGravityDirection
global ERR7_InvalidAttachmentDirection
global ERR7_InvalidHardeningType
global ERR7_ResultCaseNotInertiaRelief
global ERR7_InvalidNumLayers
global ERR7_PlateDoesNotHaveLayers
global ERR7_ToolOperationFailed
global SE_NoLoadCaseSelected
global SE_IncompatibleRestartFile
global SE_ElementUsesInvalidProperty
global SE_InvalidElement
global SE_NeedNonlinearHeatSolver
global SE_TableNotFound
global SE_InvalidRestartFile
global SE_InvalidInitialFile
global SE_InvalidSolverResultFile
global SE_InvalidLink
global SE_InvalidPlateCohesionValue
global SE_InvalidBrickCohesionValue
global SE_NonlinearSolverRequired
global SE_NoLoadTablesDefined
global SE_NoVelocityDataInInitialFile
global SE_NoModesIncluded
global SE_InvalidTimeStep
global SE_LoadIncrementsNotDefined
global SE_NoFreedomCaseInIncrements
global SE_InvalidInitialTemperatureFile
global SE_InvalidFrequencyRange
global SE_ModelMixesAxiNonAxi
global SE_CompositeModuleNotAvailable
global SE_CannotFindSolver
global SE_UnknownException
global SE_DuplicateLinks
global SE_CannotAppendToFile
global SE_CannotOverwriteFile
global SE_CannotWriteToResultFile
global SE_CannotWriteToLogFile
global SE_CannotReadRestartFile
global SE_InitialConditionsNotValid
global SE_InvalidRayleighFactors
global SE_ShearPanelMustBeQuad4
global SE_SingularPlateMatrix
global SE_SingularBrickMatrix
global SE_NoBeamProperties
global SE_NoPlateProperties
global SE_NoBrickProperties
global SE_MoreLoadIncrementsNeeded
global SE_RubberRequiresGNL
global SE_NoFreedomCaseSelected
global SE_InvalidSpectralVectors
global SE_NoSpectralResultsSelected
global SE_SpectralFactorsNotDefined
global SE_SpectralFactorsAllZero
global SE_NoTimeStepsSaved
global SE_InvalidDirectionVector
global SE_HarmonicFactorsAllZero
global SE_TemperatureDependenceCaseNotSet
global SE_ZeroLengthRigidLinkGenerated
global SE_InvalidStringGroupDefinition
global SE_InvalidPreTensionOnString
global SE_StringOrderHasChanged
global SE_BadTaperData
global SE_TaperedPlasticBeams
global SE_NoMovingLoadPathsInCases
global SE_NoResponseVariablesDefined
global SE_InvalidPlateVariableRequested
global SE_InvalidGravityCase
global SE_InvalidUserPlateCreepDefinition
global SE_InvalidUserBrickCreepDefinition
global SE_InvalidPlateShrinkageDefinition
global SE_InvalidBrickShrinkageDefinition
global SE_InvalidLaminateID
global SE_CannotReadWriteScratchPath
global SE_CannotConvertAttachmentLink
global SE_SoilRequiresMNL
global SE_ActiveStageHasNoIncrements
global SE_ConcreteCreepMNL
global SE_CannotConvertInterpMultiPoint
global SE_MissingInsituStress
global SE_InvalidMaterialNonlinearString
global SE_TensileInsituPlateStress
global SE_TensileInsituBrickStress
global SE_IncompatibleRestartUnits
global SE_CreepTimeTooShort
global SE_InvalidElements
global SE_InsufficientRestartFileSteps
global SE_NeedNodeTempNTASolver
global kMaxPlateResult
global kMaxBrickResult
global kMaxBeamRelease
global kMaxDisp
global kAllStations
global kMaxUCSDoubles
global stLinearStaticSolver
global stLinearBucklingSolver
global stNonlinearStaticSolver
global stNaturalFrequencySolver
global stHarmonicResponseSolver
global stSpectralResponseSolver
global stLinearTransientDynamicSolver
global stNonlinearTransientDynamicSolver
global stSteadyHeatSolver
global stTransientHeatSolver
global stLoadInfluenceSolver
global stQuasiStaticSolver
global smNormalRun
global smProgressRun
global smBackgroundRun
global ipLoadCaseDefRefTemp
global ipLoadCaseDefOriginX
global ipLoadCaseDefOriginY
global ipLoadCaseDefOriginZ
global ipLoadCaseDefLinAccX
global ipLoadCaseDefLinAccY
global ipLoadCaseDefLinAccZ
global ipLoadCaseDefAngVelX
global ipLoadCaseDefAngVelY
global ipLoadCaseDefAngVelZ
global ipLoadCaseDefAngAccX
global ipLoadCaseDefAngAccY
global ipLoadCaseDefAngAccZ
global ipSeismicCaseDefAlpha
global ipSeismicCaseDefPhi
global ipSeismicCaseDefBeta
global ipSeismicCaseDefK
global ipSeismicCaseDefh0
global ipSeismicCaseDefDir
global ipSeismicCaseDefLinAcc
global ipSeismicCaseDefV1
global ipSeismicCaseDefV2
global ieQuietRun
global ieProgressRun
global ipNASTRANImportUnits
global ipNASTRANFreedomCase
global ipNASTRANLoadCase
global ipNASTRANSolver
global ipNASTRANExportUnits
global ipNASTRANBeamStressSections
global ipNASTRANBeamSectionGeometry
global ipNASTRANExportHeatTransfer
global ipNASTRANExportNSMass
global ipNASTRANExportUnusedProps
global ipNASTRANTemperatureCase
global ipNASTRANExportZeroFields
global ieNASTRANSolverLSA
global ieNASTRANSolverNFA
global ieNASTRANSolverLBA
global ieNASTRANExportGeometryProps
global ieNASTRANExportPropsOnly
global naUnits_kg_N_m
global naUnits_T_N_mm
global naUnits_sl_lbf_ft
global naUnits_lbm_lbf_in
global naUnits_sl_lbf_in
global naUnits_NoUnits
global ipANSYSImportFormat
global ipANSYSArrayParameters
global ipANSYSImportLoadCaseFiles
global ipANSYSImportIGESEntities
global ipANSYSFixElementConnectivity
global ipANSYSRemoveDuplicateProps
global ipANSYSExportFormat
global ipANSYSFreedomCase
global ipANSYSLoadCase
global ipANSYSUnits
global ipANSYSEndRelease
global ipANSYSExportNonlinearMat
global ipANSYSExportHeatTransfer
global ipANSYSExportPreLoadNSMass
global ipANSYSExportTetraOption
global ieANSYSBatchImport
global ieANSYSCDBImport
global ieANSYSBatchCDBImport
global ieANSYSBatch1Export
global ieANSYSBatch3Export
global ieANSYSBlockedCDBExport
global ieANSYSUnblockedCDBExport
global ieANSYSArrayOverwrite
global ieANSYSArrayIgnore
global ieANSYSArrayPrompt
global ieANSYSEndReleaseFixed
global ieANSYSEndReleaseFull
global anUnits_NoUnits
global anUnits_kg_m_C
global anUnits_g_cm_C
global anUnits_T_mm_C
global anUnits_sl_ft_F
global anUnits_lbm_in_F
global ipSTAADCountryType
global ipSTAADIncludeSectionLibrary
global ipSTAADStripUnderscore
global ipSTAADStripSectionSpaces
global ipSTAADLengthUnit
global ipSTAADForceUnit
global ieSTAADAmericanCode
global ieSTAADAustralianCode
global ieSTAADBritishCode
global sdLengthUnit_in
global sdLengthUnit_ft
global sdLengthUnit_cm
global sdLengthUnit_m
global sdLengthUnit_mm
global sdLengthUnit_dm
global sdLengthUnit_km
global sdForceUnit_kip
global sdForceUnit_lbf
global sdForceUnit_kgf
global sdForceUnit_MTf
global sdForceUnit_N
global sdForceUnit_kN
global sdForceUnit_MN
global sdForceUnit_dN
global ipSAP2000ConvertBlackTo
global ipSAP2000DecimalSeparator
global ipSAP2000ThousandSeparator
global ipSAP2000MergeDuplicateFreedomSets
global ieSAP2000Period
global ieSAP2000Comma
global ieSAP2000Space
global ieSAP2000None
global ieSt7ExportCurrent
global ieSt7Export106
global ieSt7Export21x
global ieSt7Export22x
global ieSt7Export23x
global ipImportGeomProp
global ipImportGeomCurvesToBeams
global ipImportGeomGroupsAs
global ipImportGeomColourAsProperty
global ipImportGeomBlackReplacement
global ipImportGeomACISBodiesAsGroups
global ipImportGeomLengthUnit
global ipExportGeomColour
global ipExportGeomGroupsAsLevels
global ipExportGeomFullGroupPath
global ipExportGeomFormatProtocol
global ipExportGeomCurve
global ipExportGeomPeriodicFace
global ipExportGeomKeepAnalytic
global ipImportGeomTol
global luGeomNONE
global luGeomINCH
global luGeomMILLIMETRE
global luGeomFEET
global luGeomMILES
global luGeomMETRE
global luGeomKILOMETRE
global luGeomMIL
global luGeomMICRON
global luGeomCENTIMETRE
global luGeomMICROINCH
global luGeomUNSPECIFIED
global ggNone
global ggAuto
global ggSubfigures
global ggLevels
global ggAssemblies
global ifBoundedSurface
global ifTrimmedParametricSurface
global ifOpenShell
global ifManifoldSolidBRep
global spConfigControlDesign
global spAutomotiveDesign
global ieModelOnly
global ieParameterOnly
global ieModelPreferred
global ieParameterPreferred
global ieSeamOnlyAsRequired
global ieSplitOnFaceBoundary
global ieSplitIntoHalves
global ieColourNone
global ieFaceColour
global ieGroupColour
global iePropertyColour
global ipDXFImportFrozenLayers
global ipDXFImportLayersAsGroups
global ipDXFImportColoursAsProps
global ipDXFImportPolylineAsPlates
global ipDXFImportPolygonAsBricks
global ipDXFImportSegmentsPerCircle
global ipDXFExportPlatesBricks3DFaces
global ipDXFExportGroupsAsLayers
global ipDXFExportPropColoursAsEntityColours
global ipDXFExportBeamsAs
global ipDXFExportPlatesAs
global bmLine
global bmSection
global bmSolid
global plSurface
global plSolid
global grNone
global grAuto
global grSubfigures
global grLevels
global grAssembly
global ipBXSXBar
global ipBXSYBar
global ipBXSArea
global ipBXSI11
global ipBXSI22
global ipBXSAngle
global ipBXSZ11Plus
global ipBXSZ11Minus
global ipBXSZ22Plus
global ipBXSZ22Minus
global ipBXSS11
global ipBXSS22
global ipBXSr1
global ipBXSr2
global ipBXSSA1
global ipBXSSA2
global ipBXSSL1
global ipBXSSL2
global ipBXSIXX
global ipBXSIYY
global ipBXSIXY
global ipBXSIxxL
global ipBXSIyyL
global ipBXSIxyL
global ipBXSZxxPlus
global ipBXSZxxMinus
global ipBXSZyyPlus
global ipBXSZyyMinus
global ipBXSSxx
global ipBXSSyy
global ipBXSrx
global ipBXSry
global ipBXSJ
global ipBXSIw
global ipGeometryAccuracy
global ipGeometryFeatureLength
global ipGeometryEdgeMergeAngle
global ipGeometryAccuracyType
global ipGeometryFeatureType
global ipGeometryActOnWholeModel
global ipGeometryFreeEdgesOnly
global ipGeometryDuplicateFaces
global dfGeometryLeave
global dfGeometryDeleteOne
global dfGeometryDeleteBoth
global ipMeshTolerance
global ipMeshToleranceType
global ipZipNodes
global ipRemoveDuplicateElements
global ipFixElementConnectivity
global ipDeleteFreeNodes
global ipDoBeams
global ipDoPlates
global ipDoBricks
global ipDoLinks
global ipZeroLengthLinks
global ipZeroLengthBeams
global ipNodeAttributeKeep
global ipNodeCoordinates
global ipAllowDifferentProps
global ipActOnWholeModel
global dfLeaveAll
global dfLeaveOne
global dfLeaveNone
global naLower
global naHigher
global naAccumulate
global ncAverage
global ncLowerNode
global ncHigherNode
global ncSelectedNode
global ipSurfaceMeshMode
global ipSurfaceMeshSizeMode
global ipSurfaceMeshTargetNodes
global ipSurfaceMeshTargetPropertyID
global ipSurfaceMeshAutoCreateProperties
global ipSurfaceMeshMinEdgesPerCircle
global ipSurfaceMeshApplyTransitioning
global ipSurfaceMeshAllowUserStop
global ipSurfaceMeshConsiderNearVertex
global mmAuto
global mmCustom
global smPercentage
global smAbsolute
global ipSurfaceMeshSize
global ipSurfaceMeshLengthRatio
global ipSurfaceMeshMaximumIncrease
global ipSurfaceMeshOnEdgesLongerThan
global ipTetraMeshSize
global ipTetraMeshProperty
global ipTetraMeshInc
global ipTetraMesh10
global ipTetraMeshGroupsAsSolids
global ipTetraMeshSmooth
global ipTetraMeshAutoCreateProperties
global ipTetraMeshDeletePlates
global ipTetraMeshMultiBodyOption
global ipTetraMeshAllowUserStop
global ipTetraMeshCheckSelfIntersect
global msFine
global msMedium
global msCoarse
global mbCancelMeshing
global mbCavity
global mbSeparateSolids
global ipMeshTargetNodes
global ipMeshTargetPropertyID
global ipMeshUCSID
global ipMeshGroupID
global ipMeshPositionUCS
global itBitmap8Bit
global itBitmap16Bit
global itBitmap24Bit
global itJPEG
global imView
global imDisplay
global imShow
global imSelect
global imResults
global wsModelWindowNotCreated
global wsModelWindowVisible
global wsModelWindowMaximised
global wsModelWindowMinimised
global wsModelWindowHidden
global ipNodeSelectedColour
global ipNodeUnselectedColour
global ipNodeShowFree
global ipNodeNumberMode
global ipNodeSymbol
global ipBeamDisplay
global ipBeamShowRefNode
global ipBeamShowOffset
global ipBeamMoveToOffset
global ipBeamLightShade
global ipBeamGlobalColour
global ipBeamOutlineColour
global ipBeamEnd1Colour
global ipBeamEnd2Colour
global ipBeamRefNodeColour
global ipBeamFilledMode
global ipBeamContour
global ipBeamShrink
global ipBeamRoundFacets
global ipBeamSpringCoils
global ipBeamSpringAspect
global ipBeamThickness
global ipBeamSections
global ipBeamOutlines
global ipBeamShowAxes
global ipBeamNumberMode
global ipPlateDisplay
global ipPlateLightShade
global ipPlateGlobalColour
global ipPlateOutlineColour
global ipPlateZPlusColour
global ipPlateZMinusColour
global ipPlateOffsetColour
global ipPlateFilledMode
global ipPlateContour
global ipPlateShrink
global ipPlateOutlines
global ipPlateOutlineThickness
global ipPlateShowAxes
global ipPlateAxisOnPly
global ipPlateOffset
global ipPlateMoveToOffset
global ipPlateNumberMode
global ipBrickLightShade
global ipBrickGlobalColour
global ipBrickOutlineColour
global ipBrickFilledMode
global ipBrickContour
global ipBrickShrink
global ipBrickOutlines
global ipBrickOutlineThickness
global ipBrickShowFreeFaces
global ipBrickAxes1
global ipBrickAxes2
global ipBrickAxes3
global ipBrickNumberMode
global ipBrickShowAllFaces
global ipLinkGlobalColour
global ipLinkMasterSlaveColour
global ipLinkSectorSymmColour
global ipLinkCouplingColour
global ipLinkPinnedColour
global ipLinkRigidColour
global ipLinkShrinkColour
global ipLinkTwoPointColour
global ipLinkAttachmentColour
global ipLinkMultiPointColour
global ipLinkFilledMode
global ipLinkNumberMode
global ipLoadPathColour
global ipLoadPathColourMode
global ipLoadPathNumberMode
global ipLoadPathShowDivisions
global ipLoadPathThickness
global ipVertexFreeColour
global ipVertexFixedColour
global ipVertexSelectedColour
global ipVertextNumberMode
global ipVertexSymbol
global ipEdgeShow
global ipEdgeShowNonInterp
global ipEdgeStyle
global ipEdgeColourMode
global ipEdgeColour
global ipEdgeNonInterpColour
global ipFaceWireframeColour
global ipFaceShowWireframes
global ipFaceShowControlPoints
global ipFaceShowNormals
global ipFaceWireframeStyle
global ipFaceWireframeColourMode
global ipFaceWireframeDensity
global nmNone
global nmByElement
global nmByProperty
global nmByPropertyName
global nmByID
global dmLine
global dmSection
global dmSolid
global dmSlice
global omOutlineOn
global omOutlineOff
global omOutlineFacet
global fmPropertyColour
global fmGroupColour
global fmGlobalColour
global fmPropertyWireframe
global fmGroupWireframe
global fmOutlineWireframe
global fmOrientation
global cmPropertyColour
global cmGroupColour
global cmFaceColour
global cmFixedColour
global cmLoadPathTemplateColour
global cmLoadPathGroupColour
global cmLoadPathColour
global cmLoadPathGlobalColour
global esThinEdge
global esThickEdge
global wsDepthShaded
global wsConstantColour
global syDot1
global syDot2
global syDot3
global syDot4
global sySquare1
global sySquare2
global syDisk1
global syDisk2
global syCircle1
global syCircle2
global syCircle3
global sy3D1
global sy3D2
global sy3D3
global ctBeamNone
global ctBeamLength
global ctBeamAxis1
global ctBeamAxis2
global ctBeamAxis3
global ctBeamEA
global ctBeamEI11
global ctBeamEI22
global ctBeamGJ
global ctBeamEAFactor
global ctBeamEI11Factor
global ctBeamEI22Factor
global ctBeamGJFactor
global ctBeamOffset1
global ctBeamOffset2
global ctBeamStiffnessFactor1
global ctBeamStiffnessFactor2
global ctBeamStiffnessFactor3
global ctBeamStiffnessFactor4
global ctBeamStiffnessFactor5
global ctBeamStiffnessFactor6
global ctBeamMassFactor
global ctBeamSupport1
global ctBeamSupport2
global ctBeamTemperature
global ctBeamPreTension
global ctBeamPreStrain
global ctBeamTempGradient1
global ctBeamTempGradient2
global ctBeamPipePressureIn
global ctBeamPipePressureOut
global ctBeamPipeTempIn
global ctBeamPipeTempOut
global ctBeamConvectionCoeff
global ctBeamConvectionAmbient
global ctBeamRadiationCoeff
global ctBeamRadiationAmbient
global ctBeamHeatFlux
global ctBeamHeatSource
global ctBeamAgeAtFirstLoading
global ctPlateNone
global ctPlateAspectRatioMin
global ctPlateAspectRatioMax
global ctPlateWarping
global ctPlateInternalAngle
global ctPlateInternalAngleRatio
global ctPlateDiscreteThicknessM
global ctPlateContinuousThicknessM
global ctPlateDiscreteThicknessB
global ctPlateContinuousThicknessB
global ctPlateOffset
global ctPlateArea
global ctPlateAxis1
global ctPlateAxis2
global ctPlateAxis3
global ctPlateTemperature
global ctPlateEdgeSupport
global ctPlateFaceSupport
global ctPlatePreStressX
global ctPlatePreStressY
global ctPlatePresStressZ
global ctPlatePreStressMagnitude
global ctPlatePreStrainX
global ctPlatePreStrainY
global ctPlatePreStrainZ
global ctPlatePreStrainMagnitude
global ctPlateTempGradient
global ctPlateEdgePressure
global ctPlateEdgeShear
global ctPlateEdgeNormalShear
global ctPlatePressureNormal
global ctPlatePressureGlobal
global ctPlatePressureGlobalX
global ctPlatePressureGlobalY
global ctPlatePressureGlobalZ
global ctPlateFaceShearX
global ctPlateFaceShearY
global ctPlateFaceShearMagnitude
global ctPlateNSMass
global ctPlateDynamicFactor
global ctPlateConvectionCoeff
global ctPlateConvectionAmbient
global ctPlateRadiationCoeff
global ctPlateRadiationAmbient
global ctPlateHeatFlux
global ctPlateConvectionCoeffZPlus
global ctPlateConvectionCoeffZMinus
global ctPlateConvectionAmbientZPlus
global ctPlateConvectionAmbientZMinus
global ctPlateRadiationCoeffZPlus
global ctPlateRadiationCoeffZMinus
global ctPlateRadiationAmbientZPlus
global ctPlateRadiationAmbientZMinus
global ctPlateHeatSource
global ctPlateSoilStressSV
global ctPlateSoilStressKO
global ctPlateSoilStressSH
global ctPlateSoilRatioOCR
global ctPlateSoilRatioEO
global ctPlateAgeAtFirstLoading
global ctBrickNone
global ctBrickAspectRatioMin
global ctBrickAspectRatioMax
global ctBrickVolume
global ctBrickDeterminant
global ctBrickInternalAngle
global ctBrickMixedProduct
global ctBrickDihedral
global ctBrickAxis1
global ctBrickAxis2
global ctBrickAxis3
global ctBrickTemperature
global ctBrickSupport
global ctBrickPreStressX
global ctBrickPreStressY
global ctBrickPreStressZ
global ctBrickPreStressMagnitude
global ctBrickPreStrainX
global ctBrickPreStrainY
global ctBrickPreStrainZ
global ctBrickPreStrainMagnitude
global ctBrickNormalPressure
global ctBrickGlobalPressure
global ctBrickGlobalPressureX
global ctBrickGlobalPressureY
global ctBrickGlobalPressureZ
global ctBrickShearX
global ctBrickShearY
global ctBrickShearMagnitude
global ctBrickNSMass
global ctBrickDynamicFactor
global ctBrickConvectionCoeff
global ctBrickConvectionAmbient
global ctBrickRaditionCoeff
global ctBrickRadiationAmbient
global ctBrickHeatFlux
global ctBrickHeatSource
global ctBrickSoilStressSV
global ctBrickSoilStressKO
global ctBrickSoilStressSH
global ctBrickSoilRatioOCR
global ctBrickSoilRatioEO
global ctBrickAgeAtFirstLoading
global rtAsNone
global rtAsContour
global rtAsDiagram
global rtAsVector
global icDispC
global icVelC
global icAccC
global icPhaseC
global icReactC
global icTempC
global icNodeForceC
global icNodeFluxC
global icBeamForceC
global icBeamStrainC
global icBeamStressC
global icBeamCreepStrainC
global icBeamEnergyC
global icBeamFluxC
global icBeamTGradC
global icPlateForceC
global icPlateMomentC
global icPlateStressC
global icPlateStrainC
global icPlateCurvatureC
global icPlateCreepStrainC
global icPlateEnergyC
global icPlateFluxC
global icPlateTGradC
global icBrickStressC
global icBrickStrainC
global icBrickCreepStrainC
global icBrickEnergyC
global icBrickFluxC
global icBrickTGradC
global vtVectorComponent
global vtVectorTranslationMag
global vtVectorRotationMag
global ipResultType
global ipResultQuantity
global ipResultAxis
global ipResultComponent
global ipResultSurface
global ipVectorStyle
global ipDiagram1
global ipDiagram2
global ipDiagram3
global ipDiagram4
global ipDiagram5
global ipDiagram6
global ipVector1
global ipVector2
global ipVector3
global ipVector4
global ipVector5
global ipVector6
global ipRadian
global ipDegree
global ipResOptsBeamEnvelope
global ipResOptsRotationUnit
global ipResOptsHRADisplacement
global ipResOptsHRAVelocity
global ipResOptsHRAAcceleration
global ipResOptsStageDisplacement
global ipResOptsStrainUnit
global suUnit
global suPercent
global suMicro
global hrRelative
global hrTotal
global sdBirthStage
global sdInitial
global bePrincipal
global beLocal
global ipToolOptsElementTol
global ipToolOptsGeometryAccuracy
global ipToolOptsGeometryFeatureLength
global ipToolOptsElementTolType
global ipToolOptsGeometryAccuracyType
global ipToolOptsGeometryFeatureType
global ipToolOptsZipMesh
global ipToolOptsNodeCoordinate
global ipToolOptsNodeAttributeKeep
global ipToolOptsAllowZeroLengthLinks
global ipToolOptsAllowZeroLengthBeams
global ipToolOptsAllowSameProperty
global ipToolOptsCompatibleTriangle
global ipToolOptsSubdivideBeams
global ipToolOptsPlateAxisAlign
global ipToolOptsCopyMode
global ipToolOptsAutoCreateProperties
global zmAsNeeded
global zmOnSave
global zmOnRequest
global cmRoot
global cmSibling
global paCentroid
global paCurvilinear
global axLocalX
global axLocalY
global axPrincipal1
global axPrincipal2
global axBeamPrincipal
global axBeamLocal
global btSymm
global btTop
global btBottom
global plBeamPreTension
global plBeamPreStrain
global plPlatePreStress
global plPlatePreStrain
global plBrickPreStress
global plBrickPreStrain
global alRigid
global alFlexible
global alDirect
global alMoment
global alPinned
global ipConvection
global ipRadiation
global ipAmbient
global ltWilson
global ltNewmark
global stResponse
global stPSD
global rsAuto
global rsAbsolute
global stFullSystem
global stSuperposition
global ipDoEnds
global ipDoEdges
global ipDoFaces
global ipSelectedOnly
global ipDeleteExisting
global ipAllBrickFaces
global ipAngleDelta
global mrElementForce
global mrInertiaForce
global icAppliedVectors
global icNodalVelocity
global icFromFile
global ttNodalTemp
global ttFromFile
global etLimitEnvelopeAbs
global etLimitEnvelopeMin
global etLimitEnvelopeMax
global etCombEnvelopeMin
global etCombEnvelopeMax
global etFactEnvelopeMin
global etFactEnvelopeMax
global esCombEnvelopeOn
global esCombEnvelopeOff
global esCombEnvelopeCheck
global stExclusiveOR
global stExclusiveAND
global fuNone
global fuDispResponse
global fuVelResponse
global fuAccelResponse
global fuDispPSD
global fuVelPSD
global fuAccelPSD
global mtElastic
global mtPlastic
global htIsotropic
global htKinematic
global htTakeda
global ipSpringAxialStiff
global ipSpringLateralStiff
global ipSpringTorsionStiff
global ipSpringAxialDamp
global ipSpringLateralDamp
global ipSpringTorsionDamp
global ipSpringMass
global ipTrussIncludeTorsion
global ipCableSegments
global ipCutoffTension
global ipCutoffCompression
global cfElastic
global cfPlastic
global cyRectangular
global cyElliptical
global ipPlyWeaveType
global wtPlyUniDirectional
global wtPlyBiDirectional
global wtPlyTriDirectional
global wtPlyQuasiIsotropic
global ipPlyModulus1
global ipPlyModulus2
global ipPlyPoisson
global ipPlyShear12
global ipPlyShear13
global ipPlyShear23
global ipPlyAlpha1
global ipPlyAlpha2
global ipPlyDensity
global ipPlyThickness
global ipPlyS1Tension
global ipPlyS2Tension
global ipPlyS1Compression
global ipPlyS2Compression
global ipPlySShear
global ipPlyE1Tension
global ipPlyE2Tension
global ipPlyE1Compression
global ipPlyE2Compression
global ipPlyEShear
global ipPlyInterLaminaShear
global ipLaminateViscosity
global ipLaminateDampingRatio
global ipLaminateConductivity1
global ipLaminateConductivity2
global ipLaminateSpecificHeat
global ipLaminateDensity
global ipLaminateAlphax
global ipLaminateAlphay
global ipLaminateAlphaxy
global ipLaminateBetax
global ipLaminateBetay
global ipLaminateBetaxy
global ipLaminateModulusx
global ipLaminateModulusy
global ipLaminateShearxy
global ipLaminatePoissonxy
global ipLaminatePoissonyx
global ipLaminateThickness
global ipLaminatePlyAngle
global ipLaminatePlyThickness
global ipLaminateIgnoreCoupling
global ipLaminateAutoTransverseShear
global ipReoLayoutType
global ipReoColour13
global ipReoColour24
global ipReoCalcMethod
global ipReoConsiderMembrane
global ipReoAllowCompressionReo
global crReoSymmetric
global crReoAntiSymmetric
global crReoSimplified
global crReoElastoPlasticIter
global ipReoDiam1
global ipReoDiam2
global ipReoDiam3
global ipReoDiam4
global ipReoCover1
global ipReoCover2
global ipReoSpacing1
global ipReoSpacing2
global ipReoSpacing3
global ipReoSpacing4
global ipReoConcreteModulus
global ipReoConcreteStrain
global ipReoConcreteStress
global ipReoConcretePhi
global ipReoConcreteGamma
global ipReoSteelModulus
global ipReoSteelStress
global ipReoSteelGamma
global ipReoSteelMinArea
global ipCreepHardeningType
global ipCreepHardeningCyclic
global crHardeningTime
global crHardeningStrain
global ipCreepHyberbolicAlpha
global ipCreepHyperbolicBeta
global ipCreepHyperbolicDelta
global ipCreepHyperbolicPhi
global ipCreepHyperbolicTimeTable
global ipCreepHyperbolicConstModulus
global ipCreepViscoTimeTable
global ipCreepViscoTempTable
global ipCreepViscoDamper
global ipCreepViscoStiffness
global cfCreepFunction
global cfRelaxationFunction
global crCreepShrinkageTable
global crCreepShrinkageFormula
global ipCreepShrinkageAlpha
global ipCreepShrinkageBeta
global ipCreepShrinkageDelta
global ipCreepShrinkageStrain
global ipIncludeCreepTemperature
global ipIncludeRateTemperature
global ipIncludeShrinkageTemperature
global ipCreepCAAge
global ipCreepTRefAge
global ipCreepCCCreep
global ipCreepTRefCreep
global ipCreepCAShrink
global ipCreepTRefShrink
global ipCreepIncludeCuring
global ipCreepCuringTimeTable
global ipCreepCuringType
global ctCuringRapid
global ctCuringNormal
global ctCuringSlow
global ipCreepCuringCT
global ipCreepCuringTRef
global ipCreepCuringT0
global ipStageMorph
global ipStageMovedFixedNodes
global ipStageRotateClusters
global reNodeDisplacement
global reNodeReaction
global ipBeamResponseSF1
global ipBeamResponseSF2
global ipBeamResponseAxial
global ipBeamResponseBM1
global ipBeamResponseBM2
global ipBeamResponseTorque
global rePlateForce
global rePlateMoment
global ipPipeFlexibility
global ipPipeFluidDensity
global ipPipeOuterDiameter
global ipPipeThickness
global ipConnectionShear1
global ipConnectionShear2
global ipConnectionAxial
global ipConnectionBend1
global ipConnectionBend2
global ipConnectionTorque
global ipBeamModulus
global ipBeamShear
global ipBeamPoisson
global ipBeamDensity
global ipBeamAlpha
global ipBeamViscosity
global ipBeamDampingRatio
global ipBeamConductivity
global ipBeamSpecificHeat
global ipPlateIsoModulus
global ipPlateIsoPoisson
global ipPlateIsoDensity
global ipPlateIsoAlpha
global ipPlateIsoViscosity
global ipPlateIsoDampingRatio
global ipPlateIsoConductivity
global ipPlateIsoSpecificHeat
global ipBrickIsoModulus
global ipBrickIsoPoisson
global ipBrickIsoDensity
global ipBrickIsoAlpha
global ipBrickIsoViscosity
global ipBrickIsoDampingRatio
global ipBrickIsoConductivity
global ipBrickIsoSpecificHeat
global ipPlateOrthoModulus1
global ipPlateOrthoModulus2
global ipPlateOrthoModulus3
global ipPlateOrthoShear12
global ipPlateOrthoShear23
global ipPlateOrthoShear31
global ipPlateOrthoPoisson12
global ipPlateOrthoPoisson23
global ipPlateOrthoPoisson31
global ipPlateOrthoDensity
global ipPlateOrthoAlpha1
global ipPlateOrthoAlpha2
global ipPlateOrthoAlpha3
global ipPlateOrthoViscosity
global ipPlateOrthoDampingRatio
global ipPlateOrthoConductivity1
global ipPlateOrthoConductivity2
global ipPlateOrthoSpecificHeat
global ipBrickOrthoModulus1
global ipBrickOrthoModulus2
global ipBrickOrthoModulus3
global ipBrickOrthoShear12
global ipBrickOrthoShear23
global ipBrickOrthoShear31
global ipBrickOrthoPoisson12
global ipBrickOrthoPoisson23
global ipBrickOrthoPoisson31
global ipBrickOrthoDensity
global ipBrickOrthoAlpha1
global ipBrickOrthoAlpha2
global ipBrickOrthoAlpha3
global ipBrickOrthoViscosity
global ipBrickOrthoDampingRatio
global ipBrickOrthoConductivity1
global ipBrickOrthoConductivity2
global ipBrickOrthoConductivity3
global ipBrickOrthoSpecificHeat
global ipPlateAnisoTransShear1
global ipPlateAnisoTransShear2
global ipPlateAnisoTransShear3
global ipPlateAnisoDensity
global ipPlateAnisoAlpha1
global ipPlateAnisoAlpha2
global ipPlateAnisoAlpha3
global ipPlateAnisoAlpha12
global ipPlateAnisoViscosity
global ipPlateAnisoDampingRatio
global ipPlateAnisoConductivity1
global ipPlateAnisoConductivity2
global ipPlateAnisoSpecificHeat
global ipPlateUserTransShearxz
global ipPlateUserTransShearyz
global ipPlateUserTransShearcz
global ipPlateUserDensity
global ipPlateUserAlphax
global ipPlateUserAlphay
global ipPlateUserAlphaxy
global ipPlateUserBetax
global ipPlateUserBetay
global ipPlateUserBetaxy
global ipPlateUserViscosity
global ipPlateUserDampingRatio
global ipPlateUserConductivity1
global ipPlateUserConductivity2
global ipPlateUserSpecificHeat
global ipBrickUserDensity
global ipBrickUserAlpha1
global ipBrickUserAlpha2
global ipBrickUserAlpha3
global ipBrickUserAlpha12
global ipBrickUserAlpha23
global ipBrickUserAlpha31
global ipBrickUserViscosity
global ipBrickUserDampingRatio
global ipBrickUserConductivity1
global ipBrickUserConductivity2
global ipBrickUserConductivity3
global ipBrickUserSpecificHeat
global ipSoilDCUsePoisson
global ipSoilDCSetLevel
global ipSoilDCModulusK
global ipSoilDCModulusKUR
global ipSoilDCModulusN
global ipSoilDCPoisson
global ipSoilDCBulkK
global ipSoilDCBulkM
global ipSoilDCFrictionAngle
global ipSoilDCDeltaAngle
global ipSoilDCCohesion
global ipSoilDCFailureRatio
global ipSoilDCFailureMod
global ipSoilDCReferenceP
global ipSoilDCDensity
global ipSoilDCHorizontalRatio
global ipSoilDCConductivity
global ipSoilDCSpecificHeat
global ipSoilDCFluidLevel
global ipSoilCCUsePoisson
global ipSoilCCDrainedState
global ipSoilCCUseOCR
global ipSoilCCSetLevel
global ipSoilCCCriticalStateLine
global ipSoilCCConsolidationLine
global ipSoilCCSwellingLine
global ipSoilCCDensity
global ipSoilCCPoisson
global ipSoilCCModulusG
global ipSoilCCModulusB
global ipSoilCCHorizontalRatio
global ipSoilCCER
global ipSoilCCPR
global ipSoilCCPC0
global ipSoilCCOCR
global ipSoilCCConductivity
global ipSoilCCSpecificHeat
global ipSoilCCFluidLevel
global ipSoilMCSetLevel
global ipSoilMCModulus
global ipSoilMCPoisson
global ipSoilMCDensity
global ipSoilMCHorizontalRatio
global ipSoilMCER
global ipSoilMCConductivity
global ipSoilMCSpecificHeat
global ipSoilMCFluidLevel
global ipSoilMCCohesion
global ipSoilMCFrictionAngle
global ipSoilDPSetLevel
global ipSoilDPModulus
global ipSoilDPPoisson
global ipSoilDPDensity
global ipSoilDPHorizontalRatio
global ipSoilDPER
global ipSoilDPConductivity
global ipSoilDPSpecificHeat
global ipSoilDPFluidLevel
global ipSoilDPCohesion
global ipSoilDPFrictionAngle
global ipSoilLSSetLevel
global ipSoilLSModulus
global ipSoilLSPoisson
global ipSoilLSDensity
global ipSoilLSHorizontalRatio
global ipSoilLSER
global ipSoilLSConductivity
global ipSoilLSSpecificHeat
global ipSoilLSFluidLevel
global ipFluidModulus
global ipFluidPenaltyParam
global ipFluidDensity
global ipFluidAlpha
global ipFluidViscosity
global ipFluidDampingRatio
global ipFluidConductivity
global ipFluidSpecificHeat
global ipFrictionAngle
global ipCohesion
global ipRubberBulk
global ipRubberDensity
global ipRubberAlpha
global ipRubberViscosity
global ipRubberDampingRatio
global ipRubberConductivity
global ipRubberSpecificHeat
global ipRubberConstC1
global ltLoadCase
global ltSeismicCase
global ltSpectralCase
global ipPolyToFaceEdgeTolerance
global ipPolyToFaceFaceID
global ipPolyToFaceGroupIndex
global ipPolyToFacePropertyNumber
global ipPolyToFaceDeleteBeams
global ipPolyToFaceKeepSelected
global ipBeamPropBeamType
global ipBeamPropSectionType
global ipBeamPropMirrorType
global ipBeamPropCompatibleTwist
global axUCS
global axLocal
global ipLPTColour
global ipLPTNumLanes
global ipLPTMultiLaneType
global lpAllSameFactors
global lpAllDifferentFactors
global ipLPTTolerance
global ipLPTMinLaneWidth
global ipLPTVehicleInstance
global ipLPTVehicleDirection
global lpVehicleSingleLane
global lpVehicleDoubleLane
global lpVehicleForward
global lpVehicleBackward
global ipLPTVehicleVelocity
global ipLPTVehicleStartTime
global ipLPTMobility
global ipLPTAxisSystem
global ipLPTAdjacency
global ipLPTCentrifugal
global lpPointForceMobilityGrouped
global lpPointForceMobilityFloating
global lpDistrForceMobilityGrouped
global lpDistrForceMobilityLeading
global lpDistrForceMobilityTrailing
global lpDistrForceMobilityFullLength
global lpDistrForceMobilityFloating
global lpAxisLocal
global lpAxisGlobal
global ipLPTLimitK1
global ipLPTLengthUnit
global ipLPTForceUnit
global ipLPTMinK1
global ipLPTMaxK1
global rfCombFactors
global rfCombSRSS
global ipLoadPathCase
global ipLoadPathTemplate
global ipLoadPathShape
global ipLoadPathSurface
global ipLoadPathTarget
global ipLoadPathDivisions
global lpShapeStraight
global lpShapeCurved
global lpShapeQuadratic
global lpSurfaceFlat
global lpSurfaceCurved
global ipAniParentHandle
global ipAniCase
global ipNumFrames
global ipAniWidth
global ipAniHeight
global ipAniType
global kAniSAF
global kAniEXE
global kAniAVI
global ipNodeResFileDX
global ipNodeResFileDY
global ipNodeResFileDZ
global ipNodeResFileRX
global ipNodeResFileRY
global ipNodeResFileRZ
global ipNodeResTemp
global ipBeamResFileSF1
global ipBeamResFileSF2
global ipBeamResFileAxial
global ipBeamResFileBM1
global ipBeamResFileBM2
global ipBeamResFileTorque
global kBeamResFileForceSize
global ipBeamResFileAxialStrain
global ipBeamResFileCurvature1
global ipBeamResFileCurvature2
global ipBeamResFileTwist
global kBeamResFileStrainSize
global ipBeamResFileFX
global ipBeamResFileFY
global ipBeamResFileFZ
global ipBeamResFileMX
global ipBeamResFileMY
global ipBeamResFileMZ
global kBeamResFileReactSize
global ipBeamResFileF
global ipBeamResFileG
global kBeamResFileFluxSize
global ipPlateShellResFileNxx
global ipPlateShellResFileNyy
global ipPlateShellResFileNxy
global ipPlateShellResFileMxx
global ipPlateShellResFileMyy
global ipPlateShellResFileMxy
global ipPlateShellResFileQxz
global ipPlateShellResFileQyz
global ipPlateShellResFileZMinusSxx
global ipPlateShellResFileZMinusSyy
global ipPlateShellResFileZMinusSxy
global ipPlateShellResFileMidPlaneSxx
global ipPlateShellResFileMidPlaneSyy
global ipPlateShellResFileMidPlaneSxy
global ipPlateShellResFileZPlusSxx
global ipPlateShellResFileZPlusSyy
global ipPlateShellResFileZPlusSxy
global kPlateShellResFileStressSize
global ipPlateShellResFileExx
global ipPlateShellResFileEyy
global ipPlateShellResFileExy
global ipPlateShellResFileEzz
global ipPlateShellResFileKxx
global ipPlateShellResFileKyy
global ipPlateShellResFileKxy
global ipPlateShellResFileTxz
global ipPlateShellResFileTyz
global ipPlateShellResFileStoredE
global ipPlateShellResFileSpentE
global kPlateShellResFileStrainSize
global ipPlate2DResFileSXX
global ipPlate2DResFileSYY
global ipPlate2DResFileSXY
global ipPlate2DResFileSZZ
global kPlate2DResFileStressSize
global ipPlate2DResFileEXX
global ipPlate2DResFileEYY
global ipPlate2DResFileEXY
global ipPlate2DResFileEZZ
global ipPlate2DResFileStoredE
global ipPlate2DResFileSpentE
global kPlate2DResFileStrainSize
global ipPlateAxiResFileSRR
global ipPlateAxiResFileSZZ
global ipPlateAxiResFileSTT
global ipPlateAxiResFileSRT
global kPlateAxiResFileStressSize
global ipPlateAxiResFileERR
global ipPlateAxiResFileEZZ
global ipPlateAxiResFileETT
global ipPlateAxiResFileERT
global ipPlateAxiResFileStoredE
global ipPlateAxiResFileSpentE
global kPlateAxiResFileStrainSize
global ipPlateResFileFX
global ipPlateResFileFY
global ipPlateResFileFZ
global ipPlateResFileMX
global ipPlateResFileMY
global ipPlateResFileMZ
global kPlateResFileReactSize
global ipPlateResFileFxx
global ipPlateResFileFyy
global ipPlateResFileGxx
global ipPlateResFileGyy
global kPlateResFileFluxSize
global ipBrickResFileSXX
global ipBrickResFileSYY
global ipBrickResFileSZZ
global ipBrickResFileSXY
global ipBrickResFileSYZ
global ipBrickResFileSZX
global kBrickResFileStressSize
global ipBrickResFileExx
global ipBrickResFileEyy
global ipBrickResFileEzz
global ipBrickResFileExy
global ipBrickResFileEyz
global ipBrickResFileEzx
global ipBrickResFileStoredE
global ipBrickResFileSpentE
global kBrickResFileStrainSize
global ipBrickResFileFX
global ipBrickResFileFY
global ipBrickResFileFZ
global kBrickResFileReactSize
global ipBrickResFileFXX
global ipBrickResFileFYY
global ipBrickResFileFZZ
global ipBrickResFileGXX
global ipBrickResFileGYY
global ipBrickResFileGZZ
global kBrickResFileFluxSize
global adPlanar
global adPlusZ
global adMinusZ
kMaxStrLen = 255;

% Array Limits
kMaxEntityTotals = 4;
kMaxElementNode = 20;
kMaxBeamResult = 4096;
kNumBeamSectionData = 20;
kNumMaterialData = 3;
kMaxAttributeDoubles = 12;
kMaxAttributeLogicals = 6;
kMaxAttributeLongint = 6;
kLastUnit = 6;

% Unit Positions
ipLENGTHU = 0;
ipFORCEU = 1;
ipSTRESSU = 2;
ipMASSU = 3;
ipTEMPERU = 4;
ipENERGYU = 5;

% Unit Types - LENGTH
luMETRE = 0;
luCENTIMETRE = 1;
luMILLIMETRE = 2;
luFOOT = 3;
luINCH = 4;

% Unit Types - FORCE
fuNEWTON = 0;
fuKILONEWTON = 1;
fuMEGANEWTON = 2;
fuKILOFORCE = 3;
fuPOUNDFORCE = 4;
fuTONNEFORCE = 5;
fuKIPFORCE = 6;

% Unit Types - STRESS
suPASCAL = 0;
suKILOPASCAL = 1;
suMEGAPASCAL = 2;
suKSCm = 3;
suPSI = 4;
suKSI = 5;
suPSF = 6;

% Unit Types - MASS
muKILOGRAM = 0;
muTONNE = 1;
muGRAM = 2;
muPOUND = 3;
muSLUG = 4;

% Unit Types - TEMPERATURE
tuCELSIUS = 0;
tuFAHRENHEIT = 1;
tuKELVIN = 2;

% Unit Types - ENERGY
euJOULE = 0;
euBTU = 1;
euFTLBF = 2;
euCALORIE = 3;

% Unit Types - TIME
tuMilliSec = 0;
tuSec = 1;
tuMin = 2;
tuHour = 3;
tuDay = 4;

% Entity Types
tyNULL = -1;
tyNODE = 0;
tyBEAM = 1;
tyPLATE = 2;
tyBRICK = 3;
tyLINK = 4;
tyVERTEX = 5;
tyGEOMETRYEDGE = 6;
tyGEOMETRYFACE = 7;
tyLOADPATH = 8;

% Link Types
ilMasterSlaveLink = 1;
ilSectorSymmetryLink = 2;
ilCouplingLink = 3;
ilPinnedLink = 4;
ilRigidLink = 5;
ilShrinkLink = 6;
ilTwoPointLink = 7;
ilAttachmentLink = 8;
ilMultiPointLink = 9;

% Master-Slave Link
msFree = 0;
msFix = 1;
msFixNegate = -1;

% Coupling, Attachment and Multi-Point Links
cpTranslational = 1;
cpRotational = 2;
cpBoth = 3;

% Rigid Link
rgPlaneXYZ = 0;
rgPlaneXY = 1;
rgPlaneYZ = 2;
rgPlaneZX = 3;

% 2-Point Link
ipTwoPointDOF1 = 0;
ipTwoPointDOF2 = 1;
ipTwoPointUCS1 = 2;
ipTwoPointUCS2 = 3;
ipTwoPointC0 = 0;
ipTwoPointC1 = 1;
ipTwoPointC2 = 2;

% Attachment Link
ipAttachmentElType = 0;
ipAttachmentElNum = 1;
ipAttachmentBrickFaceNum = 2;
ipAttachmentCouple = 3;

% Multi-Point Link
mpInterpolatedFactors = 1;
mpUserFactors = 2;

% Node Temperature Types
tReferenceTemperature = 0;
tFixedTemperature = 1;
tInitialTemperature = 2;
tTableTemperature = 3;

% Beam End Release Constants
kBeamEndRelReleased = 0;
kBeamEndRelFixed = 1;
kBeamEndRelPartial = 2;

% Property Types
ptBEAMPROP = 1;
ptPLATEPROP = 2;
ptBRICKPROP = 3;
ptPLYPROP = 4;

% Property Totals
ipBeamPropTotal = 0;
ipPlatePropTotal = 1;
ipBrickPropTotal = 2;
ipPlyPropTotal = 3;

% Alpha Temperature Types
kIntegratedAlpha = 0;
kInstantAlpha = 1;

% Sampling Positions
AtCentroid = 0;
AtGaussPoints = 1;
AtNodesAverageNever = 2;
AtNodesAverageAll = 3;
AtNodesAverageSame = 4;

% Beam Types
kBeamTypeNull = 0;
kBeamTypeSpring = 1;
kBeamTypeCable = 2;
kBeamTypeTruss = 3;
kBeamTypeCutoff = 4;
kBeamTypeContact = 5;
kBeamTypeBeam = 6;
kBeamTypeUser = 7;
kBeamTypePipe = 8;
kBeamTypeConnection = 9;

% Contact Types
kZeroGapContact = 0;
kNormalContact = 1;
kTensionContact = 2;
kTakeupContact = 3;

% Contact Sub Types
kTensionTakeup = 0;
kCompressionTakeup = 1;

% Cutoff Types
kBrittleGap = 0;
kDuctileGap = 1;

% Contact Parameters Positions - Integers
ipContactType = 0;
ipDynamicStiffness = 1;
ipUseInFirstIteration = 2;
ipUpdateDirection = 3;
ipContactSubType = 4;
ipFrictionYieldType = 5;
ipFrictionModel = 6;

% Contact Parameters Positions - Doubles
ipContactStiffness = 0;
ipFrictionC1 = 1;
ipFrictionC2 = 2;
ipContactMaxTension = 3;

% CutoffBar Parameter Posistions
ipCutoffType = 0;
ipKeepMass = 1;

% Library Types
lbMaterial = 0;
lbBeamSection = 1;
lbComposite = 2;
lbReinforcementLayout = 3;
lbCreepDefinition = 4;
lbLoadPathTemplate = 5;

% Beam Section Types
kNullSection = 0;
kCircularSolid = 1;
kCircularHollow = 2;
kSquareSolid = 3;
kSquareHollow = 4;
kLipChannel = 5;
kTopHatChannel = 6;
kISection = 7;
kTSection = 8;
kLSection = 9;
kZSection = 10;
kUserSection = 11;
kTrapezoidSolid = 12;
kTrapezoidHollow = 13;
kTriangleSolid = 14;
kTriangleHollow = 15;
kCruciform = 16;

% Beam Mirror Types
kMirrorNone = 0;
kMirrorTop = 1;
kMirrorBot = 2;
kMirrorLeft = 3;
kMirrorRight = 4;
kMirrorLeftAndTop = 5;
kMirrorLeftAndBot = 6;
kMirrorRightAndTop = 7;
kMirrorRightAndBot = 8;
kMirrorLeftTopOnly = 9;
kMirrorLeftBotOnly = 10;
kMirrorRightTopOnly = 11;
kMirrorRightBotOnly = 12;

% Beam Section Positions
ipAREA = 0;
ipI11 = 1;
ipI22 = 2;
ipJ = 3;
ipSL1 = 4;
ipSL2 = 5;
ipSA1 = 6;
ipSA2 = 7;
ipXBAR = 8;
ipYBAR = 9;
ipANGLE = 10;
ipD1 = 11;
ipD2 = 12;
ipD3 = 13;
ipT1 = 14;
ipT2 = 15;
ipT3 = 16;
ipGapA = 17;
ipGapB = 18;

% Beam Load Types
kMaxDLPerBeam = 64;
kConstantDL = 0;
kLinearDL = 1;
kTriangularDL = 2;
kThreePoint0DL = 3;
kThreePoint1DL = 4;
kTrapezoidalDL = 5;

% Plate Load Patch Types
ptAuto4 = 0;
ptAuto3 = 1;
ptAuto2 = 2;
ptAuto1 = 3;
ptAngleSplit = 4;
ptManual = 5;

% Plate Types
kPlateTypeNull = 0;
kPlateTypePlaneStress = 1;
kPlateTypePlaneStrain = 2;
kPlateTypeAxisymmetric = 3;
kPlateTypePlateShell = 4;
kPlateTypeShearPanel = 5;
kPlateTypeMembrane = 6;
kPlateTypeLoadPatch = 7;

% Geometry Surface Types
suPlane = 0;
suSphere = 1;
suTorus = 2;
suCone = 3;
suBSpline = 4;
suRotSur = 5;
suPipeSur = 6;
suSumSur = 7;
suTabCyl = 8;
suRuleSur = 9;
suCubicSpline = 10;

% Plate Section Positions
ipTHICKM = 0;
ipTHICKB = 1;

% Material Types
kMaterialTypeNull = 0;
kMaterialTypeIsotropic = 1;
kMaterialTypeOrthotropic = 2;
kMaterialTypeAnisotropic = 3;
kMaterialTypeRubber = 4;
kMaterialTypeSoil = 5;
kMaterialTypeLaminate = 6;
kMaterialTypeUserDefined = 7;
kMaterialTypePly = 8;
kMaterialTypeFluid = 10;

% Yield Criteria
ycTresca = 0;
ycVonMises = 1;
ycMaxStress = 2;
ycMohrCoulomb = 3;
ycDruckerPrager = 4;

% Nonlinear Types
ntNonlinElastic = 0;
ntElastoPlastic = 1;

% Rubber Types
kNeoHookean = 1;
kMooneyRivlin = 2;
kGeneralisedMooneyRivlin = 3;
kOgden = 4;

% Material Positions
ipModulus = 0;
ipPoisson = 1;
ipDensity = 2;

% Node Result Types - Old convention
kNodeDisp = 1;
kNodeVel = 2;
kNodeAcc = 3;
kNodePhase = 4;
kNodeReact = 5;
kNodeTemp = 6;
kNodeFlux = 7;
kNodeInfluence = 1;

% Node Result Types
rtNodeDisp = 1;
rtNodeVel = 2;
rtNodeAcc = 3;
rtNodePhase = 4;
rtNodeReact = 5;
rtNodeTemp = 6;
rtNodeFlux = 7;
rtNodeInfluence = 1;

% Beam Result Types
rtBeamForce = 1;
rtBeamStrain = 2;
rtBeamStress = 3;
rtBeamTRelease = 4;
rtBeamRRelease = 5;
rtBeamCableXYZ = 6;
rtBeamFlux = 8;
rtBeamGradient = 9;
rtBeamCreepStrain = 10;
rtBeamEnergy = 11;
rtBeamDisp = 12;
rtBeamNodeReact = 13;

% Beam Result Quantities - BEAMFORCE
ipSF1 = 0;
ipBM1 = 1;
ipSF2 = 2;
ipBM2 = 3;
ipAxialF = 4;
ipTorque = 5;

% Beam Result Quantities - BEAMSTRESS
ipMinFibreStress = 0;
ipMaxFibreStress = 1;
ipMaxShearStress1 = 2;
ipMaxShearStress2 = 3;
ipAvShearStress1 = 4;
ipAvShearStress2 = 5;
ipTorqueStress = 6;
ipMinPrincipalStress = 7;
ipMaxPrincipalStress = 8;
ipMinPipeHoopStress = 9;
ipMaxPipeHoopStress = 10;
ipMinAxialStress = 11;
ipMaxAxialStress = 12;
ipMinBendingStress1 = 13;
ipMaxBendingStress1 = 14;
ipMinBendingStress2 = 15;
ipMaxBendingStress2 = 16;
ipYieldRatio = 17;

% Beam Result Quantities - BEAMFLUXGRAD
ipBeamFlux = 0;
ipBeamTempGradient = 1;

% Beam Result Quantities - BEAMSTRAIN
ipAxialStrain = 0;
ipCurvature1 = 1;
ipCurvature2 = 2;
ipTwist = 3;

% Beam Result Quantities - BEAMRELEASE
ipRelEnd1Dir1 = 0;
ipRelEnd1Dir2 = 1;
ipRelEnd1Dir3 = 2;
ipRelEnd2Dir1 = 3;
ipRelEnd2Dir2 = 4;
ipRelEnd2Dir3 = 5;

% Beam Result Quantities - BEAMENERGY
ipBeamEnergyStored = 0;
ipBeamEnergySpent = 1;

% Plate Result Types
rtPlateStress = 1;
rtPlateStrain = 2;
rtPlateEnergy = 3;
rtPlateForce = 4;
rtPlateMoment = 5;
rtPlateCurvature = 6;
rtPlatePlyStress = 7;
rtPlatePlyStrain = 8;
rtPlatePlyReserve = 9;
rtPlateFlux = 10;
rtPlateGradient = 11;
rtPlateReoDesign = 12;
rtPlateCreepStrain = 13;
rtPlateSoil = 14;
rtPlateUser = 15;
rtPlateNodeReact = 16;
rtPlateNodeDisp = 17;

% Plate Surface Definition
psPlateMidPlane = 0;
psPlateZMinus = 1;
psPlateZPlus = 2;

% Brick Result Types
rtBrickStress = 1;
rtBrickStrain = 2;
rtBrickEnergy = 3;
rtBrickFlux = 4;
rtBrickGradient = 5;
rtBrickCreepStrain = 6;
rtBrickSoil = 7;
rtBrickUser = 8;
rtBrickNodeReact = 9;
rtBrickNodeDisp = 10;

% Beam Result Sub Types
stBeamLocal = 0;
stBeamPrincipal = -1;
stBeamGlobal = -2;

% Plate Result Sub Types
stPlateLocal = 0;
stPlateGlobal = -1;
stPlateCombined = -2;
stPlateSupport = -3;
stPlateDevLocal = -4;
stPlateDevGlobal = -5;
stPlateDevCombined = -6;

% Brick Result Sub Types
stBrickLocal = 0;
stBrickGlobal = -1;
stBrickCombined = -2;
stBrickSupport = -3;
stBrickDevLocal = -4;
stBrickDevGlobal = -5;
stBrickDevCombined = -6;

% Plate/Brick Result Sub Types (Undocumented)
stLOCAL = 0;
stGLOBAL = 1;
stUCS = 2;
stCOMBINED = 3;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN, PLATEMOMENT, PLATECURVATURE, PLATEFORCE results for STLOCAL
ipPlateLocalxx = 0;
ipPlateLocalyy = 1;
ipPlateLocalzz = 2;
ipPlateLocalxy = 3;
ipPlateLocalyz = 4;
ipPlateLocalzx = 5;
ipPlateLocalxz = 5;
ipPlateLocalMean = 0;
ipPlateLocalDevxx = 1;
ipPlateLocalDevyy = 2;
ipPlateEdgeSupport = 0;
ipPlateFaceSupport = 1;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN, PLATEMOMENT, PLATECURVATURE, PLATEFORCE results for STGLOBAL (NOT AXISYMMETRIC)
ipPlateGlobalXX = 0;
ipPlateGlobalYY = 1;
ipPlateGlobalZZ = 2;
ipPlateGlobalXY = 3;
ipPlateGlobalYZ = 4;
ipPlateGlobalZX = 5;
ipPlateGlobalMean = 0;
ipPlateGlobalDevXX = 1;
ipPlateGlobalDevYY = 2;
ipPlateGlobalDevZZ = 3;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN, PLATEMOMENT, PLATECURVATURE, PLATEFORCE results for STUCS
ipPlateUCSXX = 0;
ipPlateUCSYY = 1;
ipPlateUCSZZ = 2;
ipPlateUCSXY = 3;
ipPlateUCSYZ = 4;
ipPlateUCSZX = 5;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN, PLATEFORCE, PLATEMOMENT, PLATECURVATURE results for STCOMBINED (NOT AXISYMMETRIC)
ipPlateCombPrincipal11 = 0;
ipPlateCombPrincipal22 = 1;
ipPlateCombPrincipalAngle = 3;
ipPlateCombVonMises = 4;
ipPlateCombTresca = 5;
ipPlateCombMohrCoulomb = 6;
ipPlateCombDruckerPrager = 7;
ipPlateCombPlasticStrain = 6;
ipPlateCombCreepEffRate = 6;
ipPlateCombCreepShrinkage = 7;
ipPlateCombYieldIndex = 8;
ipPlateCombMean = 0;
ipPlateCombDev11 = 1;
ipPlateCombDev22 = 2;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN results for STGLOBAL (AXISYMMETRIC)
ipPlateAxiGlobalRR = 0;
ipPlateAxiGlobalZZ = 1;
ipPlateAxiGlobalTT = 2;
ipPlateAxiGlobalRZ = 3;
ipPlateAxiGlobalMean = 0;
ipPlateAxiGlobalDevRR = 1;
ipPlateAxiGlobalDevZZ = 2;
ipPlateAxiGlobalDevTT = 3;

% PLATESTRESS, PLATESTRAIN, PLATECREEPSTRAIN results for STCOMBINED (AXISYMMETRIC)
ipPlateAxiCombPrincipal11 = 0;
ipPlateAxiCombPrincipal22 = 1;
ipPlateAxiCombPrincipal33 = 2;
ipPlateAxiCombVonMises = 4;
ipPlateAxiCombTresca = 5;
ipPlateAxiCombMohrCoulomb = 6;
ipPlateAxiCombDruckerPrager = 7;
ipPlateAxiCombPlasticStrain = 5;
ipPlateAxiCombCreepEffRate = 5;
ipPlateAxiCombCreepShrinkage = 6;
ipPlateAxiCombYieldIndex = 8;
ipPlateAxiCombMean = 0;
ipPlateAxiCombDev11 = 1;
ipPlateAxiCombDev22 = 2;
ipPlateAxiCombDev33 = 3;

% PLATEPLYSTRESS
ipPlyStress11 = 0;
ipPlyStress22 = 1;
ipPlyStress12 = 3;
ipPlyILSx = 4;
ipPlyILSy = 5;

% PLATEPLYSTRAIN
ipPlyStrain11 = 0;
ipPlyStrain22 = 1;
ipPlyStrain12 = 3;

% PLATEPLYRESERVE
ipPlyMaxStress = 0;
ipPlyMaxStrain = 1;
ipPlyTsaiHill = 2;
ipPlyModTsaiWu = 3;
ipPlyHoffman = 4;
ipPlyInterlam = 5;

% PLATESOIL
ipPlateSoilTotalPorePressure = 0;
ipPlateSoilExcessPorePressure = 1;
ipPlateSoilOCRIndex = 2;
ipPlateSoilStateIndex = 3;
ipPlateSoilVoidRatio = 4;

% PLATEFLUX, PLATEGRADIENT results for STLOCAL
ipPlateFluxLocalx = 0;
ipPlateFluxLocaly = 1;
ipPlateFluxLocalxy = 2;

% PLATEFLUX, PLATEGRADIENT results for STGLOBAL
ipPlateFluxGlobalX = 0;
ipPlateFluxGlobalY = 1;
ipPlateFluxGlobalZ = 2;
ipPlateFluxGlobalXY = 3;
ipPlateFluxGlobalYZ = 4;
ipPlateFluxGlobalZX = 5;
ipPlateFluxGlobalSRSS = 6;

% PLATEFLUX, PLATEGRADIENT results for STUCS
ipPlateFluxUCSX = 0;
ipPlateFluxUCSY = 1;
ipPlateFluxUCSZ = 2;
ipPlateFluxUCSXY = 3;
ipPlateFluxUCSYZ = 4;
ipPlateFluxUCSZX = 5;
ipPlateFluxUCSSRSS = 6;

% PLATEREODESIGN
ipPlateRCWoodArmerMoment = 0;
ipPlateRCWoodArmerForce = 1;
ipPlateRCSteelArea = 2;
ipPlateRCSteelAreaLessBase = 3;
ipPlateRCSteelStress = 4;
ipPlateRCConcreteStrain = 5;
ipPlateRCBlockRatio = 6;

% PLATENODEREACT
ipPlateNodeReactFX = 0;
ipPlateNodeReactFY = 1;
ipPlateNodeReactFZ = 2;
ipPlateNodeReactMX = 3;
ipPlateNodeReactMY = 4;
ipPlateNodeReactMZ = 5;

% PLATEENERGY
ipPlateEnergyStored = 0;
ipPlateEnergySpent = 1;

% BRICKSTRESS, BRICKSTRAIN, BRICKCREEPSTRAIN results for STLOCAL
ipBrickLocalxx = 0;
ipBrickLocalyy = 1;
ipBrickLocalzz = 2;
ipBrickLocalxy = 3;
ipBrickLocalyz = 4;
ipBrickLocalzx = 5;
ipBrickLocalMean = 0;
ipBrickLocalDevxx = 1;
ipBrickLocalDevyy = 2;
ipBrickLocalDevzz = 3;
ipBrickFaceSupport = 0;

% BRICKSTRESS, BRICKSTRAIN, BRICKCREEPSTRAIN results for STGLOBAL
ipBrickGlobalXX = 0;
ipBrickGlobalYY = 1;
ipBrickGlobalZZ = 2;
ipBrickGlobalXY = 3;
ipBrickGlobalYZ = 4;
ipBrickGlobalZX = 5;
ipBrickGlobalMean = 0;
ipBrickGlobalDevXX = 1;
ipBrickGlobalDevYY = 2;
ipBrickGlobalDevZZ = 3;

% BRICKSTRESS, BRICKSTRAIN, BRICKCREEPSTRAIN results for STUCS
ipBrickUCSXX = 0;
ipBrickUCSYY = 1;
ipBrickUCSZZ = 2;
ipBrickUCSXY = 3;
ipBrickUCSYZ = 4;
ipBrickUCSZX = 5;

% BRICKSTRESS, BRICKSTRAIN, BRICKCREEPSTRAIN results for STCOMBINED
ipBrickCombPrincipal11 = 0;
ipBrickCombPrincipal22 = 1;
ipBrickCombPrincipal33 = 2;
ipBrickCombVonMises = 3;
ipBrickCombTresca = 4;
ipBrickCombMohrCoulomb = 5;
ipBrickCombDruckerPrager = 6;
ipBrickCombPlasticStrain = 6;
ipBrickCombCreepEffRate = 6;
ipBrickCombCreepShrinkage = 7;
ipBrickCombYieldIndex = 8;
ipBrickCombMean = 0;
ipBrickCombDev11 = 1;
ipBrickCombDev22 = 2;
ipBrickCombDev33 = 3;

% BRICKSOIL
ipBrickSoilTotalPorePressure = 0;
ipBrickSoilExcessPorePressure = 1;
ipBrickSoilOCRIndex = 2;
ipBrickSoilStateIndex = 3;
ipBrickSoilVoidRatio = 4;

% BRICKFLUX, BRICKGRADIENT results for STLOCAL
ipBrickFluxLocalx = 0;
ipBrickFluxLocaly = 1;
ipBrickFluxLocalz = 2;
ipBrickFluxLocalxy = 3;
ipBrickFluxLocalyz = 4;
ipBrickFluxLocalzx = 5;
ipBrickFluxLocalRMS = 6;

% BRICKFLUX, BRICKGRADIENT results for STGLOBAL
ipBrickFluxGlobalX = 0;
ipBrickFluxGlobalY = 1;
ipBrickFluxGlobalZ = 2;
ipBrickFluxGlobalXY = 3;
ipBrickFluxGlobalYZ = 4;
ipBrickFluxGlobalZX = 5;
ipBrickFluxGlobalRMS = 6;

% BRICKFLUX, BRICKGRADIENT results for STUCS
ipBrickFluxUCSX = 0;
ipBrickFluxUCSY = 1;
ipBrickFluxUCSZ = 2;
ipBrickFluxUCSXY = 3;
ipBrickFluxUCSYZ = 4;
ipBrickFluxUCSZX = 5;
ipBrickFluxUCSRMS = 6;

% BRICKNODEREACT
ipBrickNodeReactFX = 0;
ipBrickNodeReactFY = 1;
ipBrickNodeReactFZ = 2;

% BRICKENERGY
ipBrickEnergyStored = 0;
ipBrickEnergySpent = 1;

% MODAL RESULTS NFA
ipFrequencyNFA = 0;
ipModalMassNFA = 1;
ipModalStiffNFA = 2;
ipModalDampNFA = 3;
ipModalTMassP1 = 4;
ipModalTMassP2 = 5;
ipModalTMassP3 = 6;
ipModalRMassP1 = 7;
ipModalRMassP2 = 8;
ipModalRMassP3 = 9;

% INERTIA RELIEF RESULTS
ipMassXIRA = 0;
ipMassYIRA = 1;
ipMassZIRA = 2;
ipXcIRA = 3;
ipYcIRA = 4;
ipZcIRA = 5;
ipAccXIRA = 6;
ipAccYIRA = 7;
ipAccZIRA = 8;
ipAngAccXIRA = 9;
ipAngAccYIRA = 10;
ipAngAccZIRA = 11;

% UCS Types
UCSCartesian = 0;
UCSCylindrical = 1;
UCSSpherical = 2;
UCSToroidal = 3;

% Matrix Types
mtCompliance = 1;
mtStiffness = 2;

% Node/Vertex Attribute Types
ATTRFreedom = 1;
ATTRForce = 2;
ATTRMoment = 3;
ATTRTemperature = 4;
ATTRMTranslation = 5;
ATTRMRotation = 6;
ATTRKTranslation = 7;
ATTRKRotation = 8;
ATTRDamping = 9;
ATTRNSMass = 10;
ATTRNodeInfluence = 11;
ATTRNodeHeatSource = 12;
ATTRNodeVelocity = 13;
ATTRNodeAcceleration = 14;

% Vertex Types
vtFree = 1;
vtFixed = 2;

% Beam Attribute Types
ATTRBeamAngle = 21;
ATTRBeamOffset = 22;
ATTRBeamTEndRelease = 23;
ATTRBeamREndRelease = 24;
ATTRBeamSupport = 25;
ATTRBeamPreTension = 26;
ATTRCableFreeLength = 27;
ATTRBeamDLL = 28;
ATTRBeamDLG = 29;
ATTRBeamCFL = 30;
ATTRBeamCFG = 31;
ATTRBeamCML = 32;
ATTRBeamCMG = 33;
ATTRBeamTempGradient = 34;
ATTRBeamConvection = 35;
ATTRBeamRadiation = 36;
ATTRBeamFlux = 37;
ATTRBeamHeatSource = 38;
ATTRBeamRadius = 39;
ATTRPipePressure = 40;
ATTRBeamNSMass = 41;
ATTRPipeTemperature = 42;
ATTRBeamDML = 44;
ATTRBeamStringGroup = 45;
ATTRBeamTaper = 92;
ATTRBeamInfluence = 93;
ATTRBeamSectionFactor = 94;
ATTRBeamCreepLoadingAge = 95;
ATTRBeamEndAttachment = 96;
ATTRBeamConnectionUCS = 97;
ATTRBeamStageProperty = 98;

% Plate/Edge/Face Attribute Types
ATTRPlateAngle = 51;
ATTRPlateOffset = 52;
ATTRPlatePreLoad = 53;
ATTRPlateFacePressure = 54;
ATTRPlateFaceShear = 55;
ATTRPlateEdgePressure = 56;
ATTRPlateEdgeShear = 57;
ATTRPlateEdgeNormalShear = 58;
ATTRPlateTempGradient = 59;
ATTRPlateEdgeSupport = 60;
ATTRPlateFaceSupport = 61;
ATTRPlateEdgeConvection = 62;
ATTRPlateEdgeRadiation = 63;
ATTRPlateFlux = 64;
ATTRPlateHeatSource = 65;
ATTRPlateGlobalPressure = 66;
ATTRPlateEdgeRelease = 67;
ATTRPlateThickness = 69;
ATTRPlateNSMass = 70;
ATTRLoadPatch = 71;
ATTRPlatePointForce = 99;
ATTRPlatePointMoment = 100;
ATTRPlateFaceConvection = 101;
ATTRPlateFaceRadiation = 102;
ATTRPlateInfluence = 103;
ATTRPlateSoilStress = 104;
ATTRPlateSoilRatio = 105;
ATTRPlateCreepLoadingAge = 106;
ATTRPlateEdgeAttachment = 107;
ATTRPlateFaceAttachment = 108;
ATTRPlateStageProperty = 109;

% Edge Types
etInterpolated = 0;
etNonInterpolated = 1;

% Plate/Face Global Pressure Projection Options
pfNone = 0;
pfProjResultant = 1;
pfProjComponents = 2;

% Brick Attribute Types
ATTRBrickPressure = 81;
ATTRBrickShear = 82;
ATTRBrickFaceFoundation = 83;
ATTRBrickConvection = 84;
ATTRBrickRadiation = 85;
ATTRBrickFlux = 86;
ATTRBrickHeatSource = 87;
ATTRBrickGlobalPressure = 88;
ATTRBrickNSMass = 89;
ATTRBrickLocalAxes = 90;
ATTRBrickPreLoad = 91;
ATTRBrickPointForce = 110;
ATTRBrickInfluence = 111;
ATTRBrickSoilStress = 112;
ATTRBrickSoilRatio = 113;
ATTRBrickCreepLoadingAge = 114;
ATTRBrickFaceAttachment = 115;
ATTRBrickStageProperty = 116;

% Titles
TITLEModel = 0;
TITLEProject = 1;
TITLEReference = 2;
TITLEAuthor = 3;
TITLECreated = 4;
TITLEModified = 5;

% Table Types
ttVsTime = 1;
ttVsTemperature = 2;
ttVsFrequency = 3;
ttStressStrain = 4;
ttForceDisplacement = 5;
ttMomentCurvature = 6;
ttMomentRotation = 8;
ttAccVsTime = 9;
ttForceVelocity = 10;
ttVsPosition = 11;
ttStrainTime = 12;

% Frequency Table Types
tyPeriod = 0;
tyFrequency = 1;

% Beam Prop Table Entries
ptBeamStiffModVsTemp = 1001;
ptBeamAlphaVsTemp = 1002;
ptBeamConductVsTemp = 1003;
ptBeamCpVsTemp = 1004;
ptBeamStiffModVsTime = 1005;
ptBeamConductVsTime = 1006;
ptSpringAxialVsDisp = 1007;
ptSpringTorqueVsTwist = 1008;
ptSpringAxialVsVelocity = 1009;
ptTrussAxialStressVsStrain = 1010;
ptBeamAxialStressVsStrain = 1011;
ptBeamMomentK1 = 1012;
ptBeamMomentK2 = 1013;
ptConnectionShear1 = 1014;
ptConnectionShear2 = 1015;
ptConnectionAxial = 1016;
ptConnectionBend1 = 1017;
ptConnectionBend2 = 1018;
ptConnectionTorque = 1019;
ptBeamYieldVsTemp = 1020;

% Plate Prop Table Entries
ptPlateModVsTemp = 2001;
ptPlateAlphaVsTemp = 2002;
ptPlateConductVsTemp = 2003;
ptPlateCpVsTemp = 2004;
ptPlateModVsTime = 2005;
ptPlateConductVsTime = 2006;
ptPlateStressVsStrain = 2007;
ptPlateYieldVsTemp = 2008;

% Brick Prop Table Entries
ptBrickModVsTemp = 3001;
ptBrickAlphaVsTemp = 3002;
ptBrickConductVsTemp = 3003;
ptBrickCpVsTemp = 3004;
ptBrickModVsTime = 3005;
ptBrickConductVsTime = 3006;
ptBrickStressVsStrain = 3007;
ptBrickYieldVsTemp = 3008;

% Creep Laws
clConcreteHyperbolic = 0;
clConcreteViscoChain = 1;
clConcreteUserDefined = 2;
clPrimaryPower = 3;
clSecondaryPower = 4;
clPrimarySecondaryPower = 5;
clSecondaryHyperbolic = 6;
clSecondaryExponential = 7;
clThetaProjection = 8;
clGenGraham = 9;
clGenBlackburn = 10;
clUserDefined = 11;

% Load Case Types
kNoInertia = 0;
kGravity = 1;
kAccelerations = 2;

% Freedom Case Types
kNormalFreedom = 0;
kFreeBodyInertiaRelief = 1;
kSingleSymmetryInertiaXY = 2;
kSingleSymmetryInertiaYZ = 3;
kSingleSymmetryInertiaZX = 4;
kDoubleSymmetryInertiaX = 5;
kDoubleSymmetryInertiaY = 6;
kDoubleSymmetryInertiaZ = 7;

% Global Load and Freedom Cases
ipRefTemp = 0;
ipGlobOrigX = 1;
ipGlobOrigY = 2;
ipGlobOrigZ = 3;
ipGlobAccX = 4;
ipGlobAccY = 5;
ipGlobAccZ = 6;
ipGlobAngVelX = 7;
ipGlobAngVelY = 8;
ipGlobAngVelZ = 9;
ipGlobAngAccX = 10;
ipGlobAngAccY = 11;
ipGlobAngAccZ = 12;

% Damping Types
dtNoDamping = 0;
dtRayleighDamping = 1;
dtModalDamping = 2;
dtViscousDamping = 3;

% Rayleigh Modes
rmSetFrequencies = 0;
rmSetAlphaBeta = 1;

% Entity Solver Result Types - HEAT
hrNodeFlux = 1;
hrBeamFlux = 2;
hrPlateFlux = 3;
hrBrickFlux = 4;

% Entity Solver Result Types - FREQUENCY
frBeamForcePattern = 5;
frBeamStrainPattern = 6;
frPlateStressPattern = 7;
frPlateStrainPattern = 8;
frBrickStressPattern = 9;
frBrickStrainPattern = 10;

% Entity Solver Result Types - STRUCTURAL
srNodeReaction = 11;
srNodeVelocity = 12;
srNodeAcceleration = 13;
srBeamForce = 14;
srBeamMNLStress = 15;
srBeamStrain = 16;
srPlateStress = 17;
srPlateStrain = 18;
srBrickStress = 19;
srBrickStrain = 20;
srElementNodeForce = 21;

% Solver Defaults - LOGICALS
spDoSturm = 1;
spNonlinearMaterial = 2;
spNonlinearGeometry = 4;
spAddKg = 6;
spCalcDampingRatios = 8;
spIncludeLinkReactions = 9;
spFullSystemTransient = 10;
spNonlinearHeat = 11;
spLumpedLoadBeam = 12;
spLumpedLoadPlate = 13;
spLumpedLoadBrick = 14;
spLumpedMassBeam = 15;
spLumpedMassPlate = 16;
spLumpedMassBrick = 17;
spForceDrillCheck = 18;
spSaveRestartFile = 20;
spSaveIntermediate = 21;
spExcludeMassX = 22;
spExcludeMassY = 23;
spExcludeMassZ = 24;
spSaveSRSSSpectral = 25;
spSaveCQCSpectral = 26;
spDoResidualsCheck = 27;
spSuppressAllSingularities = 28;
spSaveModalResults = 29;
spSpectralReactionAsInertia = 30;
spReducedLogFile = 31;
spIncludeRotationalMass = 32;
spIgnoreCompressiveBeamKg = 33;
spAutoScaleKg = 34;
spDynamicAutoStepping = 35;
spScaleSupports = 36;
spAutoShift = 37;
spSaveTableInsertedSteps = 38;
spSaveLastRestartStep = 39;
spAutoAssignPathDivisions = 40;

% Solver Defaults - INTEGERS
spTreeStartNumber = 1;
spNumFrequency = 2;
spNumBucklingModes = 3;
spMaxIterationEig = 4;
spMaxIterationNonlin = 5;
spNumBeamSlicesSpectral = 6;
spMaxConjugateGradientIter = 7;
spMaxNumWarnings = 8;
spFiniteStrainDefinition = 9;
spBeamLength = 10;
spFormStiffMatrix = 11;
spMaxUpdateInterval = 12;
spFormNonlinHeatStiffMatrix = 13;
spExpandWorkingSet = 14;
spMinNumViscoUnits = 15;
spMaxNumViscoUnits = 16;
spCurveFitTimeUnit = 17;
spStaticAutoStepping = 18;
spBeamKgType = 19;

% Solver Defaults - DOUBLES
spEigenTolerance = 1;
spFrequencyShift = 2;
spBucklingShift = 3;
spNonlinDispTolerance = 4;
spNonlinResidualTolerance = 5;
spTransientReferenceTemperature = 6;
spRelaxationFactor = 7;
spNonlinHeatTolerance = 8;
spMinimumTimeStep = 9;
spWilsonTheta = 10;
spNewmarkBeta = 11;
spGlobalZeroDiagonal = 12;
spConjugateGradientTol = 13;
spMinimumDimension = 14;
spMinimumInternalAngle = 15;
spZeroForce = 16;
spZeroDiagonal = 17;
spZeroContactFactor = 18;
spFrictionCutoffStrain = 19;
spZeroTranslation = 20;
spZeroRotation = 21;
spDrillStiffFactor = 22;
spMaxNormalsAngle = 24;
spMaximumRotation = 26;
spZeroDisplacement = 27;
spMaximumDispRatio = 28;
spMinimumLoadReductionFactor = 29;
spMaxDispChange = 30;
spMaxResidualChange = 31;
spZeroFrequency = 32;
spZeroBucklingEigen = 33;
spCurveFitTime = 34;
spSpacingBias = 35;
spTimeStepParam = 36;
spSlidingFrictionFactor = 37;
spMNLTangentRatio = 38;
spStickingFrictionFactor = 39;
spMinArcLengthFactor = 40;
spMaxFibreStrainInc = 41;

% Modal Load Types
mtBaseAcc = 0;
mtBaseVel = 1;
mtBaseDisp = 2;
mtAppliedLoad = 3;

% Solver Types
stSkyline = 0;
stSparse = 1;
stIterativePCG = 3;

% Solver Temperature Types
tdNone = 0;
tdCombined = 1;

% Harmonic Load Types
htVsFrequency = 0;
htVsTime = 1;

% Sort Types
rnNone = 0;
rnTree = 1;
rnGeometry = 2;
rnAMD = 3;

% Utility
ztAbsolute = 0;
ztRelative = 1;

% Boolean Types
btFalse = 0;
btTrue = 1;

% Error Codes
ERR7_InvalidRegionalSettings = -6;
ERR7_InvalidDLLsPresent = -5;
ERR7_APINotInitialised = -4;
ERR7_InvalidErrorCode = -3;
ERR7_APINotLicensed = -2;
ERR7_UnknownError = -1;
ERR7_NoError = 0;
ERR7_FileAlreadyOpen = 1;
ERR7_FileNotFound = 2;
ERR7_FileNotSt7 = 3;
ERR7_InvalidFileName = 4;
ERR7_FileIsNewer = 5;
ERR7_CannotReadFile = 6;
ERR7_InvalidScratchPath = 7;
ERR7_FileNotOpen = 8;
ERR7_ExceededTotal = 9;
ERR7_DataNotFound = 10;
ERR7_InvalidResultFile = 11;
ERR7_ResultFileNotOpen = 12;
ERR7_ExceededResultCase = 13;
ERR7_UnknownResultType = 14;
ERR7_UnknownResultLocation = 15;
ERR7_UnknownSurfaceLocation = 16;
ERR7_UnknownProperty = 17;
ERR7_InvalidEntity = 18;
ERR7_InvalidBeamPosition = 19;
ERR7_InvalidLoadCase = 20;
ERR7_InvalidFreedomCase = 21;
ERR7_UnknownTitle = 22;
ERR7_UnknownUCS = 23;
ERR7_TooManyBeamStations = 24;
ERR7_UnknownSubType = 25;
ERR7_GroupIdDoesNotExist = 26;
ERR7_InvalidFileUnit = 27;
ERR7_CannotSaveFile = 28;
ERR7_ResultFileIsOpen = 29;
ERR7_InvalidUnits = 30;
ERR7_InvalidEntityNodes = 31;
ERR7_InvalidUCSType = 32;
ERR7_InvalidUCSID = 33;
ERR7_UCSIDAlreadyExists = 34;
ERR7_CaseNameAlreadyExists = 35;
ERR7_InvalidEntityNumber = 36;
ERR7_InvalidBeamEnd = 37;
ERR7_InvalidBeamDir = 38;
ERR7_InvalidPlateEdge = 39;
ERR7_InvalidBrickFace = 40;
ERR7_InvalidBeamType = 41;
ERR7_InvalidPlateType = 42;
ERR7_InvalidMaterialType = 43;
ERR7_PropertyAlreadyExists = 44;
ERR7_InvalidBeamSectionType = 45;
ERR7_PropertyNotSpring = 46;
ERR7_PropertyNotCable = 47;
ERR7_PropertyNotTruss = 48;
ERR7_PropertyNotCutOffBar = 49;
ERR7_PropertyNotPointContact = 50;
ERR7_PropertyNotBeam = 51;
ERR7_PropertyNotPipe = 52;
ERR7_PropertyNotConnectionBeam = 53;
ERR7_InvalidSectionParameters = 54;
ERR7_PropertyNotUserDefinedBeam = 55;
ERR7_MaterialIsUserDefined = 56;
ERR7_MaterialNotIsotropic = 57;
ERR7_MaterialNotOrthotropic = 58;
ERR7_InvalidRubberModel = 59;
ERR7_MaterialNotRubber = 60;
ERR7_InvalidSectionProperties = 61;
ERR7_PlateDoesNotHaveThickness = 62;
ERR7_IncompatibleMaterialCombination = 63;
ERR7_UnknownSolver = 64;
ERR7_InvalidSolverMode = 65;
ERR7_InvalidMirrorOption = 66;
ERR7_SectionCannotBeMirrored = 67;
ERR7_InvalidTableType = 68;
ERR7_InvalidTableName = 69;
ERR7_TableNameAlreadyExists = 70;
ERR7_InvalidNumberOfEntries = 71;
ERR7_InvalidZipType = 72;
ERR7_TableDoesNotExist = 73;
ERR7_NotFrequencyTable = 74;
ERR7_InvalidFrequencyType = 75;
ERR7_InvalidTableSetting = 76;
ERR7_IncompatibleTableType = 77;
ERR7_IncompatibleCriterionCombination = 78;
ERR7_InvalidModalFile = 79;
ERR7_InvalidCombinationCaseNumber = 80;
ERR7_InvalidInitialCaseNumber = 81;
ERR7_InvalidInitialFile = 82;
ERR7_InvalidModeNumber = 83;
ERR7_BeamIsNotBXS = 84;
ERR7_InvalidDampingType = 85;
ERR7_InvalidRayleighMode = 86;
ERR7_CannotReadBXS = 87;
ERR7_InvalidResultType = 88;
ERR7_InvalidSolverParameter = 89;
ERR7_InvalidModalLoadType = 90;
ERR7_InvalidTimeRow = 91;
ERR7_SparseSolverNotLicenced = 92;
ERR7_InvalidSolverScheme = 93;
ERR7_InvalidSortOption = 94;
ERR7_IncompatibleResultFile = 95;
ERR7_InvalidLinkType = 96;
ERR7_InvalidLinkData = 97;
ERR7_OnlyOneLoadCase = 98;
ERR7_OnlyOneFreedomCase = 99;
ERR7_InvalidLoadID = 100;
ERR7_InvalidBeamLoadType = 101;
ERR7_InvalidStringID = 102;
ERR7_InvalidPatchType = 103;
ERR7_IncrementDoesNotExist = 104;
ERR7_InvalidLoadCaseType = 105;
ERR7_InvalidFreedomCaseType = 106;
ERR7_InvalidHarmonicLoadType = 107;
ERR7_InvalidTemperatureType = 108;
ERR7_InvalidPatchTypeForPlate = 109;
ERR7_InvalidAttributeType = 110;
ERR7_MaterialNotAnisotropic = 111;
ERR7_InvalidMatrixType = 112;
ERR7_MaterialNotUserDefined = 113;
ERR7_InvalidIndex = 114;
ERR7_InvalidContactType = 115;
ERR7_InvalidContactSubType = 116;
ERR7_InvalidCutoffType = 117;
ERR7_ResultQuantityNotAvailable = 118;
ERR7_YieldNotMCDP = 119;
ERR7_CombinationDoesNotExist = 120;
ERR7_InvalidSeismicCase = 121;
ERR7_InvalidImportExportMode = 122;
ERR7_CannotReadImportFile = 123;
ERR7_InvalidAnsysImportFormat = 124;
ERR7_InvalidAnsysArrayStatus = 125;
ERR7_CannotWriteExportFile = 126;
ERR7_InvalidAnsysExportFormat = 127;
ERR7_InvalidAnsysEndReleaseOption = 128;
ERR7_InvalidAnsysExportUnits = 129;
ERR7_InvalidSt7ExportFormat = 130;
ERR7_InvalidUVPos = 131;
ERR7_InvalidResponseType = 132;
ERR7_InvalidLayoutID = 133;
ERR7_InvalidPlateSurface = 134;
ERR7_MeshingErrors = 135;
ERR7_InvalidZipTolerance = 136;
ERR7_InvalidTaperAxis = 137;
ERR7_InvalidTaperType = 138;
ERR7_InvalidTaperRatio = 139;
ERR7_InvalidPositionType = 140;
ERR7_InvalidPreLoadType = 141;
ERR7_InvalidVertexType = 142;
ERR7_InvalidVertexMeshSize = 143;
ERR7_InvalidGeometryEdgeType = 144;
ERR7_InvalidPropertyNumber = 145;
ERR7_InvalidFaceSurface = 146;
ERR7_InvalidModType = 147;
ERR7_MaterialNotSoil = 148;
ERR7_MaterialNotFluid = 149;
ERR7_SoilTypeNotDC = 150;
ERR7_SoilTypeNotCC = 151;
ERR7_MaterialNotLaminate = 152;
ERR7_InvalidLaminateID = 153;
ERR7_LaminateNameAlreadyExists = 154;
ERR7_LaminateIDAlreadyExists = 155;
ERR7_PlyDoesNotExist = 156;
ERR7_ExceededMaxNumPlies = 157;
ERR7_LayoutIDAlreadyExists = 158;
ERR7_InvalidNumModes = 159;
ERR7_InvalidLTAMethod = 160;
ERR7_InvalidLTASolutionType = 161;
ERR7_ExceededMaxNumStages = 162;
ERR7_StageDoesNotExist = 163;
ERR7_ExceededMaxNumSpectralCases = 164;
ERR7_InvalidSpectralCase = 165;
ERR7_InvalidSpectrumType = 166;
ERR7_InvalidResultsSign = 167;
ERR7_InvalidPositionTableAxis = 168;
ERR7_InvalidInitialConditionsType = 169;
ERR7_ExceededMaxNumNodeHistory = 170;
ERR7_NodeHistoryDoesNotExist = 171;
ERR7_InvalidTransientTempType = 172;
ERR7_InvalidTimeUnit = 173;
ERR7_InvalidLoadPath = 174;
ERR7_InvalidTempDependenceType = 175;
ERR7_InvalidTrigType = 176;
ERR7_InvalidUserEquation = 177;
ERR7_InvalidCreepID = 178;
ERR7_CreepIDAlreadyExists = 179;
ERR7_InvalidCreepLaw = 180;
ERR7_InvalidCreepHardeningLaw = 181;
ERR7_InvalidCreepViscoChainRow = 182;
ERR7_InvalidCreepFunctionType = 183;
ERR7_InvalidCreepShrinkageType = 184;
ERR7_InvalidTableRow = 185;
ERR7_ExceededMaxNumRows = 186;
ERR7_InvalidLoadPathTemplateID = 187;
ERR7_LoadPathTemplateIDAlreadyExists = 188;
ERR7_InvalidLoadPathLane = 189;
ERR7_ExceededMaxNumLoadPathTemplates = 190;
ERR7_ExceededMaxNumLoadPathVehicles = 191;
ERR7_InvalidLoadPathVehicle = 192;
ERR7_InvalidMobilityType = 193;
ERR7_InvalidAxisSystem = 194;
ERR7_InvalidLoadPathID = 195;
ERR7_LoadPathIDAlreadyExists = 196;
ERR7_InvalidPathDefinition = 197;
ERR7_InvalidLoadPathShape = 198;
ERR7_InvalidLoadPathSurface = 199;
ERR7_InvalidNumPathDivs = 200;
ERR7_InvalidGeometryCavityLoop = 201;
ERR7_InvalidLimitEnvelope = 202;
ERR7_ExceededMaxNumLimitEnvelopes = 203;
ERR7_InvalidCombEnvelope = 204;
ERR7_ExceededMaxNumCombEnvelopes = 205;
ERR7_InvalidFactorsEnvelope = 206;
ERR7_ExceededMaxNumFactorsEnvelopes = 207;
ERR7_InvalidLimitEnvelopeType = 208;
ERR7_InvalidCombEnvelopeType = 209;
ERR7_InvalidFactorsEnvelopeType = 210;
ERR7_InvalidCombEnvelopeAccType = 211;
ERR7_InvalidEnvelopeSet = 212;
ERR7_ExceededMaxNumEnvelopeSets = 213;
ERR7_InvalidEnvelopeSetType = 214;
ERR7_InvalidCombResFile = 215;
ERR7_ExceededMaxNumCombResFiles = 216;
ERR7_CannotCombResFiles = 217;
ERR7_InvalidStartEndTimes = 218;
ERR7_InvalidNumSteps = 219;
ERR7_InvalidLibraryPath = 220;
ERR7_InvalidLibraryType = 221;
ERR7_InvalidLibraryID = 222;
ERR7_InvalidLibraryName = 223;
ERR7_InvalidLibraryItemID = 224;
ERR7_InvalidLibraryItemName = 225;
ERR7_InvalidDisplayOptionsPath = 226;
ERR7_InvalidSolverPath = 227;
ERR7_InvalidCementHardeningType = 228;
ERR7_ZeroPlateElements = 229;
ERR7_CannotMakeBXS = 230;
ERR7_CannotCalculateBXSData = 231;
ERR7_InvalidSurfaceMeshTargetType = 232;
ERR7_InvalidModalNodeReactType = 233;
ERR7_InvalidAxis = 234;
ERR7_InvalidBeamAxisType = 235;
ERR7_InvalidStaadCountryCodeOption = 236;
ERR7_InvalidGeometryFormatProtocol = 237;
ERR7_InvalidDXFBeamOption = 238;
ERR7_InvalidDXFPlateOption = 239;
ERR7_InvalidLoadPathLaneFactorType = 240;
ERR7_InvalidLoadPathVehicleInstance = 241;
ERR7_InvalidNumBeamStations = 242;
ERR7_ResFileUnsupportedType = 243;
ERR7_ResFileAlreadyOpen = 244;
ERR7_ResFileInvalidNumCases = 245;
ERR7_ResFileNotOpen = 246;
ERR7_ResFileInvalidCase = 247;
ERR7_ResFileDoesNotHaveEntity = 248;
ERR7_ResFileInvalidQuantity = 249;
ERR7_ResFileQuantityNotExist = 250;
ERR7_ResFileCantSave = 251;
ERR7_ResFileCantClearQuantity = 252;
ERR7_ResFileContainsNoElements = 253;
ERR7_ResFileContainsNoNodes = 254;
ERR7_ResFileInvalidName = 255;
ERR7_ResFileAssociationNotAllowed = 256;
ERR7_ResFileIncompatibleQuantity = 257;
ERR7_CannotEditSolverFiles = 258;
ERR7_CannotOpenResultFile = 259;
ERR7_CouldNotShowModelWindow = 260;
ERR7_ModelWindowWasNotShowing = 261;
ERR7_CantDoWithModalWindows = 262;
ERR7_InvalidSelectionEndEdgeFace = 263;
ERR7_CouldNotCreateModelWindow = 264;
ERR7_ModelWindowWasNotCreated = 265;
ERR7_InvalidImageType = 266;
ERR7_InvalidImageDimensions = 267;
ERR7_InsufficientRamToCreateImage = 268;
ERR7_CannotSaveImageFile = 269;
ERR7_InvalidWindowDimensions = 270;
ERR7_InvalidResultQuantity = 271;
ERR7_InvalidResultSubQuantity = 272;
ERR7_InvalidComponent = 273;
ERR7_ResultIsNotAvailable = 274;
ERR7_InvalidUCSIndex = 275;
ERR7_InvalidDiagramAxis = 276;
ERR7_InvalidVectorComponents = 277;
ERR7_TableTypeIsNotTimeBased = 278;
ERR7_InvalidTableID = 279;
ERR7_LinkNotMasterSlave = 280;
ERR7_LinkNotSectorSymmetry = 281;
ERR7_LinkNotCoupling = 282;
ERR7_LinkNotPinned = 283;
ERR7_LinkNotRigid = 284;
ERR7_LinkNotShrink = 285;
ERR7_LinkNotTwoPoint = 286;
ERR7_LinkNotAttachment = 287;
ERR7_LinkNotMultiPoint = 288;
ERR7_InvalidCoupleType = 289;
ERR7_InvalidRigidPlane = 290;
ERR7_InvalidMultiPointFactorsType = 291;
ERR7_InvalidMultiPointLink = 292;
ERR7_InvalidAttachmentType = 293;
ERR7_ExceededMaxNumColumns = 294;
ERR7_CouldNotDestroyModelWindow = 295;
ERR7_CannotSetWindowParent = 296;
ERR7_InvalidLoadCaseFilePath = 297;
ERR7_InvalidStaadLengthUnit = 298;
ERR7_InvalidStaadForceUnit = 299;
ERR7_InvalidDuplicateFaceType = 300;
ERR7_InvalidNodeCoordinateKeepType = 301;
ERR7_CommentDoesNotExist = 302;
ERR7_InvalidFilePath = 303;
ERR7_InvalidContactYieldType = 304;
ERR7_InvalidNumMeshingLoops = 305;
ERR7_InvalidMeshPositionOnUCS = 306;
ERR7_InvalidK0Expression = 307;
ERR7_InvalidK1Expression = 308;
ERR7_NoPatchLoadsCreated = 309;
ERR7_InvalidResOptsBeamEnvelope = 310;
ERR7_InvalidResOptsRotationUnit = 311;
ERR7_InvalidResOptsHRASetting = 312;
ERR7_InvalidResOptsStageDisplacement = 313;
ERR7_InvalidToolOptsZipOptions = 314;
ERR7_InvalidToolOptsSubdivideOptions = 315;
ERR7_InvalidToolOptsCopyOptions = 316;
ERR7_InvalidToleranceType = 317;
ERR7_InvalidAttachPartsParams = 318;
ERR7_InvalidDrawParameters = 319;
ERR7_FilesStillOpen = 320;
ERR7_SolverStillRunning = 321;
ERR7_InvalidPolygonToFaceParameters = 322;
ERR7_InvalidResOptsStrainUnit = 323;
ERR7_FunctionNotSupported = 324;
ERR7_SoilTypeNotMC = 325;
ERR7_SoilTypeNotDP = 326;
ERR7_TooManyAnimations = 327;
ERR7_InvalidAnimationFile = 328;
ERR7_InvalidAnimationMode = 329;
ERR7_InsufficientFrames = 330;
ERR7_AnimationDimensionsTooSmall = 331;
ERR7_AnimationDimensionsTooLarge = 332;
ERR7_ReducedAnimation = 333;
ERR7_InvalidAnimationType = 334;
ERR7_CannotFindStubFile = 335;
ERR7_CouldNotSaveAnimationFile = 336;
ERR7_AnimationHandleOutOfRange = 337;
ERR7_AnimationNotRunning = 338;
ERR7_SoilTypeNotLS = 339;
ERR7_NoPolygonWasConverted = 340;
ERR7_InvalidAlphaTempType = 341;
ERR7_InvalidGravityDirection = 342;
ERR7_InvalidAttachmentDirection = 343;
ERR7_InvalidHardeningType = 344;
ERR7_ResultCaseNotInertiaRelief = 345;
ERR7_InvalidNumLayers = 346;
ERR7_PlateDoesNotHaveLayers = 347;
ERR7_ToolOperationFailed = 348;

% Solver Error Codes
SE_NoLoadCaseSelected = 1001;
SE_IncompatibleRestartFile = 1002;
SE_ElementUsesInvalidProperty = 1003;
SE_InvalidElement = 1004;
SE_NeedNonlinearHeatSolver = 1005;
SE_TableNotFound = 1006;
SE_InvalidRestartFile = 1007;
SE_InvalidInitialFile = 1008;
SE_InvalidSolverResultFile = 1009;
SE_InvalidLink = 1010;
SE_InvalidPlateCohesionValue = 1011;
SE_InvalidBrickCohesionValue = 1012;
SE_NonlinearSolverRequired = 1013;
SE_NoLoadTablesDefined = 1014;
SE_NoVelocityDataInInitialFile = 1015;
SE_NoModesIncluded = 1016;
SE_InvalidTimeStep = 1017;
SE_LoadIncrementsNotDefined = 1018;
SE_NoFreedomCaseInIncrements = 1019;
SE_InvalidInitialTemperatureFile = 1020;
SE_InvalidFrequencyRange = 1021;
SE_ModelMixesAxiNonAxi = 1022;
SE_CompositeModuleNotAvailable = 1023;
SE_CannotFindSolver = 1024;
SE_UnknownException = 1025;
SE_DuplicateLinks = 1026;
SE_CannotAppendToFile = 1027;
SE_CannotOverwriteFile = 1028;
SE_CannotWriteToResultFile = 1029;
SE_CannotWriteToLogFile = 1030;
SE_CannotReadRestartFile = 1031;
SE_InitialConditionsNotValid = 1032;
SE_InvalidRayleighFactors = 1033;
SE_ShearPanelMustBeQuad4 = 1035;
SE_SingularPlateMatrix = 1036;
SE_SingularBrickMatrix = 1037;
SE_NoBeamProperties = 1038;
SE_NoPlateProperties = 1039;
SE_NoBrickProperties = 1040;
SE_MoreLoadIncrementsNeeded = 1041;
SE_RubberRequiresGNL = 1042;
SE_NoFreedomCaseSelected = 1043;
SE_InvalidSpectralVectors = 1044;
SE_NoSpectralResultsSelected = 1045;
SE_SpectralFactorsNotDefined = 1046;
SE_SpectralFactorsAllZero = 1047;
SE_NoTimeStepsSaved = 1048;
SE_InvalidDirectionVector = 1049;
SE_HarmonicFactorsAllZero = 1050;
SE_TemperatureDependenceCaseNotSet = 1051;
SE_ZeroLengthRigidLinkGenerated = 1052;
SE_InvalidStringGroupDefinition = 1053;
SE_InvalidPreTensionOnString = 1054;
SE_StringOrderHasChanged = 1055;
SE_BadTaperData = 1056;
SE_TaperedPlasticBeams = 1057;
SE_NoMovingLoadPathsInCases = 1058;
SE_NoResponseVariablesDefined = 1059;
SE_InvalidPlateVariableRequested = 1060;
SE_InvalidGravityCase = 1061;
SE_InvalidUserPlateCreepDefinition = 1062;
SE_InvalidUserBrickCreepDefinition = 1063;
SE_InvalidPlateShrinkageDefinition = 1064;
SE_InvalidBrickShrinkageDefinition = 1065;
SE_InvalidLaminateID = 1066;
SE_CannotReadWriteScratchPath = 1067;
SE_CannotConvertAttachmentLink = 1068;
SE_SoilRequiresMNL = 1069;
SE_ActiveStageHasNoIncrements = 1070;
SE_ConcreteCreepMNL = 1071;
SE_CannotConvertInterpMultiPoint = 1072;
SE_MissingInsituStress = 1073;
SE_InvalidMaterialNonlinearString = 1074;
SE_TensileInsituPlateStress = 1075;
SE_TensileInsituBrickStress = 1076;
SE_IncompatibleRestartUnits = 1077;
SE_CreepTimeTooShort = 1078;
SE_InvalidElements = 1079;
SE_InsufficientRestartFileSteps = 1080;
SE_NeedNodeTempNTASolver = 1081;

% Other Constants
kMaxPlateResult = 1024;
kMaxBrickResult = 1024;
kMaxBeamRelease = 12;
kMaxDisp = 6;
kAllStations = 20;

% UCS
kMaxUCSDoubles = 10;

% Solvers
stLinearStaticSolver = 1;
stLinearBucklingSolver = 2;
stNonlinearStaticSolver = 3;
stNaturalFrequencySolver = 4;
stHarmonicResponseSolver = 5;
stSpectralResponseSolver = 6;
stLinearTransientDynamicSolver = 7;
stNonlinearTransientDynamicSolver = 8;
stSteadyHeatSolver = 9;
stTransientHeatSolver = 10;
stLoadInfluenceSolver = 11;
stQuasiStaticSolver = 12;

% Solver Modes
smNormalRun = 1;
smProgressRun = 2;
smBackgroundRun = 3;

% Primary Load Case
ipLoadCaseDefRefTemp = 0;
ipLoadCaseDefOriginX = 1;
ipLoadCaseDefOriginY = 2;
ipLoadCaseDefOriginZ = 3;
ipLoadCaseDefLinAccX = 4;
ipLoadCaseDefLinAccY = 5;
ipLoadCaseDefLinAccZ = 6;
ipLoadCaseDefAngVelX = 7;
ipLoadCaseDefAngVelY = 8;
ipLoadCaseDefAngVelZ = 9;
ipLoadCaseDefAngAccX = 10;
ipLoadCaseDefAngAccY = 11;
ipLoadCaseDefAngAccZ = 12;

% Seismic Load Case
ipSeismicCaseDefAlpha = 0;
ipSeismicCaseDefPhi = 1;
ipSeismicCaseDefBeta = 2;
ipSeismicCaseDefK = 3;
ipSeismicCaseDefh0 = 4;
ipSeismicCaseDefDir = 5;
ipSeismicCaseDefLinAcc = 6;
ipSeismicCaseDefV1 = 7;
ipSeismicCaseDefV2 = 8;

% Import/Export Modes
ieQuietRun = 0;
ieProgressRun = 1;

% NASTRAN
ipNASTRANImportUnits = 0;
ipNASTRANFreedomCase = 0;
ipNASTRANLoadCase = 1;
ipNASTRANSolver = 2;
ipNASTRANExportUnits = 3;
ipNASTRANBeamStressSections = 4;
ipNASTRANBeamSectionGeometry = 5;
ipNASTRANExportHeatTransfer = 6;
ipNASTRANExportNSMass = 7;
ipNASTRANExportUnusedProps = 8;
ipNASTRANTemperatureCase = 9;
ipNASTRANExportZeroFields = 0;
ieNASTRANSolverLSA = 0;
ieNASTRANSolverNFA = 1;
ieNASTRANSolverLBA = 2;
ieNASTRANExportGeometryProps = 0;
ieNASTRANExportPropsOnly = 1;
naUnits_kg_N_m = 0;
naUnits_T_N_mm = 1;
naUnits_sl_lbf_ft = 2;
naUnits_lbm_lbf_in = 3;
naUnits_sl_lbf_in = 4;
naUnits_NoUnits = 5;

% ANSYS
ipANSYSImportFormat = 0;
ipANSYSArrayParameters = 1;
ipANSYSImportLoadCaseFiles = 2;
ipANSYSImportIGESEntities = 3;
ipANSYSFixElementConnectivity = 4;
ipANSYSRemoveDuplicateProps = 5;
ipANSYSExportFormat = 0;
ipANSYSFreedomCase = 1;
ipANSYSLoadCase = 2;
ipANSYSUnits = 3;
ipANSYSEndRelease = 4;
ipANSYSExportNonlinearMat = 5;
ipANSYSExportHeatTransfer = 6;
ipANSYSExportPreLoadNSMass = 7;
ipANSYSExportTetraOption = 8;
ieANSYSBatchImport = 0;
ieANSYSCDBImport = 1;
ieANSYSBatchCDBImport = 2;
ieANSYSBatch1Export = 0;
ieANSYSBatch3Export = 1;
ieANSYSBlockedCDBExport = 2;
ieANSYSUnblockedCDBExport = 3;
ieANSYSArrayOverwrite = 0;
ieANSYSArrayIgnore = 1;
ieANSYSArrayPrompt = 2;
ieANSYSEndReleaseFixed = 0;
ieANSYSEndReleaseFull = 1;
anUnits_NoUnits = 0;
anUnits_kg_m_C = 1;
anUnits_g_cm_C = 2;
anUnits_T_mm_C = 3;
anUnits_sl_ft_F = 4;
anUnits_lbm_in_F = 5;

% STAAD
ipSTAADCountryType = 0;
ipSTAADIncludeSectionLibrary = 1;
ipSTAADStripUnderscore = 2;
ipSTAADStripSectionSpaces = 3;
ipSTAADLengthUnit = 4;
ipSTAADForceUnit = 5;
ieSTAADAmericanCode = 0;
ieSTAADAustralianCode = 1;
ieSTAADBritishCode = 2;
sdLengthUnit_in = 0;
sdLengthUnit_ft = 1;
sdLengthUnit_cm = 2;
sdLengthUnit_m = 3;
sdLengthUnit_mm = 4;
sdLengthUnit_dm = 5;
sdLengthUnit_km = 6;
sdForceUnit_kip = 0;
sdForceUnit_lbf = 1;
sdForceUnit_kgf = 2;
sdForceUnit_MTf = 3;
sdForceUnit_N = 4;
sdForceUnit_kN = 5;
sdForceUnit_MN = 6;
sdForceUnit_dN = 7;

% SAP2000
ipSAP2000ConvertBlackTo = 0;
ipSAP2000DecimalSeparator = 1;
ipSAP2000ThousandSeparator = 2;
ipSAP2000MergeDuplicateFreedomSets = 3;
ieSAP2000Period = 0;
ieSAP2000Comma = 1;
ieSAP2000Space = 2;
ieSAP2000None = 3;

% ST7
ieSt7ExportCurrent = 0;
ieSt7Export106 = 1;
ieSt7Export21x = 2;
ieSt7Export22x = 3;
ieSt7Export23x = 4;

% GEOMETRY
ipImportGeomProp = 0;
ipImportGeomCurvesToBeams = 1;
ipImportGeomGroupsAs = 2;
ipImportGeomColourAsProperty = 3;
ipImportGeomBlackReplacement = 4;
ipImportGeomACISBodiesAsGroups = 5;
ipImportGeomLengthUnit = 6;
ipExportGeomColour = 0;
ipExportGeomGroupsAsLevels = 1;
ipExportGeomFullGroupPath = 2;
ipExportGeomFormatProtocol = 3;
ipExportGeomCurve = 4;
ipExportGeomPeriodicFace = 5;
ipExportGeomKeepAnalytic = 6;
ipImportGeomTol = 0;
luGeomNONE = -1;
luGeomINCH = 0;
luGeomMILLIMETRE = 1;
luGeomFEET = 2;
luGeomMILES = 3;
luGeomMETRE = 4;
luGeomKILOMETRE = 5;
luGeomMIL = 6;
luGeomMICRON = 7;
luGeomCENTIMETRE = 8;
luGeomMICROINCH = 9;
luGeomUNSPECIFIED = 10;

% Geometry Groups
ggNone = 0;
ggAuto = 1;
ggSubfigures = 2;
ggLevels = 3;
ggAssemblies = 1;

% IGES Formats
ifBoundedSurface = 0;
ifTrimmedParametricSurface = 1;
ifOpenShell = 2;
ifManifoldSolidBRep = 3;

% STEP Protocols
spConfigControlDesign = 0;
spAutomotiveDesign = 1;

% GEOMETRY Export Format Options
ieModelOnly = 0;
ieParameterOnly = 1;
ieModelPreferred = 2;
ieParameterPreferred = 3;
ieSeamOnlyAsRequired = 0;
ieSplitOnFaceBoundary = 1;
ieSplitIntoHalves = 2;
ieColourNone = 0;
ieFaceColour = 1;
ieGroupColour = 2;
iePropertyColour = 3;

% DXF Options
ipDXFImportFrozenLayers = 0;
ipDXFImportLayersAsGroups = 1;
ipDXFImportColoursAsProps = 2;
ipDXFImportPolylineAsPlates = 3;
ipDXFImportPolygonAsBricks = 4;
ipDXFImportSegmentsPerCircle = 5;
ipDXFExportPlatesBricks3DFaces = 0;
ipDXFExportGroupsAsLayers = 1;
ipDXFExportPropColoursAsEntityColours = 2;
ipDXFExportBeamsAs = 3;
ipDXFExportPlatesAs = 4;
bmLine = 0;
bmSection = 1;
bmSolid = 2;
plSurface = 0;
plSolid = 1;

% Geometry Groups Settings
grNone = 0;
grAuto = 1;
grSubfigures = 2;
grLevels = 3;
grAssembly = 1;

% BXS
ipBXSXBar = 0;
ipBXSYBar = 1;
ipBXSArea = 2;
ipBXSI11 = 3;
ipBXSI22 = 4;
ipBXSAngle = 5;
ipBXSZ11Plus = 6;
ipBXSZ11Minus = 7;
ipBXSZ22Plus = 8;
ipBXSZ22Minus = 9;
ipBXSS11 = 10;
ipBXSS22 = 11;
ipBXSr1 = 12;
ipBXSr2 = 13;
ipBXSSA1 = 14;
ipBXSSA2 = 15;
ipBXSSL1 = 16;
ipBXSSL2 = 17;
ipBXSIXX = 18;
ipBXSIYY = 19;
ipBXSIXY = 20;
ipBXSIxxL = 21;
ipBXSIyyL = 22;
ipBXSIxyL = 23;
ipBXSZxxPlus = 24;
ipBXSZxxMinus = 25;
ipBXSZyyPlus = 26;
ipBXSZyyMinus = 27;
ipBXSSxx = 28;
ipBXSSyy = 29;
ipBXSrx = 30;
ipBXSry = 31;
ipBXSJ = 32;
ipBXSIw = 33;

% GEOMETRY CLEAN - DOUBLES
ipGeometryAccuracy = 0;
ipGeometryFeatureLength = 1;
ipGeometryEdgeMergeAngle = 2;

% GEOMETRY CLEAN - INTEGERS
ipGeometryAccuracyType = 0;
ipGeometryFeatureType = 1;
ipGeometryActOnWholeModel = 2;
ipGeometryFreeEdgesOnly = 3;
ipGeometryDuplicateFaces = 4;
dfGeometryLeave = 0;
dfGeometryDeleteOne = 1;
dfGeometryDeleteBoth = 2;

% MESH CLEAN - DOUBLES
ipMeshTolerance = 0;

% MESH CLEAN - INTEGERS
ipMeshToleranceType = 0;
ipZipNodes = 1;
ipRemoveDuplicateElements = 2;
ipFixElementConnectivity = 3;
ipDeleteFreeNodes = 4;
ipDoBeams = 5;
ipDoPlates = 6;
ipDoBricks = 7;
ipDoLinks = 8;
ipZeroLengthLinks = 9;
ipZeroLengthBeams = 10;
ipNodeAttributeKeep = 11;
ipNodeCoordinates = 12;
ipAllowDifferentProps = 13;
ipActOnWholeModel = 14;
dfLeaveAll = 0;
dfLeaveOne = 1;
dfLeaveNone = 2;

% Attribute keep
naLower = 0;
naHigher = 1;
naAccumulate = 2;

% Node coordinates
ncAverage = 0;
ncLowerNode = 1;
ncHigherNode = 2;
ncSelectedNode = 3;

% SURFACE MESHING - INTEGERS
ipSurfaceMeshMode = 0;
ipSurfaceMeshSizeMode = 1;
ipSurfaceMeshTargetNodes = 2;
ipSurfaceMeshTargetPropertyID = 3;
ipSurfaceMeshAutoCreateProperties = 4;
ipSurfaceMeshMinEdgesPerCircle = 5;
ipSurfaceMeshApplyTransitioning = 6;
ipSurfaceMeshAllowUserStop = 7;
ipSurfaceMeshConsiderNearVertex = 8;
mmAuto = 0;
mmCustom = 1;
smPercentage = 0;
smAbsolute = 1;

% SURFACE MESHING - DOUBLES
ipSurfaceMeshSize = 0;
ipSurfaceMeshLengthRatio = 1;
ipSurfaceMeshMaximumIncrease = 2;
ipSurfaceMeshOnEdgesLongerThan = 3;

% TETRA MESHING
ipTetraMeshSize = 0;
ipTetraMeshProperty = 1;
ipTetraMeshInc = 2;
ipTetraMesh10 = 3;
ipTetraMeshGroupsAsSolids = 4;
ipTetraMeshSmooth = 5;
ipTetraMeshAutoCreateProperties = 7;
ipTetraMeshDeletePlates = 8;
ipTetraMeshMultiBodyOption = 9;
ipTetraMeshAllowUserStop = 10;
ipTetraMeshCheckSelfIntersect = 11;
msFine = 1;
msMedium = 2;
msCoarse = 3;
mbCancelMeshing = 0;
mbCavity = 1;
mbSeparateSolids = 2;

% Polygon Meshing
ipMeshTargetNodes = 0;
ipMeshTargetPropertyID = 1;
ipMeshUCSID = 2;
ipMeshGroupID = 3;
ipMeshPositionUCS = 0;

% IMAGE TYPES
itBitmap8Bit = 1;
itBitmap16Bit = 2;
itBitmap24Bit = 3;
itJPEG = 4;

% WINDOW POPUP MENU GROUPS
imView = 1;
imDisplay = 2;
imShow = 3;
imSelect = 4;
imResults = 5;

% WINDOW STATE
wsModelWindowNotCreated = 0;
wsModelWindowVisible = 1;
wsModelWindowMaximised = 2;
wsModelWindowMinimised = 3;
wsModelWindowHidden = 4;

% Entity Display Settings - Node
ipNodeSelectedColour = 0;
ipNodeUnselectedColour = 1;
ipNodeShowFree = 2;
ipNodeNumberMode = 3;
ipNodeSymbol = 4;

% Entity Display Settings - Beam
ipBeamDisplay = 0;
ipBeamShowRefNode = 1;
ipBeamShowOffset = 2;
ipBeamMoveToOffset = 3;
ipBeamLightShade = 4;
ipBeamGlobalColour = 5;
ipBeamOutlineColour = 6;
ipBeamEnd1Colour = 7;
ipBeamEnd2Colour = 8;
ipBeamRefNodeColour = 9;
ipBeamFilledMode = 10;
ipBeamContour = 11;
ipBeamShrink = 12;
ipBeamRoundFacets = 13;
ipBeamSpringCoils = 14;
ipBeamSpringAspect = 15;
ipBeamThickness = 16;
ipBeamSections = 17;
ipBeamOutlines = 18;
ipBeamShowAxes = 19;
ipBeamNumberMode = 20;

% Entity Display Settings - Plate
ipPlateDisplay = 0;
ipPlateLightShade = 1;
ipPlateGlobalColour = 2;
ipPlateOutlineColour = 3;
ipPlateZPlusColour = 4;
ipPlateZMinusColour = 5;
ipPlateOffsetColour = 6;
ipPlateFilledMode = 7;
ipPlateContour = 8;
ipPlateShrink = 9;
ipPlateOutlines = 10;
ipPlateOutlineThickness = 11;
ipPlateShowAxes = 12;
ipPlateAxisOnPly = 13;
ipPlateOffset = 14;
ipPlateMoveToOffset = 15;
ipPlateNumberMode = 16;

% Entity Display Settings - Brick
ipBrickLightShade = 0;
ipBrickGlobalColour = 1;
ipBrickOutlineColour = 2;
ipBrickFilledMode = 3;
ipBrickContour = 4;
ipBrickShrink = 5;
ipBrickOutlines = 6;
ipBrickOutlineThickness = 7;
ipBrickShowFreeFaces = 8;
ipBrickAxes1 = 9;
ipBrickAxes2 = 10;
ipBrickAxes3 = 11;
ipBrickNumberMode = 12;
ipBrickShowAllFaces = 13;

% Entity Display Settings - Link
ipLinkGlobalColour = 0;
ipLinkMasterSlaveColour = 1;
ipLinkSectorSymmColour = 2;
ipLinkCouplingColour = 3;
ipLinkPinnedColour = 4;
ipLinkRigidColour = 5;
ipLinkShrinkColour = 6;
ipLinkTwoPointColour = 7;
ipLinkAttachmentColour = 8;
ipLinkMultiPointColour = 9;
ipLinkFilledMode = 10;
ipLinkNumberMode = 11;

% Entity Display Settings - Load Path
ipLoadPathColour = 0;
ipLoadPathColourMode = 1;
ipLoadPathNumberMode = 2;
ipLoadPathShowDivisions = 3;
ipLoadPathThickness = 4;

% Entity Display Settings - Vertex
ipVertexFreeColour = 0;
ipVertexFixedColour = 1;
ipVertexSelectedColour = 2;
ipVertextNumberMode = 3;
ipVertexSymbol = 4;

% Entity Display Settings - Geometry Edge
ipEdgeShow = 0;
ipEdgeShowNonInterp = 1;
ipEdgeStyle = 2;
ipEdgeColourMode = 3;
ipEdgeColour = 4;
ipEdgeNonInterpColour = 5;

% Entity Display Settings - Geometry Face
ipFaceWireframeColour = 0;
ipFaceShowWireframes = 1;
ipFaceShowControlPoints = 2;
ipFaceShowNormals = 3;
ipFaceWireframeStyle = 4;
ipFaceWireframeColourMode = 5;
ipFaceWireframeDensity = 6;

% Entity Display Settings - Number Modes
nmNone = 0;
nmByElement = 1;
nmByProperty = 2;
nmByPropertyName = 3;
nmByID = 4;

% Entity Display Settings - Display Modes
dmLine = 0;
dmSection = 1;
dmSolid = 2;
dmSlice = 3;

% Entity Display Settings - Outline Modes
omOutlineOn = 0;
omOutlineOff = 1;
omOutlineFacet = 2;

% Entity Display Settings - Filled Modes
fmPropertyColour = 1;
fmGroupColour = 2;
fmGlobalColour = 3;
fmPropertyWireframe = 4;
fmGroupWireframe = 5;
fmOutlineWireframe = 6;
fmOrientation = 7;

% Entity Display Settings - Colour Modes
cmPropertyColour = 0;
cmGroupColour = 1;
cmFaceColour = 2;
cmFixedColour = 3;

% Entity Display Settings - Load Path Colour Modes
cmLoadPathTemplateColour = 0;
cmLoadPathGroupColour = 1;
cmLoadPathColour = 2;
cmLoadPathGlobalColour = 3;

% Entity Display Settings - Edge Styles
esThinEdge = 0;
esThickEdge = 1;

% Entity Display Settings - Wireframe Styles
wsDepthShaded = 0;
wsConstantColour = 1;

% Entity Display Settings - Node/Vertex Symbols
syDot1 = 0;
syDot2 = 1;
syDot3 = 2;
syDot4 = 3;
sySquare1 = 4;
sySquare2 = 5;
syDisk1 = 6;
syDisk2 = 7;
syCircle1 = 8;
syCircle2 = 9;
syCircle3 = 10;
sy3D1 = 11;
sy3D2 = 12;
sy3D3 = 13;

% Entity Display Settings - Beam Contour Types
ctBeamNone = 0;
ctBeamLength = 1;
ctBeamAxis1 = 2;
ctBeamAxis2 = 3;
ctBeamAxis3 = 4;
ctBeamEA = 5;
ctBeamEI11 = 6;
ctBeamEI22 = 7;
ctBeamGJ = 8;
ctBeamEAFactor = 9;
ctBeamEI11Factor = 10;
ctBeamEI22Factor = 11;
ctBeamGJFactor = 12;
ctBeamOffset1 = 13;
ctBeamOffset2 = 14;
ctBeamStiffnessFactor1 = 15;
ctBeamStiffnessFactor2 = 16;
ctBeamStiffnessFactor3 = 17;
ctBeamStiffnessFactor4 = 18;
ctBeamStiffnessFactor5 = 19;
ctBeamStiffnessFactor6 = 20;
ctBeamMassFactor = 21;
ctBeamSupport1 = 22;
ctBeamSupport2 = 23;
ctBeamTemperature = 24;
ctBeamPreTension = 25;
ctBeamPreStrain = 26;
ctBeamTempGradient1 = 27;
ctBeamTempGradient2 = 28;
ctBeamPipePressureIn = 29;
ctBeamPipePressureOut = 30;
ctBeamPipeTempIn = 31;
ctBeamPipeTempOut = 32;
ctBeamConvectionCoeff = 33;
ctBeamConvectionAmbient = 34;
ctBeamRadiationCoeff = 35;
ctBeamRadiationAmbient = 36;
ctBeamHeatFlux = 37;
ctBeamHeatSource = 38;
ctBeamAgeAtFirstLoading = 39;

% Entity Display Settings - Plate Contour Types
ctPlateNone = 0;
ctPlateAspectRatioMin = 1;
ctPlateAspectRatioMax = 2;
ctPlateWarping = 3;
ctPlateInternalAngle = 4;
ctPlateInternalAngleRatio = 5;
ctPlateDiscreteThicknessM = 6;
ctPlateContinuousThicknessM = 7;
ctPlateDiscreteThicknessB = 8;
ctPlateContinuousThicknessB = 9;
ctPlateOffset = 10;
ctPlateArea = 11;
ctPlateAxis1 = 12;
ctPlateAxis2 = 13;
ctPlateAxis3 = 14;
ctPlateTemperature = 15;
ctPlateEdgeSupport = 16;
ctPlateFaceSupport = 17;
ctPlatePreStressX = 18;
ctPlatePreStressY = 19;
ctPlatePresStressZ = 20;
ctPlatePreStressMagnitude = 21;
ctPlatePreStrainX = 22;
ctPlatePreStrainY = 23;
ctPlatePreStrainZ = 24;
ctPlatePreStrainMagnitude = 25;
ctPlateTempGradient = 26;
ctPlateEdgePressure = 27;
ctPlateEdgeShear = 28;
ctPlateEdgeNormalShear = 29;
ctPlatePressureNormal = 30;
ctPlatePressureGlobal = 31;
ctPlatePressureGlobalX = 32;
ctPlatePressureGlobalY = 33;
ctPlatePressureGlobalZ = 34;
ctPlateFaceShearX = 35;
ctPlateFaceShearY = 36;
ctPlateFaceShearMagnitude = 37;
ctPlateNSMass = 38;
ctPlateDynamicFactor = 39;
ctPlateConvectionCoeff = 40;
ctPlateConvectionAmbient = 41;
ctPlateRadiationCoeff = 42;
ctPlateRadiationAmbient = 43;
ctPlateHeatFlux = 44;
ctPlateConvectionCoeffZPlus = 45;
ctPlateConvectionCoeffZMinus = 46;
ctPlateConvectionAmbientZPlus = 47;
ctPlateConvectionAmbientZMinus = 48;
ctPlateRadiationCoeffZPlus = 49;
ctPlateRadiationCoeffZMinus = 50;
ctPlateRadiationAmbientZPlus = 51;
ctPlateRadiationAmbientZMinus = 52;
ctPlateHeatSource = 53;
ctPlateSoilStressSV = 54;
ctPlateSoilStressKO = 55;
ctPlateSoilStressSH = 56;
ctPlateSoilRatioOCR = 57;
ctPlateSoilRatioEO = 58;
ctPlateAgeAtFirstLoading = 59;

% Entity Display Settings - Brick Contour Types
ctBrickNone = 0;
ctBrickAspectRatioMin = 1;
ctBrickAspectRatioMax = 2;
ctBrickVolume = 3;
ctBrickDeterminant = 4;
ctBrickInternalAngle = 5;
ctBrickMixedProduct = 6;
ctBrickDihedral = 7;
ctBrickAxis1 = 8;
ctBrickAxis2 = 9;
ctBrickAxis3 = 10;
ctBrickTemperature = 11;
ctBrickSupport = 12;
ctBrickPreStressX = 13;
ctBrickPreStressY = 14;
ctBrickPreStressZ = 15;
ctBrickPreStressMagnitude = 16;
ctBrickPreStrainX = 17;
ctBrickPreStrainY = 18;
ctBrickPreStrainZ = 19;
ctBrickPreStrainMagnitude = 20;
ctBrickNormalPressure = 21;
ctBrickGlobalPressure = 22;
ctBrickGlobalPressureX = 23;
ctBrickGlobalPressureY = 24;
ctBrickGlobalPressureZ = 25;
ctBrickShearX = 26;
ctBrickShearY = 27;
ctBrickShearMagnitude = 28;
ctBrickNSMass = 29;
ctBrickDynamicFactor = 30;
ctBrickConvectionCoeff = 31;
ctBrickConvectionAmbient = 32;
ctBrickRaditionCoeff = 33;
ctBrickRadiationAmbient = 34;
ctBrickHeatFlux = 35;
ctBrickHeatSource = 36;
ctBrickSoilStressSV = 37;
ctBrickSoilStressKO = 38;
ctBrickSoilStressSH = 39;
ctBrickSoilRatioOCR = 40;
ctBrickSoilRatioEO = 41;
ctBrickAgeAtFirstLoading = 42;

% Beam/Plate/Brick Result Display Type - INDEXED BY ipResultType
rtAsNone = 0;
rtAsContour = 1;
rtAsDiagram = 2;
rtAsVector = 3;

% Node Output Display Quantity - Indexed by ipResultQuantity
icDispC = 101;
icVelC = 102;
icAccC = 103;
icPhaseC = 104;
icReactC = 105;
icTempC = 106;
icNodeForceC = 107;
icNodeFluxC = 108;

% Beam Output Display Quantity - Indexed by ipResultQuantity
icBeamForceC = 201;
icBeamStrainC = 202;
icBeamStressC = 203;
icBeamCreepStrainC = 204;
icBeamEnergyC = 205;
icBeamFluxC = 206;
icBeamTGradC = 207;

% Plate Output Display Quantity - Indexed by ipResultQuantity
icPlateForceC = 301;
icPlateMomentC = 302;
icPlateStressC = 303;
icPlateStrainC = 304;
icPlateCurvatureC = 305;
icPlateCreepStrainC = 306;
icPlateEnergyC = 307;
icPlateFluxC = 308;
icPlateTGradC = 309;

% Brick Output Display Quantity - Indexed by ipResultQuantity
icBrickStressC = 401;
icBrickStrainC = 402;
icBrickCreepStrainC = 403;
icBrickEnergyC = 404;
icBrickFluxC = 405;
icBrickTGradC = 406;

% Vector Styles - Indexed by ipVectorStyle
vtVectorComponent = 0;
vtVectorTranslationMag = 1;
vtVectorRotationMag = 2;

% Result Display Indexes
ipResultType = 0;
ipResultQuantity = 1;
ipResultAxis = 2;
ipResultComponent = 3;
ipResultSurface = 4;
ipVectorStyle = 5;
ipDiagram1 = 7;
ipDiagram2 = 8;
ipDiagram3 = 9;
ipDiagram4 = 10;
ipDiagram5 = 11;
ipDiagram6 = 12;
ipVector1 = 7;
ipVector2 = 8;
ipVector3 = 9;
ipVector4 = 10;
ipVector5 = 11;
ipVector6 = 12;

% Utility
ipRadian = 0;
ipDegree = 1;

% Result Options
ipResOptsBeamEnvelope = 0;
ipResOptsRotationUnit = 1;
ipResOptsHRADisplacement = 2;
ipResOptsHRAVelocity = 3;
ipResOptsHRAAcceleration = 4;
ipResOptsStageDisplacement = 5;
ipResOptsStrainUnit = 6;

% Result Options - Strain Units
suUnit = 0;
suPercent = 1;
suMicro = 2;

% Result Options - HRA
hrRelative = 0;
hrTotal = 1;

% Result Options - Staging
sdBirthStage = 0;
sdInitial = 1;

% Result Options - Beam Envelopes
bePrincipal = 0;
beLocal = 1;

% Tool Options - Doubles
ipToolOptsElementTol = 0;
ipToolOptsGeometryAccuracy = 1;
ipToolOptsGeometryFeatureLength = 2;

% Tool Options - Integers
ipToolOptsElementTolType = 0;
ipToolOptsGeometryAccuracyType = 1;
ipToolOptsGeometryFeatureType = 2;
ipToolOptsZipMesh = 3;
ipToolOptsNodeCoordinate = 4;
ipToolOptsNodeAttributeKeep = 5;
ipToolOptsAllowZeroLengthLinks = 6;
ipToolOptsAllowZeroLengthBeams = 7;
ipToolOptsAllowSameProperty = 8;
ipToolOptsCompatibleTriangle = 9;
ipToolOptsSubdivideBeams = 10;
ipToolOptsPlateAxisAlign = 11;
ipToolOptsCopyMode = 12;
ipToolOptsAutoCreateProperties = 13;

% Tool Options - Mesh Zipping
zmAsNeeded = 0;
zmOnSave = 1;
zmOnRequest = 2;

% Tool Options - Copy Mode
cmRoot = 0;
cmSibling = 1;

% Tool Options - Axis Alignment
paCentroid = 0;
paCurvilinear = 1;

% Axis Definitions
axLocalX = 1;
axLocalY = 2;
axPrincipal1 = 1;
axPrincipal2 = 2;
axBeamPrincipal = 0;
axBeamLocal = 1;

% Beam Taper
btSymm = 0;
btTop = 1;
btBottom = 2;

% Pre-load
plBeamPreTension = 0;
plBeamPreStrain = 1;
plPlatePreStress = 0;
plPlatePreStrain = 1;
plBrickPreStress = 0;
plBrickPreStrain = 1;

% Attachment Attribute
alRigid = 0;
alFlexible = 1;
alDirect = 2;
alMoment = 0;
alPinned = 1;

% Thermal
ipConvection = 0;
ipRadiation = 0;
ipAmbient = 1;

% LTA Methods
ltWilson = 0;
ltNewmark = 1;

% Spectral
stResponse = 0;
stPSD = 1;

% Spectral Results Sign
rsAuto = 0;
rsAbsolute = 1;

% LTA
stFullSystem = 0;
stSuperposition = 1;

% Attach Parts
ipDoEnds = 0;
ipDoEdges = 1;
ipDoFaces = 2;
ipSelectedOnly = 3;
ipDeleteExisting = 4;
ipAllBrickFaces = 5;
ipAngleDelta = 0;

% Modal Reactions
mrElementForce = 0;
mrInertiaForce = 1;

% Transient Initial Conditions
icAppliedVectors = 0;
icNodalVelocity = 1;
icFromFile = 2;

% Transient-Quasi Temperature
ttNodalTemp = 0;
ttFromFile = 1;

% Envelopes
etLimitEnvelopeAbs = 0;
etLimitEnvelopeMin = 1;
etLimitEnvelopeMax = 2;
etCombEnvelopeMin = 0;
etCombEnvelopeMax = 1;
etFactEnvelopeMin = 0;
etFactEnvelopeMax = 1;
esCombEnvelopeOn = 0;
esCombEnvelopeOff = 1;
esCombEnvelopeCheck = 2;
stExclusiveOR = 0;
stExclusiveAND = 1;

% Frequency Table Units
fuNone = 0;
fuDispResponse = 1;
fuVelResponse = 2;
fuAccelResponse = 3;
fuDispPSD = 4;
fuVelPSD = 5;
fuAccelPSD = 6;

% Temp/Time Types
mtElastic = 0;
mtPlastic = 1;

% Material Hardening Types
htIsotropic = 0;
htKinematic = 1;
htTakeda = 2;

% Spring-damper
ipSpringAxialStiff = 0;
ipSpringLateralStiff = 1;
ipSpringTorsionStiff = 2;
ipSpringAxialDamp = 3;
ipSpringLateralDamp = 4;
ipSpringTorsionDamp = 5;
ipSpringMass = 6;

% Truss
ipTrussIncludeTorsion = 0;

% Cable
ipCableSegments = 0;

% Cutoff Bar
ipCutoffTension = 0;
ipCutoffCompression = 1;

% Contact
cfElastic = 0;
cfPlastic = 1;
cyRectangular = 0;
cyElliptical = 1;

% Ply Material - Integers
ipPlyWeaveType = 0;
wtPlyUniDirectional = 0;
wtPlyBiDirectional = 1;
wtPlyTriDirectional = 2;
wtPlyQuasiIsotropic = 3;

% Ply Material - Doubles
ipPlyModulus1 = 0;
ipPlyModulus2 = 1;
ipPlyPoisson = 2;
ipPlyShear12 = 3;
ipPlyShear13 = 4;
ipPlyShear23 = 5;
ipPlyAlpha1 = 6;
ipPlyAlpha2 = 7;
ipPlyDensity = 8;
ipPlyThickness = 9;
ipPlyS1Tension = 10;
ipPlyS2Tension = 11;
ipPlyS1Compression = 12;
ipPlyS2Compression = 13;
ipPlySShear = 14;
ipPlyE1Tension = 15;
ipPlyE2Tension = 16;
ipPlyE1Compression = 17;
ipPlyE2Compression = 18;
ipPlyEShear = 19;
ipPlyInterLaminaShear = 20;

% Laminate Material
ipLaminateViscosity = 0;
ipLaminateDampingRatio = 1;
ipLaminateConductivity1 = 2;
ipLaminateConductivity2 = 3;
ipLaminateSpecificHeat = 4;
ipLaminateDensity = 5;
ipLaminateAlphax = 6;
ipLaminateAlphay = 7;
ipLaminateAlphaxy = 8;
ipLaminateBetax = 9;
ipLaminateBetay = 10;
ipLaminateBetaxy = 11;
ipLaminateModulusx = 12;
ipLaminateModulusy = 13;
ipLaminateShearxy = 14;
ipLaminatePoissonxy = 15;
ipLaminatePoissonyx = 16;
ipLaminateThickness = 17;

% Laminate Plies
ipLaminatePlyAngle = 0;
ipLaminatePlyThickness = 1;

% Laminate Matrices
ipLaminateIgnoreCoupling = 0;
ipLaminateAutoTransverseShear = 1;

% Concrete Reinforcement Layouts - Integers
ipReoLayoutType = 0;
ipReoColour13 = 1;
ipReoColour24 = 2;
ipReoCalcMethod = 3;
ipReoConsiderMembrane = 4;
ipReoAllowCompressionReo = 5;
crReoSymmetric = 0;
crReoAntiSymmetric = 1;
crReoSimplified = 0;
crReoElastoPlasticIter = 1;

% Concrete Reinforcement Layouts - Doubles
ipReoDiam1 = 0;
ipReoDiam2 = 1;
ipReoDiam3 = 2;
ipReoDiam4 = 3;
ipReoCover1 = 4;
ipReoCover2 = 5;
ipReoSpacing1 = 6;
ipReoSpacing2 = 7;
ipReoSpacing3 = 8;
ipReoSpacing4 = 9;
ipReoConcreteModulus = 10;
ipReoConcreteStrain = 11;
ipReoConcreteStress = 12;
ipReoConcretePhi = 13;
ipReoConcreteGamma = 14;
ipReoSteelModulus = 15;
ipReoSteelStress = 16;
ipReoSteelGamma = 17;
ipReoSteelMinArea = 18;

% Creep Hardening
ipCreepHardeningType = 0;
ipCreepHardeningCyclic = 1;
crHardeningTime = 0;
crHardeningStrain = 1;

% Hyperbolic Creep - Doubles
ipCreepHyberbolicAlpha = 0;
ipCreepHyperbolicBeta = 1;
ipCreepHyperbolicDelta = 2;
ipCreepHyperbolicPhi = 3;

% Hyperbolic Creep - Integers
ipCreepHyperbolicTimeTable = 0;
ipCreepHyperbolicConstModulus = 1;

% Visco-elastic Creep - Integers
ipCreepViscoTimeTable = 0;
ipCreepViscoTempTable = 1;

% Visco-elastic Creep - Doubles
ipCreepViscoDamper = 0;
ipCreepViscoStiffness = 1;

% Creep Concrete Functions
cfCreepFunction = 0;
cfRelaxationFunction = 1;

% Creep Shrinkage
crCreepShrinkageTable = 0;
crCreepShrinkageFormula = 1;
ipCreepShrinkageAlpha = 0;
ipCreepShrinkageBeta = 1;
ipCreepShrinkageDelta = 2;
ipCreepShrinkageStrain = 3;

% Creep Temperature - Integers
ipIncludeCreepTemperature = 0;
ipIncludeRateTemperature = 1;
ipIncludeShrinkageTemperature = 2;

% Creep Temperature - Doubles
ipCreepCAAge = 0;
ipCreepTRefAge = 1;
ipCreepCCCreep = 2;
ipCreepTRefCreep = 3;
ipCreepCAShrink = 4;
ipCreepTRefShrink = 5;

% Cement Curing - Integers
ipCreepIncludeCuring = 0;
ipCreepCuringTimeTable = 1;
ipCreepCuringType = 2;
ctCuringRapid = 0;
ctCuringNormal = 1;
ctCuringSlow = 2;

% Cement Curing - Doubles
ipCreepCuringCT = 0;
ipCreepCuringTRef = 1;
ipCreepCuringT0 = 2;

% Stage Data
ipStageMorph = 0;
ipStageMovedFixedNodes = 1;
ipStageRotateClusters = 2;

% Node Response Variables
reNodeDisplacement = 0;
reNodeReaction = 1;

% Beam Response Variables
ipBeamResponseSF1 = 0;
ipBeamResponseSF2 = 1;
ipBeamResponseAxial = 2;
ipBeamResponseBM1 = 3;
ipBeamResponseBM2 = 4;
ipBeamResponseTorque = 5;

% Plate Response Variables
rePlateForce = 0;
rePlateMoment = 1;

% Pipe Properties
ipPipeFlexibility = 0;
ipPipeFluidDensity = 1;
ipPipeOuterDiameter = 2;
ipPipeThickness = 3;

% Connection Properties
ipConnectionShear1 = 0;
ipConnectionShear2 = 1;
ipConnectionAxial = 2;
ipConnectionBend1 = 3;
ipConnectionBend2 = 4;
ipConnectionTorque = 5;

% Beam Materials
ipBeamModulus = 0;
ipBeamShear = 1;
ipBeamPoisson = 2;
ipBeamDensity = 3;
ipBeamAlpha = 4;
ipBeamViscosity = 5;
ipBeamDampingRatio = 6;
ipBeamConductivity = 7;
ipBeamSpecificHeat = 8;

% Plate Isotropic Materials
ipPlateIsoModulus = 0;
ipPlateIsoPoisson = 1;
ipPlateIsoDensity = 2;
ipPlateIsoAlpha = 3;
ipPlateIsoViscosity = 4;
ipPlateIsoDampingRatio = 5;
ipPlateIsoConductivity = 6;
ipPlateIsoSpecificHeat = 7;

% Brick Isotropic Materials
ipBrickIsoModulus = 0;
ipBrickIsoPoisson = 1;
ipBrickIsoDensity = 2;
ipBrickIsoAlpha = 3;
ipBrickIsoViscosity = 4;
ipBrickIsoDampingRatio = 5;
ipBrickIsoConductivity = 6;
ipBrickIsoSpecificHeat = 7;

% Plate Orthotropic Materials
ipPlateOrthoModulus1 = 0;
ipPlateOrthoModulus2 = 1;
ipPlateOrthoModulus3 = 2;
ipPlateOrthoShear12 = 3;
ipPlateOrthoShear23 = 4;
ipPlateOrthoShear31 = 5;
ipPlateOrthoPoisson12 = 6;
ipPlateOrthoPoisson23 = 7;
ipPlateOrthoPoisson31 = 8;
ipPlateOrthoDensity = 9;
ipPlateOrthoAlpha1 = 10;
ipPlateOrthoAlpha2 = 11;
ipPlateOrthoAlpha3 = 12;
ipPlateOrthoViscosity = 13;
ipPlateOrthoDampingRatio = 14;
ipPlateOrthoConductivity1 = 15;
ipPlateOrthoConductivity2 = 16;
ipPlateOrthoSpecificHeat = 17;

% Brick Orthotropic Materials
ipBrickOrthoModulus1 = 0;
ipBrickOrthoModulus2 = 1;
ipBrickOrthoModulus3 = 2;
ipBrickOrthoShear12 = 3;
ipBrickOrthoShear23 = 4;
ipBrickOrthoShear31 = 5;
ipBrickOrthoPoisson12 = 6;
ipBrickOrthoPoisson23 = 7;
ipBrickOrthoPoisson31 = 8;
ipBrickOrthoDensity = 9;
ipBrickOrthoAlpha1 = 10;
ipBrickOrthoAlpha2 = 11;
ipBrickOrthoAlpha3 = 12;
ipBrickOrthoViscosity = 13;
ipBrickOrthoDampingRatio = 14;
ipBrickOrthoConductivity1 = 15;
ipBrickOrthoConductivity2 = 16;
ipBrickOrthoConductivity3 = 17;
ipBrickOrthoSpecificHeat = 18;

% Plate Anisotropic Materials

% 0..9 ansi matrix
ipPlateAnisoTransShear1 = 10;
ipPlateAnisoTransShear2 = 11;
ipPlateAnisoTransShear3 = 12;
ipPlateAnisoDensity = 13;
ipPlateAnisoAlpha1 = 14;
ipPlateAnisoAlpha2 = 15;
ipPlateAnisoAlpha3 = 16;
ipPlateAnisoAlpha12 = 17;
ipPlateAnisoViscosity = 18;
ipPlateAnisoDampingRatio = 19;
ipPlateAnisoConductivity1 = 20;
ipPlateAnisoConductivity2 = 21;
ipPlateAnisoSpecificHeat = 22;

% Plate User Defined Materials

% 0..20 user matrix
ipPlateUserTransShearxz = 21;
ipPlateUserTransShearyz = 22;
ipPlateUserTransShearcz = 23;
ipPlateUserDensity = 24;
ipPlateUserAlphax = 25;
ipPlateUserAlphay = 26;
ipPlateUserAlphaxy = 27;
ipPlateUserBetax = 28;
ipPlateUserBetay = 29;
ipPlateUserBetaxy = 30;
ipPlateUserViscosity = 31;
ipPlateUserDampingRatio = 32;
ipPlateUserConductivity1 = 33;
ipPlateUserConductivity2 = 34;
ipPlateUserSpecificHeat = 35;

% Brick Anisotropic Materials

% 0..20 user matrix
ipBrickUserDensity = 21;
ipBrickUserAlpha1 = 22;
ipBrickUserAlpha2 = 23;
ipBrickUserAlpha3 = 24;
ipBrickUserAlpha12 = 25;
ipBrickUserAlpha23 = 26;
ipBrickUserAlpha31 = 27;
ipBrickUserViscosity = 28;
ipBrickUserDampingRatio = 29;
ipBrickUserConductivity1 = 30;
ipBrickUserConductivity2 = 31;
ipBrickUserConductivity3 = 32;
ipBrickUserSpecificHeat = 33;

% Duncan-Chang Soil Materials - Integers
ipSoilDCUsePoisson = 0;
ipSoilDCSetLevel = 1;

% Duncan-Chang Soil Materials - Doubles
ipSoilDCModulusK = 0;
ipSoilDCModulusKUR = 1;
ipSoilDCModulusN = 2;
ipSoilDCPoisson = 3;
ipSoilDCBulkK = 4;
ipSoilDCBulkM = 5;
ipSoilDCFrictionAngle = 6;
ipSoilDCDeltaAngle = 7;
ipSoilDCCohesion = 8;
ipSoilDCFailureRatio = 9;
ipSoilDCFailureMod = 10;
ipSoilDCReferenceP = 11;
ipSoilDCDensity = 12;
ipSoilDCHorizontalRatio = 13;
ipSoilDCConductivity = 14;
ipSoilDCSpecificHeat = 15;
ipSoilDCFluidLevel = 16;

% Cam-Clay Soil Materials - Integers
ipSoilCCUsePoisson = 0;
ipSoilCCDrainedState = 1;
ipSoilCCUseOCR = 2;
ipSoilCCSetLevel = 3;

% Cam-Clay Soil Materials - Doubles
ipSoilCCCriticalStateLine = 0;
ipSoilCCConsolidationLine = 1;
ipSoilCCSwellingLine = 2;
ipSoilCCDensity = 3;
ipSoilCCPoisson = 4;
ipSoilCCModulusG = 5;
ipSoilCCModulusB = 6;
ipSoilCCHorizontalRatio = 7;
ipSoilCCER = 8;
ipSoilCCPR = 9;
ipSoilCCPC0 = 10;
ipSoilCCOCR = 11;
ipSoilCCConductivity = 12;
ipSoilCCSpecificHeat = 13;
ipSoilCCFluidLevel = 14;

% Mohr-Coulomb Soil Materials - Integers
ipSoilMCSetLevel = 0;

% Mohr-Coulomb Soil Materials - Doubles
ipSoilMCModulus = 0;
ipSoilMCPoisson = 1;
ipSoilMCDensity = 2;
ipSoilMCHorizontalRatio = 3;
ipSoilMCER = 4;
ipSoilMCConductivity = 5;
ipSoilMCSpecificHeat = 6;
ipSoilMCFluidLevel = 7;
ipSoilMCCohesion = 8;
ipSoilMCFrictionAngle = 9;

% Drucker-Prager Soil Materials - Integers
ipSoilDPSetLevel = 0;

% Drucker-Prager Soil Materials - Doubles
ipSoilDPModulus = 0;
ipSoilDPPoisson = 1;
ipSoilDPDensity = 2;
ipSoilDPHorizontalRatio = 3;
ipSoilDPER = 4;
ipSoilDPConductivity = 5;
ipSoilDPSpecificHeat = 6;
ipSoilDPFluidLevel = 7;
ipSoilDPCohesion = 8;
ipSoilDPFrictionAngle = 9;

% Linear Elastic Soil Materials - Integers
ipSoilLSSetLevel = 0;

% Linear Elastic Soil Materials - Doubles
ipSoilLSModulus = 0;
ipSoilLSPoisson = 1;
ipSoilLSDensity = 2;
ipSoilLSHorizontalRatio = 3;
ipSoilLSER = 4;
ipSoilLSConductivity = 5;
ipSoilLSSpecificHeat = 6;
ipSoilLSFluidLevel = 7;

% Fluid Materials
ipFluidModulus = 0;
ipFluidPenaltyParam = 1;
ipFluidDensity = 2;
ipFluidAlpha = 3;
ipFluidViscosity = 4;
ipFluidDampingRatio = 5;
ipFluidConductivity = 6;
ipFluidSpecificHeat = 7;

% Mohr-Coulomb, Drucker-Prager
ipFrictionAngle = 0;
ipCohesion = 1;

% Rubber Materials
ipRubberBulk = 0;
ipRubberDensity = 1;
ipRubberAlpha = 2;
ipRubberViscosity = 3;
ipRubberDampingRatio = 4;
ipRubberConductivity = 5;
ipRubberSpecificHeat = 6;
ipRubberConstC1 = 7;

% Load Case Types
ltLoadCase = 0;
ltSeismicCase = 1;
ltSpectralCase = 2;

% Polygon to Face - Doubles
ipPolyToFaceEdgeTolerance = 0;

% Polygon to Face - Integers
ipPolyToFaceFaceID = 0;
ipPolyToFaceGroupIndex = 1;
ipPolyToFacePropertyNumber = 2;
ipPolyToFaceDeleteBeams = 3;
ipPolyToFaceKeepSelected = 4;

% Beam Property
ipBeamPropBeamType = 0;
ipBeamPropSectionType = 1;
ipBeamPropMirrorType = 2;
ipBeamPropCompatibleTwist = 3;

% Element Axis Types
axUCS = 0;
axLocal = 1;

% Load Path Template - Integers
ipLPTColour = 0;
ipLPTNumLanes = 1;
ipLPTMultiLaneType = 2;
lpAllSameFactors = 0;
lpAllDifferentFactors = 1;

% Load Path Template - Doubles
ipLPTTolerance = 0;
ipLPTMinLaneWidth = 1;

% Load Path Vehicle - Integers
ipLPTVehicleInstance = 0;
ipLPTVehicleDirection = 1;
lpVehicleSingleLane = 0;
lpVehicleDoubleLane = 1;
lpVehicleForward = 0;
lpVehicleBackward = 1;

% Load Path Vehicle - Doubles
ipLPTVehicleVelocity = 0;
ipLPTVehicleStartTime = 1;

% Load Path Template Forces - Integers
ipLPTMobility = 0;
ipLPTAxisSystem = 1;
ipLPTAdjacency = 2;
ipLPTCentrifugal = 3;
lpPointForceMobilityGrouped = 0;
lpPointForceMobilityFloating = 1;
lpDistrForceMobilityGrouped = 0;
lpDistrForceMobilityLeading = 1;
lpDistrForceMobilityTrailing = 2;
lpDistrForceMobilityFullLength = 3;
lpDistrForceMobilityFloating = 4;
lpAxisLocal = 0;
lpAxisGlobal = 1;

% Load Path Templates - Integers
ipLPTLimitK1 = 0;
ipLPTLengthUnit = 1;
ipLPTForceUnit = 2;

% Load Path Templates - Doubles
ipLPTMinK1 = 0;
ipLPTMaxK1 = 1;

% Combined Result Files
rfCombFactors = 0;
rfCombSRSS = 1;

% Load Path
ipLoadPathCase = 0;
ipLoadPathTemplate = 1;
ipLoadPathShape = 2;
ipLoadPathSurface = 3;
ipLoadPathTarget = 4;
ipLoadPathDivisions = 5;
lpShapeStraight = 0;
lpShapeCurved = 1;
lpShapeQuadratic = 2;
lpSurfaceFlat = 0;
lpSurfaceCurved = 1;

% Animation
ipAniParentHandle = 0;
ipAniCase = 1;
ipNumFrames = 2;
ipAniWidth = 3;
ipAniHeight = 4;
ipAniType = 5;
kAniSAF = 0;
kAniEXE = 1;
kAniAVI = 2;

% Custom Result Files - NODEDISP, NODEREACT
ipNodeResFileDX = 0;
ipNodeResFileDY = 1;
ipNodeResFileDZ = 2;
ipNodeResFileRX = 3;
ipNodeResFileRY = 4;
ipNodeResFileRZ = 5;

% Custom Result Files - NODETEMP, NODEFLUX
ipNodeResTemp = 0;

% Custom Result Files - BEAMFORCE
ipBeamResFileSF1 = 0;
ipBeamResFileSF2 = 1;
ipBeamResFileAxial = 2;
ipBeamResFileBM1 = 3;
ipBeamResFileBM2 = 4;
ipBeamResFileTorque = 5;
kBeamResFileForceSize = 6;

% Custom Result Files - BEAMSTRAIN
ipBeamResFileAxialStrain = 2;
ipBeamResFileCurvature1 = 3;
ipBeamResFileCurvature2 = 4;
ipBeamResFileTwist = 5;
kBeamResFileStrainSize = 6;

% Custom Result Files - BEAMNODEREACT
ipBeamResFileFX = 0;
ipBeamResFileFY = 1;
ipBeamResFileFZ = 2;
ipBeamResFileMX = 3;
ipBeamResFileMY = 4;
ipBeamResFileMZ = 5;
kBeamResFileReactSize = 6;

% Custom Result Files - BEAMFLUX
ipBeamResFileF = 0;
ipBeamResFileG = 1;
kBeamResFileFluxSize = 2;

% Custom Result Files - PLATESTRESS for PlateShell - Local system
ipPlateShellResFileNxx = 0;
ipPlateShellResFileNyy = 1;
ipPlateShellResFileNxy = 2;
ipPlateShellResFileMxx = 3;
ipPlateShellResFileMyy = 4;
ipPlateShellResFileMxy = 5;
ipPlateShellResFileQxz = 6;
ipPlateShellResFileQyz = 7;
ipPlateShellResFileZMinusSxx = 8;
ipPlateShellResFileZMinusSyy = 9;
ipPlateShellResFileZMinusSxy = 10;
ipPlateShellResFileMidPlaneSxx = 11;
ipPlateShellResFileMidPlaneSyy = 12;
ipPlateShellResFileMidPlaneSxy = 13;
ipPlateShellResFileZPlusSxx = 14;
ipPlateShellResFileZPlusSyy = 15;
ipPlateShellResFileZPlusSxy = 16;
kPlateShellResFileStressSize = 17;

% Custom Result Files - PLATESTRAIN for PlateShell - Local system
ipPlateShellResFileExx = 0;
ipPlateShellResFileEyy = 1;
ipPlateShellResFileExy = 2;
ipPlateShellResFileEzz = 3;
ipPlateShellResFileKxx = 4;
ipPlateShellResFileKyy = 5;
ipPlateShellResFileKxy = 6;
ipPlateShellResFileTxz = 7;
ipPlateShellResFileTyz = 8;
ipPlateShellResFileStoredE = 9;
ipPlateShellResFileSpentE = 10;
kPlateShellResFileStrainSize = 11;

% Custom Result Files - PLATESTRESS for 2D Plates - Global system
ipPlate2DResFileSXX = 0;
ipPlate2DResFileSYY = 1;
ipPlate2DResFileSXY = 2;
ipPlate2DResFileSZZ = 3;
kPlate2DResFileStressSize = 4;

% Custom Result Files - PLATESTRAIN for 2D Plates - Global system
ipPlate2DResFileEXX = 0;
ipPlate2DResFileEYY = 1;
ipPlate2DResFileEXY = 2;
ipPlate2DResFileEZZ = 3;
ipPlate2DResFileStoredE = 4;
ipPlate2DResFileSpentE = 5;
kPlate2DResFileStrainSize = 6;

% Custom Result Files - PLATESTRESS for Axi Plates - Axisymmetric system
ipPlateAxiResFileSRR = 0;
ipPlateAxiResFileSZZ = 1;
ipPlateAxiResFileSTT = 2;
ipPlateAxiResFileSRT = 3;
kPlateAxiResFileStressSize = 4;

% Custom Result Files - PLATESTRAIN for Axi Plates - Axisymmetric system
ipPlateAxiResFileERR = 0;
ipPlateAxiResFileEZZ = 1;
ipPlateAxiResFileETT = 2;
ipPlateAxiResFileERT = 3;
ipPlateAxiResFileStoredE = 4;
ipPlateAxiResFileSpentE = 5;
kPlateAxiResFileStrainSize = 6;

% Custom Result Files - PLATENODEREACT
ipPlateResFileFX = 0;
ipPlateResFileFY = 1;
ipPlateResFileFZ = 2;
ipPlateResFileMX = 3;
ipPlateResFileMY = 4;
ipPlateResFileMZ = 5;
kPlateResFileReactSize = 6;

% Custom Result Files - PLATEFLUX
ipPlateResFileFxx = 0;
ipPlateResFileFyy = 1;
ipPlateResFileGxx = 2;
ipPlateResFileGyy = 3;
kPlateResFileFluxSize = 4;

% Custom Result Files - BRICKSTRESS
ipBrickResFileSXX = 0;
ipBrickResFileSYY = 1;
ipBrickResFileSZZ = 2;
ipBrickResFileSXY = 3;
ipBrickResFileSYZ = 4;
ipBrickResFileSZX = 5;
kBrickResFileStressSize = 6;

% Custom Result Files - BRICKSTRAIN
ipBrickResFileExx = 0;
ipBrickResFileEyy = 1;
ipBrickResFileEzz = 2;
ipBrickResFileExy = 3;
ipBrickResFileEyz = 4;
ipBrickResFileEzx = 5;
ipBrickResFileStoredE = 6;
ipBrickResFileSpentE = 7;
kBrickResFileStrainSize = 8;

% Custom Result Files - BRICKNODEREACT
ipBrickResFileFX = 0;
ipBrickResFileFY = 1;
ipBrickResFileFZ = 2;
kBrickResFileReactSize = 3;

% Custom Result Files - BRICKFLUX
ipBrickResFileFXX = 0;
ipBrickResFileFYY = 1;
ipBrickResFileFZZ = 2;
ipBrickResFileGXX = 3;
ipBrickResFileGYY = 4;
ipBrickResFileGZZ = 5;
kBrickResFileFluxSize = 6;

% Edge Attachment Direction
adPlanar = 0;
adPlusZ = 1;
adMinusZ = 2;

end       % St7APIConst()
