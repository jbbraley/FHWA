function stop = OutputFunction(x, optimValues, state)
stop = false;
iter = optimValues.iteration+1;

Parameters = getappdata(0,'Para_temp');

switch state
    case 'init'
    case 'iter'
        corrValues = getappdata(0,'corrValues');
        Parameters.CorrHistory.FreqRes(:,iter) = corrValues.FreqRes;
        Parameters.CorrHistory.MACRes(:,iter) = corrValues.MACRes;
        Parameters.CorrHistory.pairedMAC(:,iter) = corrValues.pairedMAC;
        Parameters.CorrHistory.pairedModes(:,:,iter) = corrValues.pairedModes;
        Parameters.CorrHistory.ObjFun(iter) = corrValues.ObjFun;
        Parameters.CorrHistory.MAC{iter} = {corrValues.MAC};
        Parameters.CorrHistory.Alpha(:,iter) = corrValues.Alpha;
        Parameters.CorrHistory.AnaDisp{iter} = {corrValues.AnaDisp};
        Parameters.CorrHistory.AnaFreq(:,iter) = corrValues.AnaFreq;  
        Parameters.CorrHistory.COMAC(:,iter) = corrValues.COMAC;
    case 'done'
        rmappdata(0,'corrValues');
end

% Call Plot function
setappdata(0, 'Para_temp', Parameters);
OptPlot(x, optimValues, state);

end %OptStatus