function OptPlot(x, optimValues, state)
% get app data
Options = getappdata(0,'Options');
Parameters = getappdata(0,'Para_temp');
paraData = getappdata(0, 'paraData');
if isempty(optimValues)
    optimValues = getappdata(0,'optimValues');
end
if isempty(optimValues)
   return 
end
% iteration
iter = optimValues.iteration+1;
% Get number of Parameters and bounds
numExpMode = length(Options.Correlation.expModes);
param = size(Parameters.CorrHistory.AlphaBounds,1);
bounds = Parameters.CorrHistory.AlphaBounds;
%% Get slider values
handles = Options.handles.ParameterCorrelation_gui;

switch state
    case 'init'
        cla(handles.axesPara1);
        cla(handles.axesPara2);
        cla(handles.axesPara3);
        cla(handles.axesMACResidual);
        cla(handles.axesFreqResidual);
        cla(handles.axesObjFunction);
        
        if param > 1
            set(handles.sliderPara1,'enable','on')
            set(handles.sliderPara1,'Value',1);
            set(handles.sliderPara1,'min',1,'max',param);
            set(handles.sliderPara1,'SliderStep',[1/(param-1) 1/(param-1)]);
            
            set(handles.sliderPara2,'enable','on')
            set(handles.sliderPara2,'Value',2);
            set(handles.sliderPara2,'min',1,'max',param);
            set(handles.sliderPara2,'SliderStep',[1/(param-1) 1/(param-1)]);
        else
            set(handles.sliderPara1,'enable','off')
            set(handles.sliderPara1,'Value',1);  
            set(handles.sliderPara2,'enable','off')
            set(handles.sliderPara2,'Value',1);
        end
        
        if param > 2
            set(handles.sliderPara3,'enable','on')
            set(handles.sliderPara3,'Value',3);
            set(handles.sliderPara3,'min',1,'max',param);
            set(handles.sliderPara3,'SliderStep',[1/(param-1) 1/(param-1)]);    
        else
            set(handles.sliderPara3,'enable','off')
            set(handles.sliderPara3,'Value',1)
        end   
    case 'iter'
        % Update Freq Tables
        UpdateNatFreqTables();
        
        % Update Mode Shapes
        PlotModeShapes('Ana');

        % Plot MAC
        PlotMAC('Ana');
        
         % Update Parameters
        UpdateParameterTable(Parameters, Options, [], 'Init', []);
        
        % Update Alpha Table
        UpdateAlphaTable(Parameters, Options, 'Iter');
        
        % Plot freq residual
        scale = 'lin';
        yData = abs(Parameters.CorrHistory.FreqRes);
        xData = 1:iter;
        bound = [0,1];
        PlotEvent(handles.axesFreqResidual, xData, yData, bound, [], 'res');
        
        % Plot Mac residual
        scale = 'lin';
        yData = Parameters.CorrHistory.MACRes;
        bound = [0,1];
        PlotEvent(handles.axesMACResidual, xData, yData, bound, [], 'res');
        
        % plot objective function
        scale = 'lin';
        yData = Parameters.CorrHistory.ObjFun;
        bound = [0,1.2*max(yData)];
        PlotEvent(handles.axesObjFunction, xData, yData, bound, [], 'res');
        
        % Plot alpha values
        % plot using regular or semilog based on scale
        % Axes 1
        sv = get(handles.sliderPara1, 'Value');
        yData = Parameters.CorrHistory.Alpha(sv, :);
        scale = Parameters.CorrHistory.AlphaScale{sv};
        PlotEvent(handles.axesPara1, xData, yData, bounds(sv,:), sv, 'alpha');
        
        % Axes 2
        if param > 1
            sv = get(handles.sliderPara2, 'Value');
            yData = Parameters.CorrHistory.Alpha(sv, :);
            scale = Parameters.CorrHistory.AlphaScale{sv};
            PlotEvent(handles.axesPara2, xData, yData, bounds(sv,:), [], 'alpha');
        end
            
        % Axes 3
        if param > 2
            sv = get(handles.sliderPara3, 'Value');
            yData = Parameters.CorrHistory.Alpha(sv, :);
            scale = Parameters.CorrHistory.AlphaScale{sv};
            PlotEvent(handles.axesPara3, xData, yData, bounds(sv,:), [], 'alpha');
        end
        setappdata(0,'optimValues',optimValues);      
    case 'done'   
    otherwise
end

% formatColorScheme(handles.guiSingleModelCorrelation);
end %OptPlot
