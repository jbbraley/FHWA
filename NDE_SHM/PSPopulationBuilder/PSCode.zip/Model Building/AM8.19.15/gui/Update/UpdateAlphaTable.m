function UpdateAlphaTable(Parameters, Options, State)
if isempty(Parameters)
    Parameters = getappdata(0,'Parameters');
end
if isempty(Options)
    Options = getappdata(0,'Options');
end

handles = Options.handles.ParameterCorrelation_gui;

switch State
    case 'Init'
        % format table
        columnWidth = {100, 65, 65, 65, 65, 65};
        editable = false(1,length(columnWidth));
        columnNames = {'Parameter', 'Alpha', 'Start', '% Chg Strt', 'Avg', '% Chg Avg'};
        columnFormat = {'char', 'numeric', 'numeric', 'numeric', 'numeric', 'numeric'};
        set(handles.tableAlphas, 'ColumnEditable', editable, ...
            'ColumnName', columnNames, ...
            'ColumnWidth', columnWidth, ...
            'ColumnFormat', columnFormat);
    case 'Iter'
        % get values
        names = Parameters.CorrHistory.ParaNames;
        startAlpha = Parameters.CorrHistory.AlphaStart;
        currentAlpha = Parameters.CorrHistory.Alpha(:,end);
        meanAlpha = mean(Parameters.CorrHistory.Alpha,2);
        deltaCurrent = (startAlpha - currentAlpha)./startAlpha*100;
        deltaMean = (meanAlpha - currentAlpha)./meanAlpha*100;
        for i = 1:length(names)
            if length(names{i}) > 1
                Data{i,1} = strjoin(names{i}',', ');
            else
                Data(i,1) = names{i};
            end
        end
        Data(:,2) = num2cell(currentAlpha);
        Data(:,3) = num2cell(startAlpha);
        Data(:,4) = num2cell(deltaCurrent);
        Data(:,5) = num2cell(meanAlpha);
        Data(:,6) = num2cell(deltaMean);
        % Fill out table
        set(Options.handles.ParameterCorrelation_gui.tableAlphas, 'Data', Data);
end
end

                