function UpdateParameterTable(Parameters, Options, paraData, State, eventdata)
if isempty(Parameters)
    Parameters = getappdata(0,'Parameters');
end
if isempty(Options)
    Options = getappdata(0,'Options');
end
if isempty(paraData)
    paraData = getappdata(0,'paraData');
end


try
    handles = Options.handles.EditParameters_gui;
switch State
    case 'Init'
        paraData = ConvertParameterTable(Parameters, {});
        
        % parameters
        columnWidth = {100, 45, 40, 45, 80, 40, 50, 65, 50, 50, 45, 80, 80, 80};
        editable = [true(1,length(columnWidth)-1), false];
        columnNames = {'Parameter', 'Prop #', 'Ele', 'Grp #', 'Value', 'Type', 'Update?', 'Alpha', 'A Min', 'A Max', 'Scale', 'Min', 'Max', 'Result'};
        columnFormat = {'char', 'numeric', 'char', 'numeric', 'numeric', 'char', 'logical', 'numeric', 'numeric', 'numeric', {'lin', 'log'}, 'numeric', 'numeric', 'numeric'};
        set(handles.tableParameterValues, 'ColumnEditable', editable, ...
                                          'ColumnName', columnNames, ...
                                          'ColumnWidth', columnWidth, ...
                                          'ColumnFormat', columnFormat);
                                      
    case 'Update'
        paraData = get(handles.tableParameterValues, 'Data');
        paraData(cellfun(@isempty,paraData(:,4)),4) = num2cell(0);

        % Check for table edit
        if ~isempty(eventdata)
            % Get row and column indices
            row = eventdata.Indices(1);
            col = eventdata.Indices(2);
            
            % Check for deletes
            if isnan(eventdata.NewData)
                paraData(row, col) = cell(1,1);
            end
            
            % Deal with updated Data
            oldData = eventdata.PreviousData;
            newData = eventdata.NewData;
            if ~all(oldData == newData) % if change in data, proceed
                
                % Update Box
                if col == 7 && newData % check if update box was changed and changed to true
                    paraData(row,4) = {max(cell2mat(paraData(:,4)))+1}; % add new group #
                
                % Other Changes
                elseif paraData{row,7} % make sure being updated
                    groupNum = paraData{row,4};  % Get group number
                    groupList = find(cell2mat(paraData(:,4)) == groupNum);
                    
                    % Changes to alphaa/value/max/min
                    for i=1:length(groupList)
                        ind = groupList(i);
                        paraData(ind,col) = {newData};
                        
                        if col == 11 % change in scale
                            switch paraData{row,11}
                                case 'lin'
                                    paraData(ind,8:10) = num2cell(Options.Correlation.linDefaults);
                                    paraData(ind,12:13) = num2cell(paraData{ind,5}*cell2mat(paraData(ind,9:10)));
                                case 'log'
                                    paraData(ind,8:10) = num2cell(Options.Correlation.logDefaults);
                                    paraData(ind,12:13) = num2cell(paraData{ind,5}.*10.^cell2mat(paraData(ind,9:10)));
                            end
                        elseif col == 5 % Change in value, change alpha
                            switch paraData{row,11} 
                                case 'lin'
                                    paraData(ind,9) = num2cell(paraData{ind,12}/paraData{ind,5});
                                    paraData(ind,10) = num2cell(paraData{ind,13}/paraData{ind,5});
                                case 'log'
                                    paraData(ind,9) = num2cell(log10(paraData{ind,12}/paraData{ind,5}));
                                    paraData(ind,10) =  num2cell(log10(paraData{ind,13}/paraData{ind,5}));
                            end
                        elseif any(col == 9:10) % value, scale, or alpha min/max - change min/max values
                            switch paraData{row,11}
                                case 'lin'
                                    paraData(ind,col+3) = num2cell(paraData{ind,5}*paraData{ind,col});
                                case 'log'
                                    paraData(ind, col+3) = num2cell(paraData{ind,5}*10.^paraData{ind,col});
                            end
                        elseif any(col == 12:13) % value min/max - change alphas
                            switch paraData{row,11}
                                case 'lin'
                                    paraData(ind,col-3) = num2cell(paraData{ind,col}/paraData{ind,5});
                                case 'log'
                                    paraData(ind,col-3) = num2cell(log10(paraData{ind,col}/paraData{ind,5}));
                            end
                        end
                    end
                end
            end
        end
        
        % put blanks back for 0 group
        paraData(cell2mat(paraData(:,4)) == 0,4) = {[]};
    case 'Replace'
        % Replaces Parameter values, min, max, etc with current alpha value
        for i = find(cell2mat(paraData(:,7))==1)'
            switch paraData{i,11}
                case 'lin'
                    % Change actual values
                    paraData{i,5} = paraData{i,5}*paraData{i,8};
                    % Change alpha to match (1)
                    paraData{i,8} = 1;
                    % change alpha bounds
                    paraData(i,9:10) = num2cell(cell2mat(paraData(i,12:13))/paraData{i,5});           
                case 'log'
                    % Change actual values
                    paraData{i,5} = paraData{i,5}*10^paraData{i,8};
                    % Change alpha to match (0)
                    paraData{i,8} = 0;
                    % change alpha bounds
                    paraData(i,9:10) = num2cell(log10(cell2mat(paraData(i,12:13))/paraData{i,5}));    
            end
        end
end
catch
    return
end

for i = find(cell2mat(paraData(:,7))==1)'
    switch paraData{i,11}
        case 'lin'
            % Get resultant value
            paraData(i,14) = num2cell(cell2mat(paraData(i,5))*cell2mat(paraData(i,8)));
        case 'log'
            % Get resultant value
            paraData(i,14) = num2cell(cell2mat(paraData(i,5))*10^cell2mat(paraData(i,8)));
    end
end


% Sort group #s
paraData = SortUpdatingGroups(paraData);
% Set tables
set(handles.tableParameterValues, 'Data', paraData);
end %UpdateParameterTable()