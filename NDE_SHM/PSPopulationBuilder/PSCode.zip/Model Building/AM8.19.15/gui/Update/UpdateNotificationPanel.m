function UpdateNotificationPanel(hObject, msg, type)
switch type
    case 'append' % to current line
        panel = get(hObject, 'string');
        panel{end} = [panel{end} msg];
    case 'new' % line, keep old messages above
        panel = get(hObject, 'string');
        panel{end+1} = msg;
    case 'replace' % everything with new msg
        panel = msg;
    case 'delete' % clears window
        panel = [];
    otherwise
end

set(hObject, 'string', panel, 'Value', length(panel));
drawnow
end