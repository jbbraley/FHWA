function UpdateRatingTables(Parameters, Options, State)
if isempty(Parameters)
    Parameters = getappdata(0, 'Parameters');
end
if isempty(Options)
    Options = getappdata(0, 'Options');
end

try
    handles = Options.handles.LoadRating_gui;
    
    switch State
        case 'Init'
            % Set Column headers and clear old data
            columnName = ['Controlling'; cellstr(num2str((1:Parameters.NumGirder)'))];

            % Num Girders in FEA table
            set(handles.tableFEM, 'ColumnName', columnName);
            
            widths = 45*ones(length(columnName),1);
            widths(1) = 60;
            % Column Widths
            set(handles.tableFEM, 'ColumnWidth', num2cell(widths'));
            
            
            SingleLineData = get(handles.tableLineGirder,'Data');
            SingleLineData = cell(size(SingleLineData,1),size(SingleLineData,2));
            set(handles.tableLineGirder,'Data',SingleLineData);
        otherwise
    end
catch
    return
end

end 