function UpdateMassTable(Parameters, Options, meshData, State)
if isempty(Parameters)
    Parameters = getappdata(0, 'Parameters');
end

if isempty(Options)
    Options = getappdata(0, 'Options');
end

if isempty(meshData)
    meshData = getappdata(0, 'meshData');
end

try
    
% get handles if they exist for this GUI
handles = Options.handles.ParameterCorrelation_gui;
set(0,'CurrentFigure',handles.ParameterCorrelation_gui);

% Init or update state
switch State
    % init state
    case 'Init'
        % Set Edit Boxes and Popups
        set(handles.editYDiv, 'String', num2str(Options.MassCorr.YDiv));
        set(handles.editXDiv, 'String', num2str(Options.MassCorr.XDiv));
        
        % Set options for mass table
        set(handles.uitableMass, 'ColumnEditable', [false, true]); %sets the inital mass alpha value as editable
        set(handles.checkboxConstantTotalMass, 'Value', Options.MassCorr.ConstantTotal);
        
        % Mass Table
        massData = cell(Options.MassCorr.numDiv,2);
        massData(:,1) = num2cell(1:Options.MassCorr.numDiv)';
        massData(:,2) = num2cell(Options.MassCorr.massMulti);
        
        % Mass plot
        MassPlot(Parameters, meshData, handles, State);
    % update state
    case 'Replace'
        % get current Y and X divs from GUI
        Options.MassCorr.XDiv = str2double(get(handles.editXDiv,'String'));
        Options.MassCorr.YDiv = str2double(get(handles.editYDiv,'String'));
        
        % Divisions
        Options.MassCorr.numDiv = Options.MassCorr.XDiv * Options.MassCorr.YDiv;
        Options.MassCorr.massMulti = ones(Options.MassCorr.numDiv,1);
        
        % mass table
        Options.MassCorr.ConstantTotal = get(handles.checkboxConstantTotalMass, 'Value');
        
        massData = cell(Options.MassCorr.numDiv,2);
        massData(:,1) = num2cell(1:Options.MassCorr.numDiv)';
        massData(:,2) = num2cell(Options.MassCorr.massMulti);
        
        % Mass plot
        MassPlot(Parameters, meshData, handles, State)
    case 'Update'        
        % mass table
        massData = get(handles.uitableMass, 'Data');
        
       Options.MassCorr.massMulti = num2cell(massData(:,2));
end
catch
end

set(handles.uitableMass, 'Data', massData);

setappdata(0, 'Options', Options);
end

function MassPlot(Parameters, meshData, handles, State)
% Get App Data
% Applied to app data in MassPlot so may be empty if never run
textHandle = getappdata(handles.ParameterCorrelation_gui,'textHandle');
lineHandles = getappdata(handles.ParameterCorrelation_gui,'lineHandles');
pointHandle = getappdata(handles.ParameterCorrelation_gui,'pointHandle');
switch State
    case {'Init', 'Replace'}
        axes(handles.axesMassPlot);
        %% get division dimensions
        xDiv = str2num(get(handles.editXDiv, 'String'));
        yDiv = str2num(get(handles.editYDiv, 'String'));
        
        % get deck geometry
        [yR, yInd] = min(meshData.y);
        xNR = meshData.x(yInd);
        
        % Get Division points
        xDivLength = sum(Parameters.Length)/xDiv;
        yDivLength = Parameters.Width/yDiv;
        xDivPoints = zeros(xDiv+1,yDiv+1);
        yDivPoints = xDivPoints;
        for i = 1:xDiv+1
            for j = 1:yDiv+1
                if Parameters.SkewNear == Parameters.SkewFar
                    xDivPoints(i,j) = xNR + (i-1)*xDivLength + sign(Parameters.SkewNear)*(j-1)*yDivLength*tan(Parameters.SkewNear*pi/180);
                    yDivPoints(i,j) = yR + (j-1)*yDivLength;
                else
                    % Have to add this later
                end
            end
        end
        
        %% get which points are in which division
        % build polygon vectors
        nDiv = 0;
        xv = zeros(xDiv*yDiv,4);
        yv = xv;
        for i = 1:xDiv
            for j = 1:yDiv
                nDiv = nDiv + 1;
                xv(nDiv,:) = [xDivPoints(i,j), xDivPoints(i+1,j), xDivPoints(i+1,j+1), xDivPoints(i,j+1)];
                yv(nDiv,:) = [yDivPoints(i,j), yDivPoints(i+1,j), yDivPoints(i+1,j+1), yDivPoints(i,j+1)];
            end
        end
        % find which nodes are in each polygon
        nodeList = meshData.nodeID;
        zoneNodes = cell(nDiv,1);
        for i = 1:nDiv
            zoneNodes{i} = meshData.nodeID(inpolygon(meshData.x, meshData.y, xv(i,:), yv(i,:)));
            nodeList = nodeList(~ismember(nodeList, zoneNodes{i}));
        end
        % find where in the NodeID list each node number is
        nodeInd = cell(length(zoneNodes),1);
        for i=1:length(zoneNodes)
            [~,nodeInd{i}] = ismember(zoneNodes{i},meshData.nodeID);
        end
              
        % Get mass per point in each division
        zoneMass = zeros(nDiv,1);
        for i=1:nDiv
            area = polyarea(xv(i,:)',yv(i,:)');
            zoneMass(i) = area/length(nodeInd{i})*Parameters.Deck.density*Parameters.Deck.t;
        end
        
%           %% plot mass points
%         % check if previous points need to be cleared
%         pointHandle = getappdata(handles.ParameterCorrelation_gui,'pointHandle');
%         if ~isempty(pointHandle)
%             delete(pointHandle);
%         end
%         pointHandle = [];
%         % plot
%         for i=1:nDiv
%             xPts = meshData.x(nodeInd{i});
%             yPts = meshData.y(nodeInd{i});
%             pointHandle(i) = scatter(yPts, xPts, 1*10^2, '.');
%             hold on
%         end

        %% Plot zone labels
        if ~isempty(textHandle)
            delete(textHandle);
        end
        textHandle = [];
        for i = 1:nDiv
            % Get centroid of zone
            xBar = (max(meshData.x(nodeInd{i})) + min(meshData.x(nodeInd{i})))/2;
            yBar = (max(meshData.y(nodeInd{i})) + min(meshData.y(nodeInd{i})))/2;
            
            % display text
            textCell = {num2str(i)};
            % NOTE: set ah as parent of text object
            textHandle(i) = text(yBar, xBar, 1, textCell, 'fontsize', 12, 'fontweight', 'bold',...
                            'parent',handles.axesMassPlot); % plot z as 1 to keep on top
        end
        
        %% Draw divisions
        % Delete old divisions
        if ~isempty(lineHandles)
            delete(lineHandles);
        end
        % reset lineHandles
        % ! Set z for lines to 1 to put on top of scatter points
        lineHandles = 0;
        nLine = 0;
        for i = 1:xDiv+1
            for j = 1:yDiv+1
                if i ~= xDiv+1
                    nLine = nLine + 1;
                    lineHandles(nLine) = line([yDivPoints(i,j),yDivPoints(i+1,j)],[xDivPoints(i,j),xDivPoints(i+1,j)],[1,1]);
                    set(lineHandles(nLine),'Color','k','LineWidth',2);
                end

                if j ~= yDiv+1
                    nLine = nLine + 1;
                    lineHandles(nLine) = line([yDivPoints(i,j),yDivPoints(i,j+1)],[xDivPoints(i,j),xDivPoints(i,j+1)],[1,1]);
                    set(lineHandles(nLine),'Color','k','LineWidth',2);
                end
            end 
        end
        
        % sets current axes
        axis equal;  
        % set axis reverse
        set(handles.axesMassPlot, 'XDir', 'reverse');
        
        %% Mass Table - equal division
        Data(:,1) = mat2cell((1:length(zoneMass))', ones(length(zoneMass),1));
        Data(:,2) = mat2cell(ones(length(zoneMass),1), ones(length(zoneMass),1));
        set(handles.uitableMass, 'Data', Data); % 4 initial zones
        
        %% set app data
        setappdata(handles.ParameterCorrelation_gui,'lineHandles',lineHandles);
        setappdata(handles.ParameterCorrelation_gui,'nodeInd',nodeInd);
        setappdata(handles.ParameterCorrelation_gui,'zoneNodes',zoneNodes);
        setappdata(handles.ParameterCorrelation_gui,'zoneMass',zoneMass);
        setappdata(handles.ParameterCorrelation_gui,'pointHandle',pointHandle);
        setappdata(handles.ParameterCorrelation_gui,'textHandle',textHandle);
    case 'Iter'
        %% get app data
        zoneNodes = getappdata(handles.ParameterCorrelation_gui,'zoneNodes');
        nodeInd = getappdata(handles.ParameterCorrelation_gui,'nodeInd');
        Alpha = CorrHistory.Alpha{end};
        
        %% Disable editing 
        % for mass table
        set(handles.uitableMass, 'ColumnEditable', [false, false]); 
        % for divisions
        set(handles.editXDiv, 'enable', 'inactive');
        set(handles.editYDiv, 'enable', 'inactive');
        
        %% Plot Redistribution of Mass Points
        axes(handles.axesMassPlot);
        % clear previous points

%         delete(pointHandle);
%         pointHandle = [];
%         % plot
%         hold on
%         for i=1:length(zoneNodes)
%             xPts = meshData.x(nodeInd{i});
%             yPts = meshData.y(nodeInd{i});
%             pointHandle(i) = scatter(yPts, xPts, CorrHistory.Alpha{end}(i)*10^2, '.');
%         end
%         hold off
             
        % set axis reverse
        set(handles.axesMassPlot, 'XDir', 'reverse');
        
        %% Plot Mass Trend
        % Plot mass trend
        axes(handles.axesMassTrend)
        plot(cell2mat(CorrHistory.Alpha)');
        if length(CorrHistory.Alpha)>1
            set(handles.axesMassTrend, 'XLim', [1,length(CorrHistory.Alpha)]);
        end
        
        % Populate mass % table
        Data(:,1) = mat2cell((1:length(Alpha))', ones(length(Alpha),1));
        Data(:,2) = mat2cell(Alpha, ones(length(Alpha),1));
        set(handles.uitableMass, 'Data', Data);
        drawnow
        
        setappdata(handles.ParameterCorrelation_gui,'pointHandle',pointHandle);
        setappdata(handles.ParameterCorrelation_gui,'textHandle',textHandle);
    case 'Done'
        % Enable editing for mass table
        set(handles.uitableMass, 'ColumnEditable', [false, true]); 
        
        % Enablee editing for divisions
        set(handles.editXDiv, 'enable', 'on');
        set(handles.editYDiv, 'enable', 'on');       
end
end