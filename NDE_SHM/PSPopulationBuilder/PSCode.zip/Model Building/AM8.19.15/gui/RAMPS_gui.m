function varargout = RAMPS_gui(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RAMPS_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @RAMPS_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% Opening/Closing Functions -----------------------------------------------
function RAMPS_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for RAMPS_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% get data from root
Options = getappdata(0,'Options'); 

% Set overall handle data
Options.handles.RAMPS_gui = handles;

setappdata(0,'Options',Options);

function varargout = RAMPS_gui_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function RAMPS_gui_CloseRequestFcn(hObject, eventdata, handles)
% Get options from app data to close and unload
Options = getappdata(0,'Options');
CloseAndUnload(Options.St7.uID);

% delete all GUI windows
allNames = fieldnames(getappdata(0));
guiNames = allNames(strncmp('OpenFig',allNames,7));
for i = 1:length(guiNames)
    if getfield(getappdata(0),guiNames{i}) ~= hObject % check to make sure arent deleting main gui
        delete(getfield(getappdata(0),guiNames{i}));
    end
end

delete(hObject);

RemoveAppData();

% Load Files --------------------------------------------------------------

function pushbtnNewModel_Callback(hObject, eventdata, handles)
global luINCH fuPOUNDFORCE suPSI muPOUND tuFAHRENHEIT euBTU

hObject = handles.listboxNotificationPanel;
msg = 'Reseting RAMPS Model Workspace...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

try
    % Get app data
    Options = getappdata(0,'Options');
    
    %% Check for files and ask for name
    % Ask for file name and save dir
    [ModelName, ModelPath] = uiputfile([Options.SaveDir '*.st7'],'Choose Save Directory');
    % error screen no selection
    if all(ModelPath) == 0 || all(ModelName) == 0
        [~, ~] = FileLoadErrorHandling([], Options, handles);
        return
    end
    
    h = waitbar(0.2, 'Creating New St7 Model File...');
    
    % Check is model file is open
    if Options.FileOpen.St7Model
        % Close model file
        St7CloseModelFile(Options.St7.uID);
    end
         
    St7Start = 0;
    [Parameters, Options] = InitializeRAMPS(Options, [], St7Start);
    
    waitbar(0.4,h);
    
    % Set options
    Options.FileOpen.St7Model = 1;
    Options.FileOpen.Parameters = 1;
    Options.FileOpen.Options = 1;
    Options.PathName = ModelPath;
    Options.FileName = ModelName(1:end-4);

    % Clear Node. Reset and overwrite Options and Parameters
    if Options.FileOpen.Node
        clear('Nodes');
        rmappdata(0, 'Node');
    end
    Options.FileOpen.Node = 0;
    
    Units = [luINCH, fuPOUNDFORCE, suPSI, muPOUND, tuFAHRENHEIT, euBTU];
    
    St7NewModel(Options.St7.uID, Options.PathName, Options.FileName, Options.St7.ScratchPath, Units);
    
%     % Assigns properties to beams, barrier, and deck
%     Parameters = InitializeSt7Properties(Options.St7.uID, Parameters);
    
    %% Save files
    iErr = calllib('St7API', 'St7SaveFile', Options.St7.uID);
    HandleError(iErr);
    
    waitbar(0.6,h);
    
    save([Options.PathName Options.FileName '_Para.mat'], 'Parameters', '-v7');
    save([Options.PathName Options.FileName '_Options.mat'], 'Options', '-v7');
    
    %% Call routine to save temp file
    Options = SaveTempFile(Options);
    
    %% Set data to root
    setappdata(0,'Options', Options);
    setappdata(0,'Parameters', Parameters);
    
    waitbar(0.8,h);
    
    %% Update GUI
    % update listbox string
    set(handles.listboxModelFile, 'string', [Options.PathName Options.FileName '.st7']);
    set(handles.listboxMetaData, 'string', [Options.PathName Options.FileName '_Para.mat']);
    
    hObject = handles.listboxNotificationPanel;
    msg = 'DONE';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
    
    close(h);
catch
    [~, ~] = FileLoadErrorHandling([], [], handles);
end

function pushbtnLoadModelFile_Callback(hObject, eventdata, handles)
try
    % Notification Panel
    hObject = handles.listboxNotificationPanel;
    msg = 'Model Loading:...';
    type = 'new';
    UpdateNotificationPanel(hObject, msg, type);
    
    % Get data from root
    Options = getappdata(0, 'Options');
    Parameters = getappdata(0, 'Parameters');
    
    % Check if model is already open, if so, close it
    if Options.FileOpen.St7Model
        CloseModelFile(Options.St7.uID);
    end
    
    try
        % get files from user
        [filename, pathname] = uigetfile({'*.st7'  , 'All Files (*.st7)'}, ...
            'Select model file', ...
            'MultiSelect' , 'off');
    catch
        return
    end
    
    % error screen no selection
    if isequal(pathname,0) || isequal(filename,0)
        return
    end
    
    % Create full file name
    fullnames = {fullfile(pathname,filename)};
    
    % Define Model Name
    fname = filename(1:end-4);
    
    % Set model and path names to options
    Options.FileName = fname;
    Options.PathName = pathname;
    
    % Load St7 Files
    St7OpenModelFile(Options.St7.uID, Options.PathName, Options.FileName, Options.St7.ScratchPath)
    Options.FileOpen.St7Model = 1;
    
    % Save and open temp
    Options = SaveTempFile(Options);
    
    % set data to root
    setappdata(0, 'Options', Options);
    setappdata(0, 'Parameters', Parameters);
    
    % update listbox string
    set(handles.listboxModelFile, 'string', fullnames);
    
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = [fname '...DONE'];
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
    
    % Handle Metadata
    pushbtnLoadMetaData_Callback(handles.pushbtnLoadMetaData, eventdata, handles)
catch
   [~, ~] = FileLoadErrorHandling([], Options, handles);
end    

function pushbtnSaveModelFile_Callback(hObject, eventdata, handles)
% Display metadata loading messages
hObject = handles.listboxNotificationPanel;
msg = 'Saving Model File...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

try
    % get app data
    Options = getappdata(0, 'Options');
    
    % check if st7 model currently open
    if Options.FileOpen.St7Model
        Node = getappdata(0, 'Node');
        Parameters = getappdata(0, 'Parameters');
        
        % get files from user
        [filename, pathname] = uiputfile({'*.*', 'All Files (*.*)'}, ...
            'Save model file', ...
            [Options.PathName Options.FileName '.st7']);
        
        % error screen no selection
        if isequal(pathname,0) || isequal(filename,0)
            return
        end
        
        % new file names
        Options.PathName = pathname;
        Options.FileName = filename(1:end-4);
        
        % Update model parameters
        Parameters = SetModelParameters(Options.St7.uID, Parameters, Node);
        
        % save original
        % Save actual file by overwriting
        St7SaveFileAs(Options.St7.uID, Options.PathName, Options.FileName);
        
        % save temp 
        Options = SaveTempFile(Options);
        
        % Set app data 
        setappdata(0, 'Options', Options);
        setappdata(0, 'Parameters', Parameters);
        
        % update listbox string
        set(handles.listboxModelFile, 'string', [pathname filename]);
        
        % Display metadata loading messages
        hObject = handles.listboxNotificationPanel;
        msg = 'DONE';
        type = 'append';
        UpdateNotificationPanel(hObject, msg, type);
        
        % save metadata
        pushbtnSaveMetaData_Callback(hObject, eventdata, handles)
    else
        % Display metadata loading messages
        hObject = handles.listboxNotificationPanel;
        msg = 'FILE NOT OPEN';
        type = 'append';
        UpdateNotificationPanel(hObject, msg, type);
        
        return
    end
catch
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'FAILED';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
end

function pushbtnCloseModelFile_Callback(hObject, eventdata, handles)
% Display metadata loading messages
hObject = handles.listboxNotificationPanel;
msg = 'Close St7 File...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);
try
    % get app data
    Options = getappdata(0, 'Options');
    
    % check if st7 model currently open
    if Options.FileOpen.St7Model
        St7CloseModelFile(Options.St7.uID);
    end
    
    Options.FileOpen.St7Model = 0;
    
    setappdata(0, 'Options', Options);
    
     % update listbox string
    set(handles.listboxModelFile, 'string', '');
    
    % Display messages
    hObject = handles.listboxNotificationPanel;
    msg = 'DONE';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
catch
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'FAILED';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
end

function listboxModelFile_Callback(hObject, eventdata, handles)

function pushbtnLoadMetaData_Callback(hObject, eventdata, handles)
% Display metadata loading messages
hObject = handles.listboxNotificationPanel;
msg = 'Meta Data Loading...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

try
    % Get data from root
    Options = getappdata(0, 'Options');
    Parameters = getappdata(0, 'Parameters');
    testData = getappdata(0, 'testData');
    
    % Check for metadata
    % Check if filenames exist in directory
    % Try to get filename if it's loaded...if metadata was cleared you have
    % to pick fiels manually
    fname = Options.FileName;
    pathname = Options.PathName;
    meta_fnames = {};
    
    % parameters
    if exist([pathname fname '_Para.mat'],'file')==2
        meta_fnames{end+1} = fullfile(pathname,[fname '_Para.mat']);
    else
        % Ask for files
        [filename, pathname] = uigetfile({'*.mat'  , 'All Files (*.mat)'}, ...
            'Select Parameters File or Cancel', ...
            [pathname fname '_Para.mat']);
        
        if ~isequal(pathname,0) && ~isequal(filename,0)
            meta_fnames{end+1} = fullfile(pathname, filename);
        end
    end
    % nodes
    if exist([pathname fname '_Node.mat'],'file')==2
        meta_fnames{end+1} = fullfile(pathname,[fname '_Node.mat']);
    else
        % Ask for files
        [filename, pathname] = uigetfile({'*.mat'  , 'All Files (*.mat)'}, ...
            'Select Node File or Cancel', ...
            [pathname fname '_Node.mat']);
        
        if ~isequal(pathname,0) && ~isequal(filename,0)
            meta_fnames{end+1} = fullfile(pathname, filename);
        end
    end
    
    % Load meta .mat files
    for ii = 1:length(meta_fnames)
        try
            load(meta_fnames{ii}); % load file
            
            % Set filenames and file open status to options
            if strcmp('Para',meta_fnames{ii}(end-7:end-4)) % checks what type of metadata
                Options.FileOpen.Parameters = 1;
                Options.FileNames.Parameters = meta_fnames{ii};
            elseif strcmp('Node',meta_fnames{ii}(end-7:end-4))
                Options.FileOpen.Node = 1;
                Options.FileNames.Node = meta_fnames{ii};
            end
            
        catch
            if strcmp('Para',meta_fnames{ii}(end-7:end-4))
                Options.FileOpen.Parameters = 0;
                Options.FileNames.Parameters = [];
            elseif strcmp('Node',meta_fnames{ii}(end-7:end-4))
                Options.FileOpen.Node = 0;
                Options.FileNames.Node = [];
            end
        end
    end

    % Set filename and Pathname to Options in case loaded options file doesn't
    % match
    Options.FileName = fname;
    Options.PathName = pathname;
    
    % Save data to root
    setappdata(0,'Parameters',Parameters);
    setappdata(0,'Options',Options);
    if Options.FileOpen.Node
        setappdata(0,'Node',Node);

        % Get all node coords and IDs From Node
        meshData.ID = nonzeros(vertcat(Node.ID));
        meshData.x = horzcat(Node.x)';
        meshData.y = horzcat(Node.y)';
        
        % call function to sort nodes into grid and get boundaries
        meshData = GetAnaMesh(Node);

        % Upload Data to App Data
        setappdata(0, 'meshData', meshData);
    end
    
    % display file names
    set(handles.listboxMetaData, 'String', meta_fnames);
    
    % Update Geometry Info
    State = 'Init';
    UpdateGeometryTables(Parameters,Options,State);
    UpdateDiaTables(Parameters,Options);
    UpdateParameterTable(Parameters, Options, [], State, []);
    UpdateSteelGirderGUI(Parameters,Options,State);
    
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'DONE';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
catch
    % display file names
    set(handles.listboxMetaData, 'String', '');
    
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'FAILED';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
end

function pushbtnClearMetaData_Callback(hObject, eventdata, handles)
Options = getappdata(0, 'Options');

% Get current handles structure in Options and save
handlesTemp = Options.handles;

% Clear meta data files from memory
clear Parameters Options Node

% Remove app data
allNames = fieldnames(getappdata(0));
if any(strcmp('Parameters',allNames));
rmappdata(0, 'Parameters');
end
if any(strcmp('Options',allNames));
rmappdata(0, 'Options');
end
if any(strcmp('Node',allNames));
rmappdata(0, 'Node');
end
if any(strcmp('meshData',allNames));
rmappdata(0, 'meshData');
end

% Clear meta data list box
msg = [];
set(handles.listboxMetaData, 'String', msg);

% Notification Panel
hObject = handles.listboxNotificationPanel;
msg = 'Meta Data Cleared.';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

% Reset Basic app data
St7Start = 0;
Options = [];
Parameters = [];
[Parameters, Options] = InitializeRAMPS(Options, Parameters, St7Start);

Options.Handles = handlesTemp;

% set data to root
setappdata(0,'Parameters',Parameters);
setappdata(0,'Options',Options);

% Update Geometry Info
State = 'Init';
UpdateParameterTable(Parameters, Options, [], State, []);
UpdateGeometryTables(Parameters,Options,State);
UpdateDiaTables(Parameters,Options);

        
function pushbtnSaveMetaData_Callback(hObject, eventdata, handles)
% Display metadata loading messages
hObject = handles.listboxNotificationPanel;
msg = 'Saving Meta Data...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

msg = [];
set(handles.listboxMetaData, 'String', msg);

try
    % get app data
    Options = getappdata(0, 'Options');
    
    % check if st7 model currently open
    if Options.FileOpen.Node
        % get Parameters and Node
        Node = getappdata(0, 'Node');

        % Get all node coords and IDs From Node
        meshData.ID = nonzeros(vertcat(Node.ID));
        meshData.x = horzcat(Node.x)';
        meshData.y = horzcat(Node.y)';
        
        % call function to sort nodes into grid and get boundaries
        meshData = GetAnaMesh(Node);
     
        % Upload Data to App Data
        setappdata(0, 'meshData', meshData);
        
        % get files from user
        [filename, pathname] = uiputfile({'*.*', 'All Files (*.*)'}, ...
            'Save Node File', ...
            [Options.PathName Options.FileName '_Node.mat']);
        
        % error screen no selection
        if ~pathname == 0
            % Save Node File
            save([pathname filename], 'Node');
        end
        
        % Put name in listbox
        set(handles.listboxMetaData, 'String', [pathname filename]);
    end
    
    % check if st7 model currently open
    if Options.FileOpen.Parameters
        % get Parameters and Node
        Parameters = getappdata(0, 'Parameters');
        
        % get files from user
        [filename, pathname] = uiputfile({'*.*', 'All Files (*.*)'}, ...
            'Save Parameters File', ...
            [Options.PathName Options.FileName '_Para.mat']);
        
        % error screen no selection
        if ~pathname == 0
            % Save Parameters File
            save([pathname filename], 'Parameters');
        end
        
        % Put name in listbox
        msg = cell(2,1);
        msg{1} = get(handles.listboxMetaData, 'String');
        if ~strcmp(msg{1},'')
            msg{2} = [pathname filename];
        else
            msg = [pathname filename];
        end
        set(handles.listboxMetaData, 'String', msg);
    end
    
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'DONE';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
    
catch
    % Display metadata loading messages
    hObject = handles.listboxNotificationPanel;
    msg = 'FAILED';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
end

function listboxMetaData_Callback(hObject, eventdata, handles)
metaName = get(hObject, 'String');
num = get(hObject, 'value');
if iscell(metaName)
    evalin('base',sprintf('load(''%s'')',metaName{num}));
else
    evalin('base',sprintf('load(''%s'')',metaName));
end

function pushbtnLoadTestData_Callback(hObject, eventdata, handles)
% Notification Panel
hObject = handles.listboxNotificationPanel;
msg = 'Test Data Loading...';
type = 'new';
UpdateNotificationPanel(hObject, msg, type);

try
    % Get data from root
    Options = getappdata(0, 'Options');
    
    % get files from user
    [filename, pathname] = uigetfile({'*.*'  , 'All Files (*.*)'}, ...
        'Select Test File', ...
        'MultiSelect' , 'off');
    
    % error screen no selection
    if pathname == 0
        return
    end
    
    % Create full file name
    fullnames = fullfile(pathname,filename);
    
    % Check if file is formatted or need to be imported
    loadRes = load(fullnames);
    if ~isfield(loadRes, 'testData') % not in imported format
        % Check for Metadata Files
        if ~Options.FileOpen.Parameters || ~Options.FileOpen.Node
            pushbtnLoadMetaData_Callback(handles.pushbtnLoadMetaData, eventdata, handles)
        end
        
        % import test data
        h = ImportTestData_gui(loadRes.results);
        waitfor(h);
        
        % Get full file name of formatted test data
        testFileName = getappdata(0, 'testFileName');
        testPathName = getappdata(0, 'testPathName');
        % rmeove from app data
        rmappdata(0, 'testFileName');
        rmappdata(0, 'testPathName');
        
        % load file
        loadRes = load(fullfile(testPathName,testFileName));
    end  
    testData = loadRes.testData;
    
    % update listbox string
    set(handles.listboxTestData, 'string', fullnames);
    
    % Set test data flag to open
    Options.FileOpen.TestData = 1;
    
    % Add all expModes to Options files
    Options.Correlation.expModes = [1:length(testData.freq)]';
    
    % get exp/exp MAC
    testData.MAC = GetMACValue(testData.U, testData.U);
    testData.COMAC = GetCOMACValue(testData.U, testData.U);
    
    % Set data to root
    setappdata(0,'Options',Options);
    setappdata(0,'testData',testData);
  
    % Dynamic plots
    if isfield(Options.handles, 'ModelExperimentComparison_gui');
        plotType = 'Exp';
        PlotModeShapes(plotType);
        PlotMAC(plotType);
        UpdateNatFreqTables();
    end
    
    % if all model files are open, run new natural frequency analysis
    if Options.FileOpen.Node && Options.FileOpen.St7Model
        if Options.Analysis.NumModes < length(Options.Correlation.expModes)
            Options.Analysis.NumModes = length(Options.Correlation.expModes);
            setappdata(0,'Options',Options);
        end
        
        meshData = getappdata(0,'meshData');
        
        % get freqs and mode shapes
        meshData = LoadNaturalFrequencyData(Options, meshData, meshData.nodeID); % calls function to run solver, get results, and save data to meshData
        repairCoord = 1;
        repairMAC = 1;
        meshData = NaturalFrequencyComparison(Options, meshData, testData, repairCoord, repairMAC);
        
        setappdata(0,'meshData', meshData);
        if isfield(Options.handles, 'ModelExperimentComparison_gui')
            plotType = 'Ana';
            PlotModeShapes(Options.handles.ModelExperimentComparison_gui, plotType);
            PlotMAC(Options.handles.ModelExperimentComparison_gui,plotType);
            UpdateNatFreqTables(Options.handles.ModelExperimentComparison_gui);
        end
    end
     
    % Notification Panel
    hObject = handles.listboxNotificationPanel;
    msg = 'DONE';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type); 
catch
    % Set test data flag to open
    Options.FileOpen.TestData = 1;
    
    % Set data to root
    setappdata(0,'Options',Options);
    
    % Notification Panel
    hObject = handles.listboxNotificationPanel;
    msg = 'FAILED!';
    type = 'append';
    UpdateNotificationPanel(hObject, msg, type);
end

function listboxTestData_Callback(hObject, eventdata, handles)

% Notification Panel ------------------------------------------------------

function pushbtnClearNotificationPanel_Callback(hObject, eventdata, handles)
UpdateNotificationPanel(handles.listboxNotificationPanel, [], 'delete');

function listboxNotificationPanel_Callback(hObject, eventdata, handles)

% Subfunction Buttons -----------------------------------------------------

% Build Model -------

function pushbtnNBIData_Callback(hObject, eventdata, handles)
NBIData_gui();

function pushbtnGeo_Callback(hObject, eventdata, handles)
UserInputDeck_gui();

function pushbtnDiaphragm_Callback(hObject, eventdata, handles)
SteelDiaSection_gui();

function pushbtnGirders_Callback(hObject, eventdata, handles)
SteelGirder_gui();

function pushbtnBuildFEM_Callback(hObject, eventdata, handles)
global luINCH fuPOUNDFORCE suPSI muPOUND tuFAHRENHEIT euBTU;

% Build Model
h = waitbar(0.2,'Please Wait While Bridge Model is Created...');

% Get data from root
Parameters = getappdata(0,'Parameters');
Options = getappdata(0,'Options');

waitbar(0.4,h);

if ~Options.FileOpen.St7Model
    %% Check for files and ask for name
    % Ask for file name and save dir
    [ModelName, ModelPath] = uiputfile([Options.SaveDir '*.st7'],'Choose Save Directory');
    % error screen no selection
    if all(ModelPath) == 0 || all(ModelName) == 0
        [~, ~] = FileLoadErrorHandling([], Options, handles);
        return
    end
    
    Options.PathName = ModelPath;
    Options.FileName = ModelName(1:end-4);
    
    Units = [luINCH, fuPOUNDFORCE, suPSI, muPOUND, tuFAHRENHEIT, euBTU];
    
    St7NewModel(Options.St7.uID, Options.PathName, Options.FileName, Options.St7.ScratchPath, Units);
    
    %% Save files
    iErr = calllib('St7API', 'St7SaveFile', Options.St7.uID);
    HandleError(iErr);
    
    waitbar(0.6,h);
    
    save([Options.PathName Options.FileName '_Para.mat'], 'Parameters', '-v7');
    save([Options.PathName Options.FileName '_Options.mat'], 'Options', '-v7');
    
    %% Call routine to save temp file
    Options = SaveTempFile(Options);
    
    %% Set data to root
    setappdata(0,'Options', Options);
    setappdata(0,'Parameters', Parameters);
    
    waitbar(0.8,h);
    
    %% Update GUI
    % update listbox string
    set(handles.listboxModelFile, 'string', [Options.PathName Options.FileName '.st7']);
    set(handles.listboxMetaData, 'string', [Options.PathName Options.FileName '_Para.mat']);
end

% Generate model
[Node, Parameters] = ModelGeneration(Options.St7.uID, Options, Parameters);

% Set Fileopn status
Options.FileOpen.Node = 1;
Options.FileOpen.St7Model = 1;

waitbar(0.6,h);

% Save file in memory - TEMP FILE
iErr = calllib('St7API', 'St7SaveFile', Options.St7.uID);
HandleError(iErr);

% Save actual file by overwriting
St7SaveFileAs(Options.St7.uID, Options.PathName, Options.FileName);

waitbar(0.8,h);

setappdata(0,'Parameters',Parameters);
setappdata(0,'Node',Node);
setappdata(0,'Options',Options);

% Save meta data
pushbtnSaveMetaData_Callback(handles.pushbtnSaveMetaData, eventdata, handles)

close(h);

% Edit Model -------

function pushbtnBoundaryConditions_Callback(hObject, eventdata, handles)
UserInputBearings_Variable_gui();

function pushbtnParameters_Callback(hObject, eventdata, handles)
EditParameters_gui();

% StID -------------

function pushbtnTestModelComparison_Callback(hObject, eventdata, handles)
ModelExperimentComparison_gui();

function pushbtnParameterCorrelation_Callback(hObject, eventdata, handles)
ParameterCorrelation_gui();

function pushbtnRateModel_Callback(hObject, eventdata, handles)
LoadRating_gui();

% St7 API Functions  --
function pushbtnFEModelWindow_Callback(hObject, eventdata, handles)
FEModelWindow_gui();

function pushbtnInitSt7_Callback(hObject, eventdata, handles)
InitializeSt7();

function pushbtnCloseAndUnload_Callback(hObject, eventdata, handles)
CloseAndUnload(1);
