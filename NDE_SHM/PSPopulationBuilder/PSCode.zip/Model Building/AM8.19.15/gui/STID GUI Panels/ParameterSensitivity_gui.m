function varargout = ParameterSensitivity_gui(varargin)
% PARAMETERSENSITIVITY_GUI MATLAB code for ParameterSensitivity_gui.fig
%      PARAMETERSENSITIVITY_GUI, by itself, creates a new PARAMETERSENSITIVITY_GUI or raises the existing
%      singleton*.
%
%      H = PARAMETERSENSITIVITY_GUI returns the handle to a new PARAMETERSENSITIVITY_GUI or the handle to
%      the existing singleton*.
%
%      PARAMETERSENSITIVITY_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PARAMETERSENSITIVITY_GUI.M with the given input arguments.
%
%      PARAMETERSENSITIVITY_GUI('Property','Value',...) creates a new PARAMETERSENSITIVITY_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ParameterSensitivity_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ParameterSensitivity_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ParameterSensitivity_gui

% Last Modified by GUIDE v2.5 15-Jul-2015 15:58:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ParameterSensitivity_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @ParameterSensitivity_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ParameterSensitivity_gui is made visible.
function ParameterSensitivity_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ParameterSensitivity_gui (see VARARGIN)

% Choose default command line output for ParameterSensitivity_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

formatColorScheme(hObject);

% Creation Functions ------------------------------------------------------
% get app data
Options = getappdata(0, 'Options');
paraData = get(Options.handles.EditParameters_gui.tableParameterValues, 'Data');

% popup box
paraNames.name = paraData(cell2mat(paraData(:,7)),1); 
set(handles.popupParameter, 'String', paraNames.name);
paraNames.group = cell2mat(paraData(cell2mat(paraData(:,7)),4));

% number of updating parameters
numGroup = length(unique(cell2mat(paraData(:,4))));

% insert group number of zero into paraData AFTER unique search
paraData(cellfun(@isempty,paraData(:,4)),4) = num2cell(0);

% modeNum list - List modeNums 1-20
Data = cell(20,2);
Data(:,1) = num2cell(1:20)';
Data(:,2) = {false};
set(handles.uitableRunModes, 'Data', Data);

% Preallocate structure for parameter information to be saved in
paraList = struct('Alphas', cell(numGroup,1), 'freq', cell(numGroup,1), ...
                  'MAC', cell(numGroup,1), 'COMAC', cell(numGroup,1), ...
                  'Sv2', cell(numGroup,1), 'St1', cell(numGroup,1), ...
                  'dataInd', cell(numGroup,1));

for i = 1:length(paraList)
    paraList(i).dataInd = find(cell2mat(paraData(:,4)) == i);
end

setappdata(handles.guiParameterSensitivity,'paraList',paraList);
setappdata(handles.guiParameterSensitivity,'paraData',paraData);
setappdata(handles.guiParameterSensitivity, 'paraNames', paraNames);

function varargout = ParameterSensitivity_gui_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

% Push Buttons -------------------------------------------------------------
function pushbtnRunSensitivityStudy_Callback(hObject, eventdata, handles)
Type = 'Dynamic';

SensitivityStudy(Type, handles) 

function pushbtnRunRatingStudy_Callback(hObject, eventdata, handles)
Parameters = getappdata(0,'Para_temp');

% Get Rating Code
ASDcheck = get(handles.radiobtnCode_ASD, 'value');

if ASDcheck
    Parameters.Rating.Code = 'ASD';
else
    Parameters.Rating.Code = 'LRFD';
end

% Get Rating Truck
Trucks = get(handles.popupRatingTruck,'string');
selectInd = get(handles.popupRatingTruck,'value');

Parameters.Rating.DesignTruckName = Trucks(selectInd);
if ASDcheck
    Parameters.Rating.DesignLoad = num2str(selectInd);
else
    Parameters.Rating.DesignLoad = 'A';
end

Parameters.Rating = GetTruckLoads(Parameters.Rating);

%% Get Lane width
if ~isfield(Parameters,'NumLane')
    Parameters.NumLane = floor(Parameters.RoadWidth/144);
end

%% Write to root
setappdata(0,'Para_temp',Parameters);

%% Run Load Rating Functions in loop
Type = 'Rating';
SensitivityStudy(Type, handles); 

function pushbtnApplyBounds_Callback(hObject, eventdata, handles)
paraList = getappdata(handles.guiParameterSensitivity, 'paraList');
paraNames = getappdata(handles.guiParameterSensitivity, 'paraNames');

% get current parameter
value = get(handles.popupParameter, 'Value');
group = paraNames.group(value);

% apply bounds from paralist to edit fields and data structure
% get min and max fields
lbAlpha = str2double(get(handles.editLowerBound, 'String'));
ubAlpha = str2double(get(handles.editUpperBound, 'String'));
avg = str2double(get(handles.editMean, 'String'));
% Apply to edit fields
set(handles.editMin, 'String', num2str(lbAlpha));
set(handles.editMax, 'String', num2str(ubAlpha));
% Applot to paraList data structure
paraList(group).Alphas.lb = lbAlpha;
paraList(group).Alphas.ub = ubAlpha;
paraList(group).Alphas.avg = avg;

% set app data
setappdata(handles.guiParameterSensitivity,'paraList',paraList);

function pushbtnAcceptBounds_Callback(hObject, eventdata, handles)
% accept bounds as alpha values for correlation and make mean value alpha=1
% apply bounds from paralist to parameters spring values and alpha values
paraList = getappdata(handles.guiParameterSensitivity, 'paraList');
paraData = getappdata(handles.guiParameterSensitivity, 'paraData');
Parameters = getappdata(0,'Para_temp');

for i = 1:length(paraList)
    paraNums = paraList(i).dataInd;
    for k = 1:length(paraNums)
        j = paraNums(k);
        if ~isempty(paraList(i).Alphas)
            switch paraData{j,11}
                case 'lin'
                    paraData{j,5} = paraData{j,5}*paraList(i).Alphas.avg;
                    paraData{j,9} = paraList(i).Alphas.lb/paraList(i).Alphas.avg;
                    paraData{j,10} = paraList(i).Alphas.ub/paraList(i).Alphas.avg;

                case 'log'
                    paraData{j,5} = paraData{j,5}*10^paraList(i).Alphas.avg;
                    paraData{j,9} = paraList(i).Alphas.lb - paraList(i).Alphas.avg;
                    paraData{j,10} = paraList(i).Alphas.ub - paraList(i).Alphas.avg;
            end
        end
    end
end

Parameters = ConvertParameterTable(paraData, Parameters);

State = 'Init';
UpdateParameterTable(Parameters, [], [], State,[]);

setappdata(0,'Para_temp',Parameters);

function guiParameterSensitivity_CloseRequestFcn(hObject, eventdata, handles)

delete(hObject);

% Popup boxes -------------------------------------------------------------
function popupParameter_Callback(hObject, eventdata, handles)
paraList = getappdata(handles.guiParameterSensitivity,'paraList');
paraData = getappdata(handles.guiParameterSensitivity, 'paraData');
paraNames = getappdata(handles.guiParameterSensitivity, 'paraNames');

% Get DOF values and put in edit boxes
value = get(handles.popupParameter, 'Value');
group = paraNames.group(value);

if isempty(paraList(group).MAC) && isempty(paraList(group).St1)
    % get default alpha values  
    lbAlpha = paraData(paraList(group).dataInd(1),9);
    ubAlpha = paraData(paraList(group).dataInd(1),10);
    
    % change alpha edit fields
    set(handles.editMin, 'String', lbAlpha);
    set(handles.editMax, 'String', ubAlpha);
    
    cla(handles.axesGraph); 
    cla(handles.axesRatingFactorSt); 
    cla(handles.axesRatingFactorSv); 
    
    set(handles.editLowerBound, 'String', []);
    set(handles.editMean, 'String', []);
    set(handles.editUpperBound, 'String', []);
else
    % Get previous info
    ubAlpha = paraList(group).Alphas.ub;
    lbAlpha = paraList(group).Alphas.lb;
    avgAlpha = paraList(group).Alphas.avg;
    
    % change alpha edit fields
    set(handles.editMin, 'String', num2str(lbAlpha));
    set(handles.editMax, 'String', num2str(ubAlpha));
    
    % Set text fields
    set(handles.editLowerBound, 'String', num2str(lbAlpha));
    set(handles.editMean, 'String', num2str(avgAlpha));
    set(handles.editUpperBound, 'String', num2str(ubAlpha));
end

% change output fields, etc.
if ~isempty(paraList(group).MAC)
    COMAC = paraList(group).COMAC;
    MAC = paraList(group).MAC;
    freq = paraList(group).freq;
   
    stepAlpha = paraList(group).Alphas.stepAlphaDyn;
    
    hold off
    % plot freq for each modeNum
    semilogy(handles.axesGraph, stepAlpha, freq);
    xlim(handles.axesGraph, [lbAlpha ubAlpha]);
    ylim(handles.axesGraph, [.9*min(min(freq)) 1.1*max(max(freq))]);
    
    % plot MAC for first modeNum
    axes(handles.axesMACGrid);
    imagesc(MAC{group});colorbar;
    
    % plot COMAC plot for first modeNum
    hist(handles.axesCOMAC, COMAC);
end

if ~isempty(paraList(group).St1)
    St1 = paraList(group).St1;
    Sv2 = paraList(group).Sv2;
    
    stepAlpha = paraList(group).Alphas.stepAlphaStat;
    
    hold off
    % plot freq for each modeNum
    semilogy(handles.axesRatingFactorSt, stepAlpha, St1);
    xlim(handles.axesRatingFactorSt, [lbAlpha ubAlpha]);
    ylim(handles.axesRatingFactorSt, [.9*min(min(min(St1))) 1.1*max(max(max(St1)))]);
    
     % plot freq for each modeNum
    semilogy(handles.axesRatingFactorSv, stepAlpha, Sv2);
    xlim(handles.axesRatingFactorSv, [lbAlpha ubAlpha]);
    ylim(handles.axesRatingFactorSv, [.9*min(min(min(Sv2))) 1.1*max(max(max(Sv2)))]);
end

% Edit boxes -------------------------------------------------------------
function editMin_Callback(hObject, eventdata, handles)

function editMax_Callback(hObject, eventdata, handles)

function editNumPoints_Callback(hObject, eventdata, handles)

% Check boxes -------------------------------------------------------------
function uitableRunModes_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to uitableRunModes (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)

% Switch graphs if modeNum number is selected in uitable
if eventdata.Indices(2) == 1;
    paraList = getappdata(handles.guiParameterSensitivity, 'paraList');
    paraNames = getappdata(handles.guiParameterSensitivity, 'paraNames');

    % Get DOF values and put in edit boxes
    value = get(handles.popupParameter, 'Value');
    group = paraNames.group(value);
    modeNum = eventdata.Indices(1);
    
    axes(handles.axesMACGrid);
    try
        if ~isempty(paraList(group).MAC{modeNum}); % check to see if graphs have been created before 
            imagesc(paraList(group).MAC{modeNum}); colorbar % graph MAC plot
        end
    catch
        image([]); % if not, just clear plots
    end
    
    setappdata(handles.guiParameterSensitivity, 'modeNum', modeNum);
end

% Axes --------------------------------------------------------------------
function axesGraph_ButtonDownFcn(hObject, eventdata, handles)
GraphButtonDown(hObject, handles)

function axesRatingFactorSv_ButtonDownFcn(hObject, eventdata, handles)
GraphButtonDown(hObject, handles)

function axesRatingFactorSt_ButtonDownFcn(hObject, eventdata, handles)
GraphButtonDown(hObject, handles)

function GraphButtonDown(hObject, handles)
% get current mouse position
pos = get(hObject, 'CurrentPoint');
xpos = pos(1,1);

% get min and max fields
lbAlpha = str2double(get(handles.editLowerBound, 'String'));
ubAlpha = str2double(get(handles.editUpperBound, 'String'));

% Find closest bound to click and replace bounds fields
if abs(xpos-ubAlpha) < abs(xpos-lbAlpha)
    set(handles.editUpperBound, 'String', num2str(xpos));
else
    set(handles.editLowerBound, 'String', num2str(xpos));
end

% Replace Mean values between new bounds
set(handles.editMean, 'String', num2str(mean([ubAlpha, lbAlpha])));

% Rating Factor Otions ----------------------------------------------------
function popupRatingTruck_Callback(hObject, eventdata, handles)

function radiobtnCode_ASD_Callback(hObject, eventdata, handles)
if get(hObject, 'Value') % true
    set(handles.radiobtnCode_LRFD, 'Value', 0); % set opposite to false
    set(hObject, 'Value', 1); % set current to false
    LRFD = 0;
else    % false
    set(handles.radiobtnCode_LRFD, 'Value', 1); % set opposite to true
    set(hObject, 'Value', 0); % set current to false
    LRFD = 1;
end

SetDesignTruckList(LRFD, handles)
  
function radiobtnCode_LRFD_Callback(hObject, eventdata, handles)
if get(hObject, 'Value') % true
    set(handles.radiobtnCode_ASD, 'Value', 0); % set opposite to false
    set(hObject, 'Value', 1); % set current to true
    LRFD = 1;
else    % false
    set(handles.radiobtnCode_ASD, 'Value', 1); % set opposite to true
    set(hObject, 'Value', 0); % set current to false
    LRFD = 0;
end

SetDesignTruckList(LRFD, handles)

function SetDesignTruckList(LRFD, handles)
% Design Trucks
tempcd = pwd;
cd('../');
load([pwd '\Tables\GUI\GuiInit.mat'], 'DesignTruckList');
cd(tempcd);

if LRFD
    set(handles.popupRatingTruck,'String', {'HL-93'});
    set(handles.popupRatingTruck, 'Value', 1);
else
    set(handles.popupRatingTruck, 'String', DesignTruckList, 'Value', 6);
end

%% Sensitivity Study ------------------------------------------------------
function SensitivityStudy(Type, handles) 
h = waitbar(0.1, 'Running Sensitivity Study');
% Sensitivity ------------------------------------------------------------
Options = getappdata(0,'Options');
Node = getappdata(0,'Node');
Parameters = getappdata(0, 'Para_temp');

paraList = getappdata(handles.guiParameterSensitivity, 'paraList');
paraData = getappdata(handles.guiParameterSensitivity, 'paraData');
paraNames = getappdata(handles.guiParameterSensitivity, 'paraNames');

% get user values
value = get(handles.popupParameter, 'Value');
nIter = str2double(get(handles.editNumPoints, 'String'));
group = paraNames.group(value);

% get user alpha bounds and apply to text fields and local variable
% variable
lbAlpha = str2double(get(handles.editMin, 'String'));
ubAlpha = str2double(get(handles.editMax, 'String'));
% bounds text fields
set(handles.editLowerBound, 'String', num2str(lbAlpha));
set(handles.editUpperBound, 'String', num2str(ubAlpha));
set(handles.editMean, 'String', num2str(mean([ubAlpha, lbAlpha])));
% Place in paralist
paraList(group).Alphas.lb = lbAlpha;
paraList(group).Alphas.ub = ubAlpha;
paraList(group).Alphas.avg = mean([lbAlpha ubAlpha]);

% get modeNums to solve for
Data = get(handles.uitableRunModes, 'Data');
modeNums = find(cell2mat(Data(:,2)));

% get point discretization
stepAlpha = lbAlpha:(ubAlpha-lbAlpha)/(nIter-1):ubAlpha;

% check for num modeNums
Options.Analysis.NumModes = max(modeNums);

% decimate nodeList list of deck nodes until list is less than 100
nodeList = [];
for i = 1:length(Node)
    nodeList = vertcat(nodeList, nonzeros(Node(i).ID(:,:,1)));
end
while length(nodeList) > 100
    nodeList = nodeList(1:5:end);
end

% Set Solver Options
switch Type
    case 'Rating'
        paraList(group).Alphas.stepAlphaStat = stepAlpha;    
        
        St7SetLSASolverOptions(Options.St7.uID, Parameters, Options);
    case 'Dynamic'
        paraList(group).Alphas.stepAlphaDyn = stepAlpha;    
        
        Options.Analysis.NumModes = max(modeNums);
end
    
% Convert paraData to Parameters
Parameters = ConvertParameterTable(paraData, Parameters);

% Update Model With Current Parameters and Alphas
Parameters = SetModelParameters(Options.St7.uID, Parameters, Node);

switch Type
    case 'Dynamic'
        % initial run - baseline
        PathName = Options.St7.ScratchPath;
        FileName = Options.TempFileName;
        St7RunNaturalFrequencySolver(Options.St7.uID, PathName, FileName, Options);
        [St7Mode, St7Disp] = St7GetNaturalFrequencyResults(Options.St7.uID, PathName, FileName, nodeList);
        
        apFreq = St7Mode(:,1);
        apShape(:,:) = St7Disp;
end

% Set all Parameters Update Status Except Para Group of Interest to FALSE
paraData_temp = paraData;
paraData(paraList(group).dataInd, 7) = {true};
paraData(~paraList(group).dataInd, 7) = {false};

% iterate
for i = 1:nIter
    waitbar(i/nIter, h);
    
    % get alpha to be changed for group
    paraData(paraList(group).dataInd,8) = {stepAlpha(i)};
    
    % Convert paraData to Parameters
    Parameters = ConvertParameterTable(paraData, Parameters);
    
    % apply new parameter step to model
    UpdateModelParameters(Options.St7.uID, Parameters, Node);

     switch Type
        case 'Dynamic'
            % Solve for 50% more modes to pair enough iteration modes to the a priori modes 
            Options.Analysis.NumModes = round(max(modeNums)*2.5);
            
            % run solver and get results
            PathName = Options.St7.ScratchPath;
            FileName = Options.TempFileName;
            St7RunNaturalFrequencySolver(Options.St7.uID, PathName, FileName, Options);
            [St7Mode, St7Disp] = St7GetNaturalFrequencyResults(Options.St7.uID, PathName, FileName, nodeList);
            
            % get frequencies of interest
            tmpfreq(:,i) = St7Mode(:,1);
            tmpshape(:,i,:) = St7Disp;
        case 'Rating'
            [St1(:,i), Sv2(:,i)] = FERatingFactors(handles, Parameters, Options, Node);
    end
end

switch Type
    case 'Dynamic'
        % Get MAC pairing with a priori model
        % Use columnwise pairing to match a priori to best available
        % mode from the parametric iteration
        for i = 1:nIter
            % get MAC value
            tmpMAC = GetMACValue(permute(tmpshape(:,i,:),[1,3,2]), apShape);
            
            MACsearchindex = 1:Options.Analysis.NumModes;
            for j = 1:length(modeNums)
                % find Max
                [~,ind] = max(tmpMAC(MACsearchindex,j));
                I(i,j) = MACsearchindex(ind);

                % Subtract out mode from MAC search index so it cannot be
                % paired with any other experimental mode
                MACsearchindex(ind)=[];
            end
        end
        
        for i = 1:nIter
            freq(:,i) = tmpfreq(I(i,:),i);
            shape(:,i,:) = tmpshape(:,i,I(i,:));
        end
        
        for i = 1:length(modeNums)
            MAC{i} = GetMACValue(shape(:,:,i), []);
           
        end
        
        for i = 1:length(shape)
            tmpCOMAC{i} = GetCOMACValue(permute(shape(i,:,:),[3,2,1]), []);
        end
        
        COMAC = cell2mat(tmpCOMAC)';
        
        % --- PLots --------
        hold off
        % plot freq for each modeNum
        set(handles.axesGraph,'NextPlot','ReplaceChildren',...
            'ButtonDownFcn',{@axesGraph_ButtonDownFcn,handles},...
            'HitTest','on');
        semilogy(handles.axesGraph, stepAlpha, freq);
        set(get(handles.axesGraph,'Children'),'HitTest','off');
        xlim(handles.axesGraph, [lbAlpha ubAlpha]);
        ylim(handles.axesGraph, [.9*min(min(freq)) 1.1*max(max(freq))]);
        
        % plot MAC for first modeNum
        axes(handles.axesMACGrid);
        imagesc(MAC{1}); colorbar
        
        % plot COMAC plot for first modeNum
        hist(handles.axesCOMAC, COMAC);
        
        % Save paraList info
        % Freq plot
        paraList(group).freq = freq;
        % MAC plots
        paraList(group).MAC = MAC;
        % CoMAC plot
        paraList(group).COMAC = COMAC;
    case 'Rating'
        % --- PLots --------
        hold off
        % plot freq for each modeNum
        set(handles.axesRatingFactorSt,'NextPlot','ReplaceChildren',...
            'ButtonDownFcn',{@axesRatingFactorSt_ButtonDownFcn,handles},...
            'HitTest','on');
        semilogy(handles.axesRatingFactorSt, stepAlpha, St1);
        set(get(handles.axesGraph,'Children'),'HitTest','off');
        xlim(handles.axesRatingFactorSt, [lbAlpha ubAlpha]);
        ylim(handles.axesRatingFactorSt, [.9*min(min(St1)) 1.1*max(max(St1))]);   
        
        hold off
        % plot freq for each modeNum
        set(handles.axesRatingFactorSv,'NextPlot','ReplaceChildren',...
            'ButtonDownFcn',{@axesRatingFactorSv_ButtonDownFcn,handles},...
            'HitTest','on');
        semilogy(handles.axesRatingFactorSv, stepAlpha, Sv2);
        set(get(handles.axesGraph,'Children'),'HitTest','off');
        xlim(handles.axesRatingFactorSv, [lbAlpha ubAlpha]);
        ylim(handles.axesRatingFactorSv, [.9*min(min(Sv2)) 1.1*max(max(Sv2))]);  
        
        % Save paraList info
        paraList(group).St1 = St1;
        paraList(group).Sv2 = Sv2; 
end

% Reset parameters in model
% Convert paraData to Parameters
paraData = paraData_temp;
Parameters = ConvertParameterTable(paraData, Parameters);

% apply new parameter step to model
UpdateModelParameters(Options.St7.uID, Parameters, Node);

% Close wait bar
close(h);

% Set app data
setappdata(handles.guiParameterSensitivity, 'paraList', paraList);

function [St1, Sv2] = FERatingFactors(handles, Parameters, Options, Node)
% Get data from root
Parameters = getappdata(0,'Para_temp');
Options = getappdata(0, 'Options');
Node = getappdata(0, 'Node');

% Notification Panel
msg = 'Starting Load Rating...';
type = 'new';
hObj = Options.handles.RAMPS_gui.listboxNotificationPanel;
UpdateNotificationPanel(hObj, msg, type);

% Get Current GUI Options
uID = Options.St7.uID;

% Get Rating Code
if get(handles.radiobtnCode_LRFD, 'value')
    Code = 'LRFD';
elseif get(handles.radiobtnCode_ASD,'value')
    Code = 'ASD';
end
Parameters.Rating.Code = Code;

% Get Rating Truck
Trucks = get(handles.popupRatingTruck, 'string');
selectInd = get(handles.popupRatingTruck, 'value');

% Stiffeners
if get(handles.checkboxTransStiff, 'value')
    Parameters.Beam.Stiffeners.Spacing = str2double(get(handles.editTransStiff, 'string'));
end
if get(handles.checkboxLongStiff, 'value')
    % INSERT LONG STIFF CODE
end

% Crawl steps
Options.LoadPath.CrawlSteps = str2double(get(handles.editCrawlSteps, 'String'));

% lane divs
Options.LoadPath.Divisions = str2double(get(handles.editLaneDivs, 'String'));

% CB
% With moment gradient modifier str2double(get(handles.editCB, 'String'));
Parameters.Rating.(Code).useCB = get(handles.editCB, 'value'); 
Parameters.Rating.(Code).CB = str2double(get(handles.editCB, 'String'));

% % Shear Rating
% Options.LoadRating.ShearRating = get(handles.checkboxShearRating, 'Value');

% Clear Past Tables 
State = 'Init';
UpdateRatingTables(Parameters, Options, State);

% Truck Load Assignment
Parameters.Rating.DesignTruckName = Trucks(selectInd);
if strcmp(Parameters.Rating.Code, 'ASD')
    Parameters.Rating.(Code).DesignLoad = '6';
else
    Parameters.Rating.(Code).DesignLoad = 'A';
end

%% Apply Boundary Conditions to model
BCpress = getappdata(0,'BCpress');
if ~isempty(BCpress)
    % Notification Panel
    msg = 'Applying Boundary Conditions...';
    UpdateNotificationPanel(Options.handles.RAMPS_gui.listboxNotificationPanel, msg, 'new');
   
    FreedomCase = 1;
    BoundaryConditions(uID,Node,Parameters,FreedomCase);
end

%% Run Load Rating Functions
% Call Main Funciton
guiState = 1;
Parameters = FEALoadRating_Main(uID, Parameters, Options, Node, [], [], guiState);

St1 = [Parameters.Rating.(Code).FEM.Int.St1.RFInv, Parameters.Rating.(Code).FEM.Ext.St1.RFInv];
Sv2 = [Parameters.Rating.(Code).FEM.Int.Sv2.RFInv, Parameters.Rating.(Code).FEM.Ext.Sv2.RFInv];
