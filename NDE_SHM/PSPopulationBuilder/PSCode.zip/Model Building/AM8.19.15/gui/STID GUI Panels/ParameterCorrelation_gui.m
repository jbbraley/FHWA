function varargout = ParameterCorrelation_gui(varargin)
% PARAMETERCORRELATION_GUI MATLAB code for ParameterCorrelation_gui.fig
%      PARAMETERCORRELATION_GUI, by itself, creates a new PARAMETERCORRELATION_GUI or raises the existing
%      singleton*.
%
%      H = PARAMETERCORRELATION_GUI returns the handle to a new PARAMETERCORRELATION_GUI or the handle to
%      the existing singleton*.
%
%      PARAMETERCORRELATION_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PARAMETERCORRELATION_GUI.M with the given input arguments.
%
%      PARAMETERCORRELATION_GUI('Property','Value',...) creates a new PARAMETERCORRELATION_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ParameterCorrelation_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ParameterCorrelation_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ParameterCorrelation_gui

% Last Modified by GUIDE v2.5 11-Aug-2015 16:35:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ParameterCorrelation_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @ParameterCorrelation_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ParameterCorrelation_gui is made visible.
function ParameterCorrelation_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ParameterCorrelation_gui (see VARARGIN)

% Choose default command line output for ParameterCorrelation_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

formatColorScheme(hObject);

% Get App Data
Parameters = getappdata(0, 'Parameters');
Options = getappdata(0, 'Options');
meshData = getappdata(0, 'meshData');
% Add Handles
Options.handles.ParameterCorrelation_gui = handles;
set(hObject, 'visible', 'off');

% Get Options
editNumModes = Options.Analysis.NumModes;
popupFreqWeight = Options.Correlation.stringFreqWeightOpts;
editFreqWeightDelta = Options.Correlation.deltaFreqWeight;
editTolX = Options.Correlation.TolX;
editTolFun = Options.Correlation.TolFun;
editDiffMinChange = Options.Correlation.DiffMinChange;

% Set options to GUI
set(handles.editNumAnaModes, 'String', num2str(editNumModes));
set(handles.popupFreqWeight, 'String', popupFreqWeight);
set(handles.editFreqWeightDelta, 'String', num2str(editFreqWeightDelta));
set(handles.editTolX, 'String', num2str(editTolX));
set(handles.editTolFun, 'String', num2str(editTolFun));
set(handles.editDiffMinChange, 'String', num2str(editDiffMinChange));

% update table
State = 'Init';
UpdateMassTable(Parameters, Options, meshData, State);
UpdateAlphaTable(Parameters, Options, State);

% Set App Data
setappdata(0, 'Options', Options);

% --- Outputs from this function are returned to the command line.
function varargout = ParameterCorrelation_gui_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

% --- Executes when user attempts to close ParameterCorrelation_gui.
function ParameterCorrelation_gui_CloseRequestFcn(hObject, eventdata, handles)
% Remove handles from Options
Options = getappdata(0,'Options');
Options.handles = rmfield(Options.handles, 'ParameterCorrelation_gui');
setappdata(0,'Options',Options);

delete(hObject);

% Run ---------------------------------------------------------------------
function pushbtnRunPara_Callback(hObject, eventdata, handles)
% Get temp parameters from app data
Parameters = getappdata(0, 'Parameters');
Node = getappdata(0,'Node');
% Check to see if EditParameters_gui is open
Options = getappdata(0, 'Options'); 
if ~isfield(Options.handles, 'EditParameters_gui')
    EditParameters_gui();
    Options = getappdata(0, 'Options'); 
end

% Get Para table Fields
paraData = get(Options.handles.EditParameters_gui.tableParameterValues, 'Data');
Parameters = ConvertParameterTable(paraData, Parameters);

% Update Options From GUI
GetOptions(handles);

% Set up Pre-calibration Parameters in memory
P_temp = Parameters;

% Set App Data
setappdata(0, 'Para_temp', Parameters);

% Run Calibration
Parameters = ModelCorrelation(Parameters, [], paraData, [], []);

setappdata(0,'Para_temp',Parameters);

function pushbtnAssign_Callback(hObject, eventdata, handles)
% check to see if overwrite is desired
button = questdlg('Overwrite Parameters in Memory?','Overwrite?','Yes','No','Reset','Yes');

switch button
    case 'Reset'
        Parameters = getappdata(0, 'Parameters');
        setappdata(0, 'Para_temp', Parameters);
        % Update GUI with final values
        UpdateParameterTable(Parameters, [], [], 'Init', []);
    case 'Yes'
        Parameters = getappdata(0, 'Para_temp');
        % Update GUI with final values
        UpdateParameterTable(Parameters, [], [], 'Replace', [])
    case 'No'
        Parameters = getappdata(0, 'Para_temp');
end

Node = getappdata(0, 'Node');
Options = getappdata(0, 'Options');

% Update Model in memory
Parameters = SetModelParameters(Options.St7.uID, Parameters, Node);
% Update rest of GUI
UpdateMassTable(Parameters, Options, [], 'Init');
UpdateNatFreqTables();
PlotModeShapes('Ana');

% Apply Parameters to memory
setappdata(0, 'Parameters', Parameters);

function pushbtnRunMass_Callback(hObject, eventdata, handles)
GetOptions(handles);
State = 'Update';
UpdateMassTable([], [], meshData, State);

% Mass Div ----------------------------------------------------------------
function editYDiv_Callback(hObject, eventdata, handles)
State = 'Replace';
UpdateMassTable([], [], [], State); 

function editXDiv_Callback(hObject, eventdata, handles)
State = 'Replace';
UpdateMassTable([], [], [], State); 
 
function checkboxConstantTotalMass_Callback(hObject, eventdata, handles)
State = 'Replace';
UpdateMassTable([], [], [], State); 

% Options ----------------------------------------------------------------- 
function editNumAnaModes_Callback(hObject, eventdata, handles)

function popupFreqWeight_Callback(hObject, eventdata, handles)

function editFreqWeightDelta_Callback(hObject, eventdata, handles)

function editTolFun_Callback(hObject, eventdata, handles)

function editTolX_Callback(hObject, eventdata, handles)

function checkboxRepair_Callback(hObject, eventdata, handles)
% Sliders -----------------------------------------------------------------
function sliderPara1_Callback(hObject, eventdata, handles)
state = 'iter';
OptPlot([], [], state);
function sliderPara2_Callback(hObject, eventdata, handles)
state = 'iter';
OptPlot([], [], state);
function sliderPara3_Callback(hObject, eventdata, handles)
state = 'iter';
OptPlot([], [], state);

% Util Fun ----------------------------------------------------------------
function GetOptions(handles)
Options = getappdata(0, 'Options');

% get options from GUIOptions.Analysis.NumModes = str2double(get(handles.editNumAnaModes, 'String'));
string = get(handles.popupFreqWeight, 'String');
value = get(handles.popupFreqWeight, 'Value');
Options.Correlation.stringFreqWeight = string{value};
Options.Correlation.deltaFreqWeight = str2double(get(handles.editFreqWeightDelta, 'String'));
Options.Correlation.TolX = str2double(get(handles.editTolX, 'String'));
Options.Correlation.TolFun = str2double(get(handles.editTolFun, 'String'));
Options.Correlation.DiffMinChange = str2double(get(handles.editDiffMinChange, 'String')); 
Options.Correlation.RePairModes = get(handles.checkboxRepair, 'Value');

setappdata(0, 'Options', Options);
