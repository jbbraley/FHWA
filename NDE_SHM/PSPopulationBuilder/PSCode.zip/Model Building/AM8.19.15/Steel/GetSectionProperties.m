%% GetSectionProperties: Calculates composite & non-composite, short-term & long-term section properties listed below:
    % 1. (y) Moment Arm [in]
    % 2. (I) Moment of Inertia [in^4]
    % 3. (S) Section Modulus [in^3]
    % 4. (A) Cross-section Area [in^2]
    % 4. (be) Effective Width of Deck [in]
    % 5. (A) Effective Area [in^2]
    % 6. (d) Beam depth [in]
    
function Arg = GetSectionProperties(Arg, Parameters, Section)
% Parameters.Beam.Int = GetSectionProperties(Parameters.Beam.Int,Parameters,'Int')
% Parameters.Beam.Ext = GetSectionProperties(Parameters.Beam.Ext,Parameters,'Ext')

%%%%%%%%%%%%%%%%%% NON-COMPOSITE SECTION PROPERTIES %%%%%%%%%%%%%%%%%%%%

% Depth of Web
Arg.ind = Arg.d-2*Arg.tf;

% Depth of web in compression in elastic range for non-composite section
Arg.DcNc = Arg.d/2-Arg.tf; %in 

% Moment Arm
Arg.yTnc = Arg.d/2;
Arg.yBnc = Arg.d/2;

% Moments of Intertia
Arg.Ix = 2*(Arg.bf*Arg.tf^3/12+Arg.bf*Arg.tf*(Arg.tf/2+Arg.ind/2)^2)+Arg.tw*Arg.ind^3/12;
Arg.Iyc = Arg.tf*Arg.bf^3/12; %Moment of Inertia of the compression flange
Arg.Iyt = Arg.Iyc; %Moment of Inertia of the Tension Flange (same as compression flange b/c symetrical cross section)
Arg.Iy = 2*Arg.tf*Arg.bf^3/12+(Arg.ind)*Arg.tw^3/12; %Moment of inertia of the entire steel section

% Section Modulus
Arg.STnc = Arg.Ix/Arg.yTnc;
Arg.SBnc = Arg.Ix/Arg.yBnc;
Arg.S2 = Arg.Iy/(Arg.bf/2);

% Section Area
Arg.A = 2*Arg.bf*Arg.tf + Arg.tw*Arg.ind;
    
% For multiple span continuous models    
if Parameters.Spans > 1
    if Arg.CoverPlate.Length > 0 % For models with a coverplate
        % Total Beam Depth
        Arg.CoverPlate.d = Arg.d + 2*Arg.CoverPlate.t;

        % Depth of Web
        Arg.CoverPlate.ind = Arg.CoverPlate.d-2*Arg.CoverPlate.tf;

        % Depth of web in compression in elastic range for non-composite section
        Arg.CoverPlate.DcNc = Arg.CoverPlate.d/2-Arg.CoverPlate.tf; %in 

        % Moment Arm
        Arg.CoverPlate.yTnc = Arg.CoverPlate.d/2;
        Arg.CoverPlate.yBnc = Arg.CoverPlate.d/2;

        % Moment of Interia
        Arg.CoverPlate.Ix = 2*(Arg.CoverPlate.bf*Arg.CoverPlate.tf^3/12+Arg.CoverPlate.bf*Arg.CoverPlate.tf*(Arg.CoverPlate.tf/2+...
            Arg.CoverPlate.ind/2)^2)+Arg.CoverPlate.tw*Arg.CoverPlate.ind^3/12;
        Arg.CoverPlate.Iyc = Arg.CoverPlate.tf*Arg.CoverPlate.bf^3/12; %Moment of Inertia of the compression flange
        Arg.CoverPlate.Iyt = Arg.CoverPlate.Iyc; %Moment of Inertia of the Tension Flange (same as compression flange b/c symetrical cross section)
        Arg.CoverPlate.Iy = 2*Arg.CoverPlate.tf*Arg.CoverPlate.bf^3/12+(Arg.CoverPlate.d...
            -2*Arg.CoverPlate.tf)*Arg.CoverPlate.tw^3/12; %Moment of inertia of the entire steel section

        % Section Modulus
        Arg.CoverPlate.STnc = Arg.CoverPlate.Ix/Arg.CoverPlate.yTnc;
        Arg.CoverPlate.SBnc = Arg.CoverPlate.Ix/Arg.CoverPlate.yBnc;
        Arg.CoverPlate.S2 = Arg.CoverPlate.Iy/(Arg.CoverPlate.bf/2);

        % Section Area
        Arg.CoverPlate.A = 2*Arg.CoverPlate.bf*Arg.CoverPlate.tf...
            +Arg.CoverPlate.tw*Arg.CoverPlate.ind;
    end
end

%%%%%%%%%%%%%%%%%%%% COMPOSITE SECTION PROPERTIES %%%%%%%%%%%%%%%%%%%%%%

if Parameters.Deck.CompositeDesign == 1
    
    % Total Depth of Composite Section
    Arg.Dt = Arg.d+Parameters.Deck.t+Parameters.Deck.Offset;

    switch Section
        case 'Int'
            Ast = Parameters.Deck.A.AInt_st;
            Alt = Parameters.Deck.A.AInt_lt;
        case 'Ext'
            Ast = Parameters.Deck.A.AExt_st;
            Alt = Parameters.Deck.A.AExt_lt;
        case 'Rolled'
            Ast = Parameters.Deck.A.AInt_st;
            Alt = Parameters.Deck.A.AInt_lt;
        case 'Manual Assign'
            Ast = Parameters.Deck.A.AInt_st;
            Alt = Parameters.Deck.A.AInt_lt;           
    end

    % Determine distances from centroid of composite short/long-term section to top, bottom
    % and deck(bottom of girder is reference axis). 

    % Short-term 
        yBst = (Ast*(Parameters.Deck.t/2 + Parameters.Deck.Offset + Arg.d) + Arg.A*Arg.yBnc)/(Ast+Arg.A); % formula to find centroid: y = sum(Ai*yi)/sum(Ai)
        if yBst > Arg.d % Elastic Neutral Axis is in the deck
            Arg.yBst = yBst; 
            Arg.yTst = yBst - Arg.d;
            Arg.yDst = Arg.Dt - yBst; 
        elseif yBst < Arg.d % Elastic Neutral Axis is in the steel
            Arg.yBst = yBst; 
            Arg.yTst = Arg.d - yBst;
            Arg.yDst = Arg.Dt - yBst; 
        end
    % Long-term
        yBlt = (Alt*(Parameters.Deck.t/2 + Parameters.Deck.Offset + Arg.d) + Arg.A*Arg.yBnc)/(Alt+Arg.A); % formula to find centroid: y = sum(Ai*yi)/sum(Ai)
        if yBlt > Arg.d % Elastic Neutral Axis is in the deck
            Arg.yBlt = yBlt;
            Arg.yTlt = yBlt - Arg.d;
            Arg.yDlt = Arg.Dt - yBlt; 
        elseif yBlt < Arg.d % Elastic Neutral Axis is in the steel
            Arg.yBlt = yBlt;
            Arg.yTlt = Arg.d - yBlt;
            Arg.yDlt = Arg.Dt - yBlt; 
        end

    % Caclulate short-term and long term moments of inertia 

    % Short-Term 
    Arg.Ist = Arg.Ix + Arg.A*(Arg.yBst-Arg.d/2)^2 +...
        Ast*Parameters.Deck.t^2/12 + Ast*(Arg.yDst - Parameters.Deck.t/2)^2;   
    % Long-Term 
    Arg.Ilt=  Arg.Ix + Arg.A*(Arg.yBlt-Arg.d/2)^2 +...
        Alt*Parameters.Deck.t^2/12 + Alt*(Arg.yDlt - Parameters.Deck.t/2)^2;

    % Caclulate short-term and long-term elastic section modulii 

    % Short-Term 
    Arg.SDst = Arg.Ist/Arg.yDst;
    Arg.STst = Arg.Ist/Arg.yTst;
    Arg.SBst = Arg.Ist/Arg.yBst;
    % Long-Term 
    Arg.SDlt = Arg.Ilt/Arg.yDlt;
    Arg.STlt = Arg.Ilt/Arg.yTlt;
    Arg.SBlt = Arg.Ilt/Arg.yBlt;

end
       
end




