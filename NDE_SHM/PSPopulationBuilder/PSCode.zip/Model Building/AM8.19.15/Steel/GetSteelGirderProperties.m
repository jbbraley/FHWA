function [Parameters, Beam] = GetSteelGirderProperties(Parameters, Beam, Section, fCall)
% Check if fCall is empty
fCall(isempty(fCall)) = 1;

% Check if sending seperate Beam strucutre or just using Parameters
if isempty(Beam)
    Beam = Parameters.Beam.(Section);
end

% Section Properties
Beam = GetSectionProperties(Beam, Parameters, Section);

% Distribution Factors
if strcmp(Parameters.Design.Code, 'LRFD')
    [Parameters.Design.DF.(['DF' (Section)]), Parameters.Design.DF.(['DFV' (Section)])] = GetLRFDDistFact(Parameters, Beam, Section);
end

% Demands
Parameters.Demands.(Section).SL = GetSectionForces(Beam, Parameters, Parameters.Design.Code, Section, fCall);

% Capacity
if strcmp(Parameters.Design.Code, 'LRFD')
    Beam = GetLRFDResistance(Beam, Parameters.Demands.(Section).SL, Parameters, Section, []);
end

% Compactness
if strcmp(Parameters.Design.Code, 'LRFD')
    Beam = CompactCheckLRFD(Beam, Parameters);
end

% Aplpy to Parameters
Parameters.Beam.(Section) = Beam;
end