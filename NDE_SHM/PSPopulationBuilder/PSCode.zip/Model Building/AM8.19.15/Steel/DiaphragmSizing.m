function Parameters = DiaphragmSizing(Parameters, Options, CShapes, LShapes, Beam)
%% Get Depth of Beam in case it isnt there
if ~isfield(Beam, 'd') 
    % Beam Depth for wind load
    Beam.d = max(Parameters.Length/Parameters.Design.MaxSpantoDepth);
end

%% Requirement Selection
if Parameters.Dia.autoType
    if Beam.d <= 30                                                       % max height of beam for channel to be at least 1/2 height of beam
        Parameters.Dia.Type = 'Beam';    
    else
        % Choose Chevron or Cross based on angle of incidence between
        % bottom and diagonal
        minRatio = tan(Options.Dia.MinDiaAngle*pi/180);                     % ratio of depth to spacing
        
        if Beam.d/Parameters.GirderSpacing < minRatio                       % if cross would put angle less than 40, use chevron
            Parameters.Dia.Type = 'Chevron';
        else
            Parameters.Dia.Type = 'Cross';
        end
    end
end

%% Diaphragm Section Property Assignment
switch Parameters.Dia.Type
    case 'Beam'
        %% Get Requirement
        Parameters.Dia.Req = Beam.d/2;
        
        %% Find Most Beam Efficient Section
        % Beam Section
        found = 0;
        for i=31:-1:1
            CurrentBeamA = CShapes(i).A;
            CurrentBeamd = CShapes(i).d;
            
            if Parameters.Dia.Force/CurrentBeamA > 0.55*Parameters.Dia.Fy; % 0.55fy % if wind force is greater than 55% yield
                continue
            end
            
            if CurrentBeamd < Parameters.Dia.Req % depth requirement - if channel is at least 1/2 height of web depth
                continue
            end
            
            % if it made it this far, it works...channels sorted by Area so
            % this is best one
            found = 1;
            break
        end
        
        if found % if iteration was successful
            Parameters.Dia.A = CShapes(i).A;
            Parameters.Dia.bf = CShapes(i).bf;
            Parameters.Dia.tf = CShapes(i).tf;
            Parameters.Dia.tw = CShapes(i).tw;
            Parameters.Dia.d = CShapes(i).d;
            Parameters.Dia.SectionName = CShapes(i).AISCManualLabel;
            Parameters.Dia.Section = [Parameters.Dia.bf, Parameters.Dia.d, 0, Parameters.Dia.tf, Parameters.Dia.tw, 0];
        else % recursive call to GetDiaRequirement for cross bracing type
            Parameters.Dia.Type = 'Chevron';
            Parameters = DiaphragmSizing(Parameters, Options, CShapes, LShapes, Beam);
        end
    otherwise % Cross or Chevron
        %% Requirement
        % Length of Memebr
        if strcmp(Parameters.Dia.Type, 'Cross')
            diaLen = sqrt(Parameters.GirderSpacing^2+Beam.d^2);
            Parameters.Dia.Force = Parameters.Dia.Force/4;
        else
            % Find greatest member length
            if sqrt(3/4)*Parameters.GirderSpacing > Beam.d                     % COndition when diagonal is greater in length than bottom chord
                diaLen = sqrt(Parameters.GirderSpacing^2/4+Beam.d^2);
            else                                                             % bottom chord is longest
                diaLen = Parameters.GirderSpacing;
            end
            Parameters.Dia.Force = Parameters.Dia.Force/3;
        end
        
        % Additional Skew Length
        % get length of diagonal or chord if bracing is skewed
        if strcmp(Parameters.Dia.Config, 'Parallel')
            diaLen = diaLen/cos(max([Parameters.SkewNear, Parameters.SkewFar])*pi()/180);
        end
        
        % Get radius of gyration requirement
        % Requirement is radius of gyration for Kl/r > slenderness ratio
        % radius of gyration = Kl/slendernessR
        Parameters.Dia.Req = Parameters.Dia.K*diaLen/Parameters.Dia.slendernessR;

        %% Find Angle Section
        found = 0;
        for i=127:-1:1
            CurrentBeamrx = LShapes(i).rx;
            CurrentBeamA = LShapes(i).A;
            
            if Parameters.Dia.Force/CurrentBeamA > 0.55*Parameters.Dia.Fy; % 0.55fy
                continue
            end
            
            if CurrentBeamrx < Parameters.Dia.Req
                continue
            end
            
            % if it made it this far, it works...channels sorted by Area so
            % this is best one
            found = 1;
            break
        end
        
        if found % if iteration was successful
            Parameters.Dia.A = LShapes(i).A;
            Parameters.Dia.B = LShapes(i).B;
            Parameters.Dia.d = LShapes(i).d;
            Parameters.Dia.t = LShapes(i).t;
            Parameters.Dia.SectionName = LShapes(i).AISCManualLabel;
            Parameters.Dia.Section = [Parameters.Dia.B, Parameters.Dia.d, 0, Parameters.Dia.t, Parameters.Dia.t, 0];
        else
            Parameters.Dia.Section = [];
            Parameters.Dia.SectionName = 'None Found';
        end
end
end %GetDiaSection