function Parameters = SteelGirderSizing_Main(Parameters, Options, Section, CShapes, WShapes, LShapes)
%% ASD & LRFD Girder Sizing for Multi-girder Designs
oldFolder = pwd;
cd('..\');
if isempty(WShapes)
    filepath = [pwd '\Tables\WShapes_Current.mat'];
    load(filepath);
end
if isempty(CShapes)
    filepath = [pwd '\Tables\CShapes_Current.mat'];
    load(filepath);
end
if isempty(LShapes)
    filepath = [pwd '\Tables\LShapes_Current.mat'];
    load(filepath);
end
cd(oldFolder);

% Get LL Deflection Requirements
exitflagP = -99;
exitflagR = -99; % make these default for not running case
exitflagCP = -99;

% Get Diaphragm Requirement for Beam
if strcmp(Section, 'All')
    beamSection = {'Int';'Ext'};
else
    beamSection = Section;
end

for i = 1:length(beamSection)
    Beam = Parameters.Beam.(beamSection{i});
    Parameters = DiaphragmSizing(Parameters, Options, CShapes, LShapes, Beam);
end

% Runs innitial design for simple or continuous span with no cover plate
% for rolled and plate girder
if strcmp(Parameters.Design.Code, 'ASD')
    if Parameters.Spans == 1
        [Parameters_tempR, exitflagR] = RolledGirderSizingASD(Parameters, Options, Section, WShapes);
        Parameters.tempR = Parameters_tempR;
    end
    [Parameters_tempP, exitflagP] = PlateGirderSizingASD(Parameters);
    Parameters.tempP = Parameters_tempP;
elseif strcmp(Parameters.Design.Code, 'LRFD')
    if Parameters.Spans == 1
        [Parameters_tempR,exitflagR] = RolledGirderSizingLRFD(Parameters, Options, Section, WShapes);
    end
      [Parameters_tempP,exitflagP] = PlateGirderSizingLRFD(Parameters, Section);
end

% Handle exitflags
if strcmp(Section, 'All') 
    exitflagP = min(exitflagP(1,2));
    if Parameters.Spans == 1
        exitflagR = min(exitflagR(1,2));
    end
else
    exitflagP = min(exitflagP(1,2), exitflagP(2,2));
    if Parameters.Spans == 1
        exitflagR = min(exitflagR(1,2), exitflagR(2,2));
    end
end
%-----------FINAL GIRDER SIZING-------------------

% Saves design as either rolled girder or plate girder

if exitflagP > 0 && exitflagR > 0 % if both pass
        if Parameters_tempR.Beam.Int.A*(1 + Options.RolledGirder.Var) <= Parameters_tempP.Beam.Int.A % if rolled is lighter plus penatly
            Parameters = Parameters_tempR;
            Parameters.Beam.Type = 'Rolled'; %Rolled girder is designed
        else
            Parameters = Parameters_tempP;
            Parameters.Beam.Type = 'Plate';%Plate girder is designed
        end
elseif all(exitflagP > 0)
    Parameters = Parameters_tempP;
    Parameters.Beam.Type = 'Plate';%Plate girder is designed
%         Parameters = GetRatingFactor(Parameters);
else
    Parameters.Beam.Type = 'None';
end
      
Parameters.Design.ExitFlags = [exitflagR, exitflagP, exitflagCP];
end