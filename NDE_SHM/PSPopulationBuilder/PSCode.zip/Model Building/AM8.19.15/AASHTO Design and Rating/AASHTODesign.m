function Parameters = AASHTODesign(Parameters)
%% Get AASHTO Design Configuration
if strcmp(Parameters.Design.Code, 'ASD')
    % Lanes
    if Parameters.RoadWidth >= 20*12 && Parameters.RoadWidth <= 24*12
        Parameters.NumLane = 2;
    elseif Parameters.RoadWidth > 24*12
        Parameters.NumLane = floor(Parameters.RoadWidth/144);
    else
        Parameters.NumLane = 1;
    end
    
    % Live Load Deflection
    Parameters.Design.maxDelta = 800;
    
    % Impact
    Parameters.Design.Im = 50./(Parameters.Length/12+125);
    if Parameters.Design.IM > 0.3
        Parameters.Design.IM = 0.3;
    end
        
    % Determine minimum stiffness for gamma and span length
    % LL Reduction Factor
    if Parameters.NumLane <= 2
        Parameters.Design.MultiPres = 1;
    elseif Parameters.NumLane == 3
        Parameters.Design.MultiPres = 0.9;
    else
        Parameters.Design.MultiPres = 0.75;
    end
    
    % Delta is in in^5
    I = Parameters.Design.Load.DeltaPrime*Parameters.Design.maxDelta./Parameters.Length.*Parameters.Design.IM*...
        Parameters.NumLane*Parameters.Design.MultiPres/Parameters.NumGirder;
    
    Parameters.Beam.IstDelta = max(I); % in in^4
    
    % Modulous Ratio
    Parameters.Deck.N = Parameters.Beam.E/Parameters.Deck.E;

    % Distribution Factors - Axle Distribution is 1/2 of wheel load
    % distribution
    Parameters.Design.DF = Parameters.GirderSpacing/5.5/12/2;   
    
elseif strcmp(Parameters.Design.Code, 'LFD')
    Parameters.Design.Code = 'LFD';
 
elseif strcmp(Parameters.Design.Code, 'LRFD')
    % Diaphragms ----------------------------------------------------------

    if Parameters.Dia.autoConfig
        if Parameters.SkewNear > 20 || Parameters.SkewFar > 20
            Parameters.Dia.Config = 'Normal';
        else
            Parameters.Dia.Config = 'Parallel';
        end
    end
        
    if strcmp(Parameters.structureType, 'Steel')
        % Wind Force Calculatios
        % Velocity Assumptions
        Vo = 12.0; %MPH (largest for city) T3.8.1.1-1
        Zo = 8.20; %ft (largest for city) T3.8.1.1-1
        Z = 30; %ft, Assumed height of structure above low ground or water level
        V30 = 100; %MPH, Assumed fastest wind speed at Z
        Vb = V30; % Assumed in absence of better criterion 3.8.1.1

        % Design wind velocity
        Vdz = 2.5*Vo*(V30/Vb)*log(Z/Zo); %MPH

        % Wind Pressure on Structure
        Pb = 0.050; %ksf, Base pressure for beams
        Pd = Pb*(Vdz^2)/10000; %ksf, design wind pressure

        % Wind force per unit length
        if isfield(Parameters.Beam.Ext, 'd')
            d = Parameters.Beam.Ext.d;
        else
            d = Parameters.Length/Parameters.Design.MaxSpantoDepth;
        end
        W = (1.40*d*Pd*1000)/(2*144); %lb/in

        Parameters.Dia.Force = W*max(Parameters.Length)/(Parameters.NumDia + 1); %lbs

        % slenderness ratio
        if Parameters.SkewNear > 20 || Parameters.SkewFar > 20
            Parameters.Dia.slendernessR = 140;
        else
            Parameters.Dia.slendernessR = 120;
        end
        Parameters.Dia.K = 1;
    else
        Parameters.Dia.Type = 'Concrete';
    end
% Live Load ---------------------------------------------------------------   
    % Lanes 
    if Parameters.RoadWidth >= 20*12 && Parameters.RoadWidth <= 24*12
        Parameters.NumLane = 2;
    elseif Parameters.RoadWidth > 24*12
        Parameters.NumLane = floor(Parameters.RoadWidth/144);
    else
        Parameters.NumLane = 1;
    end
    % Live Load Deflection
    Parameters.Design.maxDelta = 800;
    
    % Dynamic Load Allowance
    Parameters.Design.IM = 1.33;  %To be applied to static wheel load, not pedestrian or lane load
    
    % Fatigue
    Parameters.Design.IMF = 1.15; % Fatigue impact factor
    Parameters.Design.FTH = 12000;

% Composite Section -------------------------------------------------------
    % Modulous Ratio (N)
    Parameters.Deck.N = Parameters.Beam.E/Parameters.Deck.E;
    
    %Multipresence factors - To be used only with Lever Rule
    Parameters.Design.MultiPres = 1;
    Parameters.Design.MulPres(1) = 1.2;
    Parameters.Design.MulPres(2) = 1;
    Parameters.Design.MulPres(3) = 0.85;
    Parameters.Design.MulPres(4) = 0.65;

    % Determine Effective Width of Deck for Interior or Exterior Beam beam
    Parameters.Deck.be.beInt = Parameters.GirderSpacing;
    Parameters.Deck.be.beExt = Parameters.Overhang + Parameters.GirderSpacing/2;
   
    % Transform section to short-term/long-term
    % Determine short-term and long-term effective width of deck for
    % interior girder and exterior girder
    Parameters.Deck.be.beInt_st = Parameters.Deck.be.beInt/Parameters.Deck.N;
    Parameters.Deck.be.beInt_lt = Parameters.Deck.be.beInt/(3*Parameters.Deck.N);
    Parameters.Deck.be.beExt_st = Parameters.Deck.be.beExt/Parameters.Deck.N;
    Parameters.Deck.be.beExt_lt = Parameters.Deck.be.beExt/(3*Parameters.Deck.N);

    % Determine short-term and long-term effective area of deck for
    % interior  girder and exterior girder
    Parameters.Deck.A.AInt_st = Parameters.Deck.t*Parameters.Deck.be.beInt_st;
    Parameters.Deck.A.AInt_lt = Parameters.Deck.t*Parameters.Deck.be.beInt_lt;
    Parameters.Deck.A.AExt_st = Parameters.Deck.t*Parameters.Deck.be.beExt_st;
    Parameters.Deck.A.AExt_lt = Parameters.Deck.t*Parameters.Deck.be.beExt_lt;  
    
else
    Parameters.Design.Code = 'NA';
end
end % CoverPlateDesign()