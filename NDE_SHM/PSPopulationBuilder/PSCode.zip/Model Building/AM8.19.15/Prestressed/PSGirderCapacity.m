function [ Arg, Beam] = PSGirderCapacity( Parameters, Beam )
%% Stress is Prestressing strands at nominal flexural resistance at midspan
% Calculate eccentricity
if ~isfield(Beam, 'PSEcc')
    e = Beam.yb-Beam.PSCenter;
    Beam.PSEcc = e;
end
if ~isfield(Beam, 'PSCenter')
    Beam.PSCenter = Beam.yb - Beam.PSEcc;
end

% Compressive stress due to effective prestress
if ~isfield(Parameters.Beam, 'PSForce')
    Beam = GetPSForce(Parameters, Beam);
end
    

[a, c, NAexitflag] = PSLocateNA(Parameters, Beam);
Beam.NA = c;
% S5.7.3.1.1-2
k = 2*(1.04-Beam.PSSteel.Fy/Beam.PSSteel.Fu);

Beam.PSSteel.Fs = Beam.PSSteel.Fu*(1-k*c/(Beam.d+Parameters.Deck.t-Beam.PSCenter));

%% Flexural Resistance
% Moment Capacity (lb-in)
if NAexitflag==1
    Arg.Mn_pos = min(Beam.PSSteel.At*Beam.PSSteel.Fs.*(Beam.d+Parameters.Deck.t-Beam.PSCenter-a./2)); % lb-in
elseif NAexitflag==2
    Arg.Mn_pos = min(Beam.PSSteel.At*Beam.PSSteel.Fs.*(Beam.d+Parameters.Deck.t-Beam.PSCenter-Parameters.Deck.t/2)-...
        0.85*Beam.fc*Beam.bft*a*(a-Parameters.Deck.t)*(1/2)); % lb-in

else
    Arg.Mn_pos = min(Beam.PSSteel.At*Beam.PSSteel.Fs.*(Beam.d+Parameters.Deck.t-Beam.PSCenter-Parameters.Deck.t/2)...
        -0.85*Beam.fc*Beam.bft*(Beam.tft(1)+Beam.tft(2)/2)*(Parameters.Deck.t+(Beam.tft(1)+Beam.tft(2)/2))/2 ...
        -0.85*Beam.fc*Beam.tw*(a-Parameters.Deck.t-sum(Beam.tft))*(a+sum(Beam.tft))/2);% lb-in
end

% Design reinforcing over negative moment region
if Parameters.Spans>1
    Mu = max(abs(Parameters.LRFD.M_neg));
%     if Parameters.Beam.fc <= 4000
%     beta = .85;
%     else
%     beta = max(0.85-(Beam.fc-4000)/1000*.05, 0.65);
%     end
%     
%     ds = (Beam.d+Parameters.Deck.Offset+Parameters.Deck.t/2);
%     a = sym('a');
%     % Capacity equation as a function of reinforcement area
%     Mn = Beam.RFSteel.Fy*a*(ds-beta*(Beam.RFSteel.Fy*a)/(0.85*beta*Beam.fc*Beam.bfb))== Mu/0.9;
%     As_neg = min(eval(solve(Mn,a)));
%     % Adjust area for 2 levels of reinforcing with the spacing rounded down to the nearest half inch
%     Beam.RFSteel.As_neg = 0.44*2/(floor(2*0.44/(As_neg/max(Parameters.Deck.beff))*2)/2)*max(Parameters.Deck.beff);
%     
%     % Recalculate Resistance
%     Mcheck = @(A) Beam.RFSteel.Fy*A*(ds-beta*(Beam.RFSteel.Fy*A)/(0.85*beta*Beam.fc*Beam.bfb));
    Arg.Mn_neg = Mu/0.9; % Mcheck(Beam.RFSteel.As_neg);
end
Arg.Vn = Parameters.LRFD.V/0.9;
Fpb = Beam.PSForce/Beam.A+Beam.PSForce*Beam.PSEcc*Beam.yb/Beam.Ix;
% Allowable Tensile Stress
Fat = 6*sqrt(Beam.fc);
% Stress Capacity (psi)
Arg.Fn_pos = Fpb+Fat;


end

