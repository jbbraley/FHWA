function [ Beam ] = GetPSForce( Parameters, Beam)
%GETPSFORCE Calculates the actual effective prestress force after all losses
%   Based on the Girder section and the number of PS strands and their diameter
%% Stress in Prestressing Tendons
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% eccentricity
e = Beam.PSEcc;

%% Stress Limits
% Immediately prior to transfer
Fpi = 0.75*Beam.PSSteel.Fu; % T5.9.3-1 (psi)

% Elastic Shortening
% Midspan Moment due to member self-weight
Mg = abs(Parameters.Design.SLG.SS.maxDLM_POI)*Beam.Weight/12;
%Prestress loss due to elastic shortening in pretensioned members - S5.9.5.2.3
Fpes = (Beam.PSSteel.At*Fpi*(Beam.Ix+(e)^2*Beam.A)-e*Mg*Beam.A)/...
    (Beam.PSSteel.At*(Beam.Ix+e^2*Beam.A)+Beam.A*Beam.Ix*Beam.Eci/Beam.PSSteel.E); % psi

% Prestressing stress at transfer
Beam.PSSteel.Fpt = Fpi-Fpes;
% Prestressing force at transfer
Pt = Beam.PSSteel.At*Beam.PSSteel.Fpt; %lb

% Shrinkage losses
if ~isfield(Parameters,'RHumidity')
    RH = 70;
else
    RH = Parameters.RHumidity;
end
Fpsr = (17-.15*RH)*1000; %psi S5.9.5.4.2

% Creep Losses - S5.9.5.4.3
Fcgp = Fpes/(Beam.PSSteel.E/Beam.Eci);
Fcdp = (max(Parameters.Demands.SL.DLdeck)+Parameters.Demands.SL.DLhaunch+Parameters.Demands.SL.DLdiaphragm)*abs(Parameters.Design.SLG.SS.maxDLM_POI)*e/Beam.Ix+...
    max(Parameters.Demands.SL.MSDL_pos).*(Beam.yBst-Beam.PSCenter)./Beam.Ist;
Fpcr = max(12*Fcgp-7*Fcdp,0);

%Relaxation - S5.9.5.4.4
Fpr2 = (20000-.4*Fpes-.2*(Fpsr+Fpcr))*.3;

%Total loss after transfer
DeltaFpt = max(Fpes+Fpsr+Fpcr+Fpr2);

% Final Effective prestress response
Beam.PSSteel.Fpe = min(.80*Beam.PSSteel.Fy, 0.75*Beam.PSSteel.Fu-DeltaFpt);

% Total Prestress Force after losses
Beam.PSForce = Beam.PSSteel.At*Beam.PSSteel.Fpe;

end

