function [ Parameters] = PSGirderDesign( Parameters )
%PSGIRDERDESIGN Designs a prestressed section with prestressing force and eccentricity
%   Parameters - Structure containing design and structural parameters
 
%       jbb - 7/22/2015
exitflag = 0;
n_sect = 0;
fc = Parameters.Beam.fc;
while exitflag==0 && n_sect<3
    n_sect = n_sect+1;
    for jj=1:3
        if exitflag
            break
        end
        Parameters.Beam.fc = fc+(jj-1)*1000;
        Parameters.Beam.E = 57000*sqrt(Parameters.Beam.fc);
        Parameters.Beam.fci = 0.8*Parameters.Beam.fc;
        Parameters.Beam.Eci = 57000*sqrt(Parameters.Beam.fci);
        %% Calculate Section Forces
        [Beam, SectionFlag] = GetPSGirder(Parameters, n_sect);
        if ~SectionFlag
            return
        end
        [Parameters, Beam] = PSSectionForces(Parameters, Beam);

        Parameters.Beam = MergeStructures(Beam, Parameters.Beam);

        % %% Strand minimization algorithm
        % 
        % % Set bounds
        % ub = Beam.MaxStrands;
        % lb = Beam.DiaStart;
        % %starting point
        % x0 = ub; %(ub+lb)/2+(ub+lb)/8*randn(1,1);
        % 
        % % Objective function
        % strands = @(x)ceil(x/2)*2; % the number of strands rounded up to the nearest even integer
        % % set options
        % tolx = 0.5; % maintain even number of strands
        % typx = 20;
        % 
        % con = @(x)PSDesignCheck(x, Parameters, Parameters.Beam);
        % options = optimset('Algorithm','interior-point','Display','off','TypicalX',typx,'TolX', tolx);
        % [x, ~, exitflag, ~] = fmincon(strands, x0, [], [], [], [], lb, ub, con, options);

        %% Iterate through increasing number of strands until design passes
        iter = 0;
        c = [];
        for ii = 8:2:Beam.MaxStrands
            x = ii;
            iter = iter+1;
            [c(:,iter), ~, ~] = PSDesignCheck(x, Parameters, Parameters.Beam);
            if all(c(:,iter)<=0)
                exitflag = 1;
                break
            end
            if x==Beam.MaxStrands
                exitflag = 0;
            end
        end
    end
end
    

% Get final constraint and Prestressed parameters
if exitflag > 0
    [Constraints, Parameters, Beam] = PSDesignCheck(x, Parameters, Parameters.Beam);
    Beam.PSSteel.NumStrands = x;

    Beam.Constraints = Constraints;

%     Rbar(:,1) = [3 4 5 6 7 8 9 10 11 14 18];
%     Rbar(:,2) = [.11 .20 .31 .44 .60 .79 1.00 1.27 1.56 2.25 4];
%     Rbar(:,3) = [.375 .5 .625 .75 .875 1 1.128 1.27 1.41 1.693 2.257];

% %     if Beam.RFSteelCheck
%         Num = max(Beam.RFSteel.A)./Rbar(:,2);
%         limit = (Beam.bft-4)./(Rbar(:,3)+2);
%         barind = find((Num-limit)>0,1,'last');
%         if ~isempty(barind)
%             Beam.RFSteel.BarNo = Rbar(barind,1);
%             Beam.RFSteel.NumBars = ceil(Num(barind));
%             Beam.RFSteel.A = Beam.RFSteel.NumBars*Rbar(barind,2);
%             if Beam.RFSteel.NumBars*(Rbar(barind,3)+2)+2<Beam.bft
%                 Beam.RFCenter = 2+Rbar(barind,3)/2;
%             else
%                 row1 = floor((Beam.bft-4)/(Rbar(barind,3)+2));
%                 row2 = Beam.RFSteel.NumBars-row1;
%                 Beam.RFCenter = (Rbar(barind,2)*row1*(2+Rbar(barind,3)/2)+Rbar(barind,2)*row2*(4+Rbar(barind,3)*3/2))/Beam.RFSteel.A;
%             end
%         else
%             Beam.RFSteel.A = 0;
%             Beam.RFSteel.NumBars = 0;
%         end
% %     end
end
Parameters.Beam = Beam;
Parameters.Beam.Exitflag = exitflag;
end

function [c, Parameters, Beam] = PSDesignCheck(x, Parameters, Beam)

%% 7 Wire Strand diam. & area
switch Parameters.Beam.Type
    case {'AASHTO' 'BulbTee'}
        DA(1) = .500;
        DA(2) = .153;
    case 'PCBT'
        DA(1) = .600;
        DA(2) = .217;
end

% Calculate area of prestressing steel
Beam.PSSteel.At = x*DA(2);
% Record diameter of strands
Beam.PSSteel.d = DA(1);

% Calculate centroid of strands
Beam.PSCenter = GetPSCenter(Beam, x);

% Get capacity of beam with prestressing
[Capacity, Beam] = PSGirderCapacity(Parameters, Beam);       
Beam.Capacity = Capacity;
        
% Get demands based on single line girder model
[Parameters, Beam] = PSGirderDemand(Parameters, Beam);

        
%% Constraints
% Stress limits at transfer
c(1) = -.60*Parameters.Beam.fci-min(Parameters.Design.Transfer.StressT_min); % S5.9.4.1.1
% c(2) = max(Parameters.Design.Transfer.StressT_max)-0.24*sqrt(Parameters.Beam.fci/1000)*1000;
% Disregarded as this constraint can fail without strands with varying bonding at girder ends
c(2) = -.60*Parameters.Beam.fci-min(Parameters.Design.Transfer.StressB_min);

% Stress limits under Service Loads
c(3) = -.60*Parameters.Beam.fc - min(Parameters.Design.Service.StressT_min); % S5.9.4.2.1-1

c(4) = -.45*Parameters.Beam.fc - min(Parameters.Design.PS1.StressT_min);
c(5) = max(Parameters.Design.PS1.StressB_max)-.19*sqrt(Parameters.Beam.fc/1000)*1000;

c(6) = max(Parameters.Design.PS3.StressB_max)-.19*sqrt(Parameters.Beam.fc/1000)*1000;

c(7) = -.6*Parameters.Deck.fc - min(Parameters.Design.Deck.Stress_min);

% Strength Requirements
c(8) = max(Parameters.LRFD.M_pos) - Capacity.Mn_pos;
if Parameters.Spans>1
    c(9) = max(Parameters.LRFD.M_neg) - Capacity.Mn_neg;
end

% Cracking moment check
c(10) = min(1.33*max(Parameters.LRFD.M_pos), max(Beam.Mcr))-Capacity.Mn_pos;

end
