function [ Parameters, Beam ] = PSGirderDemand( Parameters, Beam )
%PSGIRDERDEMAND Calculates the demands for Prestressed girder design 
% Includes stresses under transfer, strength and service conditions
%   Parameters - Parameters Structure


e = Beam.PSEcc;


% Prestressing stress at transfer
Fpt = Beam.PSSteel.Fpt;
% Final Effective prestress response
Fpe = Beam.PSSteel.Fpe;

%% Development Length
% Transfer Length
Lt = 60*Beam.PSSteel.d;

% Development Length
% Fully bonded strands
Ld_f = 1.6*(Beam.PSSteel.Fs-2/3*Fpe)/1000*Beam.PSSteel.d;
% Partially debonded strands
Ld_p = 5/4*Ld_f;

%% Flexural stresses
% Stress in prestressing strands at transfer, strength, and service conditions
% Girder Self weight moment
for i=1:Parameters.Spans
    %% Stress in prestressing strands at transfer, strength, and service conditions
    PSF(i).Strength = zeros(ceil(Parameters.Length(i)/24)*12,2);
    PSF(i).Service = zeros(ceil(Parameters.Length(i)/24)*12,2);
    PSF(i).Transfer = zeros(ceil(Parameters.Length(i)/24)*12,2);
    PSF(i).Strength(:,1) = [1:ceil(Parameters.Length(i)/24)*12];
    PSF(i).Service(:,1) = [1:ceil(Parameters.Length(i)/24)*12];
    PSF(i).Transfer(:,1) = [1:ceil(Parameters.Length(i)/24)*12];
    
    % Stresses at Transfer   
    PSF(i).Strength(1:ceil(Lt),2) = max(Fpe)/Lt*(PSF(i).Strength(1:ceil(Lt),1));

    PSF(i).Service(1:ceil(Lt),2) = max(Fpe)/Lt*(PSF(i).Service(1:ceil(Lt),1));

    PSF(i).Transfer(1:ceil(Lt),2) = max(Fpt)/Lt*(PSF(i).Transfer(1:ceil(Lt),1));
    
    % Stresses over Development Length
    PSF(i).Strength(ceil(Lt)+1:ceil(max(Ld_f)+Lt),2) = (max(Beam.PSSteel.Fs)-max(Fpe))/max(Ld_f)*(PSF(i).Strength(ceil(Lt)+1:ceil(max(Ld_f)+Lt),1)-(Lt))+max(Fpe);
    
    % Stresses in central region
    PSF(i).Strength(ceil(max(Ld_f)+Lt):end,2) = max(Beam.PSSteel.Fs);

    PSF(i).Service(ceil(Lt)+1:end,2) = min(Fpe);

    PSF(i).Transfer(ceil(Lt)+1:end,2) = max(Fpt);
    
    % Transform stress into force
    PSF(i).Strength(:,2) = PSF(i).Strength(:,2)*Beam.PSSteel.At;

    PSF(i).Service(:,2) = PSF(i).Service(:,2)*Beam.PSSteel.At;
    
    PSF(i).Transfer(:,2) = PSF(i).Transfer(:,2)*Beam.PSSteel.At;
    
    % Live Load Force
    LLForce(:,i) = (max(max(max(Parameters.Design.DF.DFInt, Parameters.Design.DF.DFExt))*Parameters.Design.SLG.Cont.M_Max(2:end,(i-1)*round(Parameters.Length(i)/12)+2:(i-1)*round(Parameters.Length(i)/12)+ceil(Parameters.Length(i)/24)+1),[],1)).';
   
    %% Stress in Beam
    Moment(i).SSUniform = [12:12:ceil(Parameters.Length(i)/24)*12];
    Moment(i).SSUniform = -(Moment(i).SSUniform.^2/2-Moment(i).SSUniform*Parameters.Length(i)/2)';
%     Moment(i).SSUniform = -Parameters.Design.SLG.SS.M_Max(1,2:Parameters.Length(i)/24+1)';
    Moment(i).ContUniform = Parameters.Design.SLG.Cont.M_Max(1,(i-1)*round(Parameters.Length(i)/12)+2:(i-1)*round(Parameters.Length(i)/12)+ceil(Parameters.Length(i)/24)+1)';
    
    % Beam Stresses after transfer
    Stress(i).Transfer(:,1) = [1:ceil(Parameters.Length(i)/24)];
    Stress(i).Transfer(:,2) = -PSF(i).Transfer(12:12:end,end)/Beam.A+PSF(i).Transfer(12:12:end,end)*e/Beam.St-Moment(i).SSUniform*Parameters.Demands.SL.DLstringer/Beam.St; %girder top stress in psi
    Stress(i).Transfer(:,3) = -PSF(i).Transfer(12:12:end,end)/Beam.A-PSF(i).Transfer(12:12:end,end)*e/Beam.Sb+Moment(i).SSUniform*Parameters.Demands.SL.DLstringer/Beam.Sb; %girder bottom stress in psi

    % Girder top stress under prestressing and dead load after losses
    Stress(i).Service(:,1) = -PSF(i).Service(12:12:end,end)/Beam.A+PSF(i).Service(12:12:end,end)*e/Beam.St-... 
        (Parameters.Demands.SL.wDL)*Moment(i).SSUniform/Beam.St -(Parameters.Demands.SL.wSDL)*Moment(i).ContUniform/min(Beam.STlt);

    % Girder top stress after losses under sum of all loads (Service I)
    Stress(i).Service(:,2) = Stress(i).Service(:,1)-LLForce(:,i)/min(Beam.STst);

    % Girder bottom stress after losses under prestress and dead load
    Stress(i).Service(:,4) = -PSF(i).Service(12:12:end,end)/Beam.A-PSF(i).Service(12:12:end,end)*e/Beam.Sb+... 
        (Parameters.Demands.SL.wDL)*Moment(i).SSUniform/Beam.Sb +(Parameters.Demands.SL.wSDL)*Moment(i).ContUniform/min(Beam.SBst);

    % Girder bottom stress under all loads (Service III)
    Stress(i).Service(:,5) = Stress(i).Service(:,4)+0.8*LLForce(:,i)/min(Beam.SBst);

    % Deck slab top stress under full load
    Stress(i).Service(:,6) = -(Parameters.Demands.SL.wSDL)*Moment(i).ContUniform/min(Beam.SDlt) -...
        LLForce(:,i)/min(Beam.SDst)/(Beam.E/Parameters.Deck.E);
    
    
     %% Longitudinal Steel at top of girder
    [T, I] = max(Stress(i).Transfer(:,2));
    C = Stress(i).Transfer(I,3);
    NA = T/((T-C)/Beam.d);
    PA = @(d) (Beam.bft+(d-Beam.tft(1)).*(Beam.tw-Beam.bft)/sum(Beam.tft(2:end))).*(T-(T-C)/Beam.d.*d);
    if NA<Beam.tft(1)
        F(1) = Beam.bft*NA*((T-(T-C)/Beam.d.*NA)+T)/2;
    elseif NA<sum(Beam.tft)
        F(1) = Beam.bft*Beam.tft(1)*((T-(T-C)/Beam.d.*Beam.tft(1))+T)/2;
        F(2) = integral(PA,Beam.tft(1),NA);
    else        
        F(1) = Beam.bft*Beam.tft(1)*((T-(T-C)/Beam.d.*Beam.tft(1))+T)/2;
        F(2) = integral(PA,Beam.tft(1),sum(Beam.tft));
        F(3) = Beam.tw*(NA-sum(Beam.tft))*(T-((T-C)/Beam.d.*(sum(Beam.tft)+NA))/2);
    end

    % Required area of reinforcing steel
    Beam.RFSteel.A(i) = 1.2*sum(F)/Beam.RFSteel.Fy; %min(0.5*Beam.RFSteel.Fy, 30000);              
end

for i=1:length(Parameters.Length)
%% Cracking Moment
Beam.Mcr(i) = (1.6*240*sqrt(Beam.fc/1000)+(PSF(i).Service(end,end))/Beam.A+(PSF(1).Service(end,end))*e/Beam.Sb)*min(Beam.SBst)-...
    ((Parameters.Demands.SL.wDL)*Moment(i).SSUniform(end)+(Parameters.Demands.SL.wSDL)*Moment(i).ContUniform(end))*(min(Beam.SBst)/Beam.Sb-1);

%% Maximum Girder Stress at Transfer
Parameters.Design.Transfer.StressT_max(i) = max(Stress(i).Transfer(:,2));
Parameters.Design.Transfer.StressT_min(i) = min(Stress(i).Transfer(:,2)); 
Parameters.Design.Transfer.StressB_min(i) = min(Stress(i).Transfer(:,3)); 

%% Maximum Girder Top Stress under Service Loads
Parameters.Design.Service.StressT_min(i) = min(Stress(i).Service(:,2)); 

%% Maximum Girder Stress under prestressing after losses
Parameters.Design.PS1.StressT_min(i) = min(Stress(i).Service(:,1));
Parameters.Design.PS1.StressB_max(i) = max(Stress(i).Service(:,4));

%% Girder bottom stress under all loads (Service III)
Parameters.Design.PS3.StressB_max(i) = max(Stress(i).Service(:,5));

%% Max. Deck stress under full load
Parameters.Design.Deck.Stress_min(i) = min(Stress(i).Service(:,6));

end

% Ultimate moment under strength conditions
Parameters.Design.Strength.M_pos = Parameters.LRFD.M_pos;
Parameters.Design.Strength.M_neg = Parameters.LRFD.M_neg;

%Save Beam Stress to Parameters
Beam.Stress = Stress;

% %% Temp Storage
% Temp = getappdata(0,'Temp');
% if isfield(Temp,'NA')
% Temp.NA(end+1) = Beam.NA;
% Temp.Fpt(end+1) = Beam.PSSteel.Fpt;
% else
%     Temp.NA = Beam.NA;
%     Temp.Fpt = Beam.PSSteel.Fpt;
% end
% setappdata(0,'Temp',Temp)

end

