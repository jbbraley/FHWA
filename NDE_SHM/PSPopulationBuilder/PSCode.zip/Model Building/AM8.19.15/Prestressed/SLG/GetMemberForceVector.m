function [M_Max, M_Min, V_Max, V_Min, M, V] = GetMemberForceVector(Delta, loadType, Parameters, numEle, I_diff)

% Initialize Vectors
V = zeros(numEle+1, size(Delta,2), size(Delta,3)); 
M = V; 

q = -1;
E = Parameters.Beam.E; %in psi
L = 12; % 12 inch lengths
if isfield(Parameters.Beam, 'Int') && Parameters.Beam.Int.CoverPlate.Length~=0
    CPratio = Parameters.Beam.Int.CoverPlate.Ratio;
else
    CPratio = 0;
end

eleK=E/L^3*[12,  6*L,   -12,  6*L;
            6*L, 4*L^2, -6*L, 2*L^2;
            -12, -6*L,  12,   -6*L;
            6*L, 2*L^2, -6*L, 4*L^2];
        
% Check for distributed loads and populate FEM vector
if any(strcmp(loadType, {'Lane_PatternEven'; 'Lane_PatternOdd'; 'Lane_All'; 'Dead'}))
    eleFEM = [q*L/2; q*L^2/12; q*L/2; -1*q*L^2/12]; 
else
    eleFEM = [0;0;0;0]*ones(1,size(Delta,3));
end

% Get local (internal) nodal actions from global displacement matrix
for i=1:numEle % for each ele 
    for j=1:size(Delta,2) % for each load location (lane loads have a singular value
        Loc = 2*i-1;
        
        if ~isempty(I_diff) && CPratio > 0
            if i > floor((1-CPratio)*numEle/2) && i < ceil((1+CPratio)*numEle/2)   
                K = eleK*I_diff;
            else
                K = eleK;
            end
        else
            K = eleK;
        end   
            
        V(i,j,:) = K(1,:)*squeeze(Delta(Loc:Loc+3,j,:)) - eleFEM(1,:);
        M(i,j,:) = -1*K(2,:)*squeeze(Delta(Loc:Loc+3,j,:)) + eleFEM(2,:);
        V(i+1,j,:) = -1*K(3,:)*squeeze(Delta(Loc:Loc+3,j,:)) + eleFEM(3,:);
        M(i+1,j,:) = K(4,:)*squeeze(Delta(Loc:Loc+3,j,:)) - eleFEM(4,:);
    end
end

% Find max at each DOF
M_Max = max(max(M,[],3),[],2);
M_Min = min(min(M,[],3),[],2);
V_Max = max(max(V,[],3),[],2);
V_Min = min(min(V,[],3),[],2);

end %function