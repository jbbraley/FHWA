function [ Beam , exitflag ] = GetPSGirder( Parameters, sectionNum)

switch Parameters.Beam.Type
    case 'AASHTO'
        MaxSpan(:,1) = 1:6;
        MaxSpan(:,2) = [48 70 100 120 145 167]';
    case 'BulbTee'
        MaxSpan(:,1) = [54 63 72]';
        MaxSpan(:,2) = [114 130 146]';
    case 'PCBT'
        MaxSpan(:,1) = [29 37 45 53 61 69 77 85 93]';
        MaxSpan(:,2) = [60 80 100 115 125 135 145 150 160]';
end

if isempty(sectionNum)
    Type = find((MaxSpan(:,2)-(max(Parameters.Length)/12)>=0),1,'first');
else
    Type = find((MaxSpan(:,2)-(max(Parameters.Length)/12)>=0),1,'first')+sectionNum-1;
end
if isempty(Type)
    exitflag = 0;
    return
else
    Type = min(Type, size(MaxSpan,1));
    exitflag = 1;
end

Beam = Parameters.Beam;
Beam.Name = [Beam.Type num2str(MaxSpan(Type,1))];

[Beam, Beam.Section] = PSSectionChoose(Beam.Name, Beam);

end 