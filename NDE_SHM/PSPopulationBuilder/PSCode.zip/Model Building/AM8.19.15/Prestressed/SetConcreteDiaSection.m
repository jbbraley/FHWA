function [ Dia ] = SetConcreteDiaSection( Parameters )
Dia = Parameters.Dia;
if ~isfield(Dia, 'b')
    Dia.b = 10;
else
    Dia.b = Parameters.Dia.b;
end
Dia.d = Parameters.Beam.d-sum(Parameters.Beam.tfb);
Dia.A = Dia.b*Dia.d;
Dia.SectionName = ['Rec' num2str(Dia.b) 'X' num2str(Dia.d)];
Dia.Section = [Dia.d Dia.b 0 0 0 0];

end

