function [Parameters, Beam] = PSSectionForces(Parameters, Beam)
%% Calculate Composite Section Properties
%% Effective Slab Width      
% Interior Girders
WF = [.25*min(Parameters.Length) 12*Parameters.Deck.t+max(Beam.tw, .5*Beam.bft) Parameters.GirderSpacing];
Parameters.Deck.beff(1) = min(WF);
% Exterior Girders
WF = [0.125*min(Parameters.Length) 6*Parameters.Deck.t+max(Beam.tw/2, .25*Beam.bft) Parameters.Overhang];
Parameters.Deck.beff(2) = Parameters.Deck.beff(1)/2+min(WF);

%% Haunch dimension
Haunch = Parameters.Deck.Offset; %in
bHaunch = Beam.bft;

%% Composite Section Properties
% Calculate Properties of Interior & Exterior Composite Section
Parameters.Deck.Ast = Parameters.Deck.t*Parameters.Deck.beff*Parameters.Deck.E/Parameters.Beam.E;

Beam.yBst = (Parameters.Deck.Ast*(Parameters.Deck.t/2 + Beam.d + Parameters.Deck.Offset) + Beam.A*Beam.yb)/(Parameters.Deck.Ast+Beam.A);
Beam.yTst = (Parameters.Deck.t + Beam.d + Parameters.Deck.Offset) - Beam.yBst;

Beam.Ist = Beam.Ix + Beam.A*(Beam.yBst-Beam.yb)^2 +...
    Parameters.Deck.Ast*Parameters.Deck.t^2/12 + Parameters.Deck.Ast*(Beam.yTst - Parameters.Deck.t/2)^2;

Beam.SDst = Beam.Ist/Beam.yTst;
Beam.STst = Beam.Ist/(Beam.yTst-Parameters.Deck.t-Parameters.Deck.Offset);
Beam.SBst = Beam.Ist/Beam.yBst;

%% Calculate Long term Properties of Interior & Exterior Composite Section - To be used with super imposed dead loads & Prestressing
Parameters.Deck.Alt = Parameters.Deck.t*Parameters.Deck.beff/(2)*Parameters.Deck.E/Parameters.Beam.E;

Beam.yBlt = (Parameters.Deck.Alt*(Parameters.Deck.t/2 + Beam.d + Parameters.Deck.Offset) + Beam.A*Beam.yb)/(Parameters.Deck.Alt+Beam.A);
Beam.yTlt = (Parameters.Deck.t + Beam.d + Parameters.Deck.Offset) - Beam.yBlt;

Beam.Ilt = Beam.Ix + Beam.A*(Beam.yBlt-Beam.yb)^2 +...
    Parameters.Deck.Alt*Parameters.Deck.t^2/12 + Parameters.Deck.Alt*(Beam.yTlt - Parameters.Deck.t/2)^2;

Beam.SDlt = Beam.Ilt/Beam.yTlt;
Beam.STlt = Beam.Ilt/(Beam.yTlt-Parameters.Deck.t);
Beam.SBlt = Beam.Ilt/Beam.yBlt;

%% Dead Load
Parameters.Demands.SL.DLdeck(1) = Parameters.GirderSpacing* Parameters.Deck.t*Parameters.Deck.density; % Interior
Parameters.Demands.SL.DLdeck(2) = (Parameters.Overhang+Parameters.GirderSpacing/2)*Parameters.Deck.t*Parameters.Deck.density; % Exterior
Parameters.Demands.SL.DLstringer = Beam.A*Parameters.Beam.density; 
if Parameters.Deck.Offset>0
    Parameters.Demands.SL.DLhaunch = Haunch*bHaunch*Parameters.Deck.density;
else
    Parameters.Demands.SL.DLhaunch = 0;
end

%Diaphragm Dead weight
if Parameters.NumDia ~=0
    Parameters.Demands.SL.DLdiaphragm = Parameters.Dia.density*Parameters.Dia.A*Parameters.NumDia*(Parameters.GirderSpacing-Beam.tw)./Parameters.Length;
else
    Parameters.Demands.SL.DLdiaphragm = 0;
end

% Curb and Parapet Dead weight
Parameters.Demands.SL.DLcurb = (Parameters.Sidewalk.Left*Parameters.Sidewalk.Height+Parameters.Sidewalk.Right*Parameters.Sidewalk.Height)*(Parameters.Sidewalk.density)/Parameters.NumGirder;
Parameters.Demands.SL.DLparapet = Parameters.Barrier.Width*Parameters.Barrier.Height*2*Parameters.Barrier.density/Parameters.NumGirder;

%Wearing Surface
Parameters.Demands.SL.DWearing(1) = 144/(12^3)*Parameters.Deck.WearingSurface*Parameters.GirderSpacing; % Interior
Parameters.Demands.SL.DWearing(2) = 144/(12^3)*Parameters.Deck.WearingSurface*(Parameters.GirderSpacing/2+Parameters.Overhang-min(Parameters.Sidewalk.Right, Parameters.Sidewalk.Left)-Parameters.Barrier.Width);


%% Positive Moment
Parameters.Demands.SL.wDL = max(Parameters.Demands.SL.DLdeck+Parameters.Demands.SL.DLstringer+Parameters.Demands.SL.DLhaunch+Parameters.Demands.SL.DLdiaphragm);

% Superimposed dead loads
Parameters.Demands.SL.wSDL = Parameters.Demands.SL.DLcurb + Parameters.Demands.SL.DLparapet+max(Parameters.Demands.SL.DWearing);

% Moments from dead load - multiply by DLM from unit dead load
Parameters.Demands.SL.MDL_pos = (Parameters.Demands.SL.wDL).*Parameters.Design.SLG.SS.maxDLM_POI;
Parameters.Demands.SL.MDL_neg = min((Parameters.Demands.SL.wDL).*min(Parameters.Design.SLG.SS.minDLM_POI));
% Moments form superimposed dead load (continuous over interior supports for multiple spans)
Parameters.Demands.SL.MSDL_pos = (Parameters.Demands.SL.wSDL).*Parameters.Design.SLG.Cont.maxDLM_POI;
Parameters.Demands.SL.MSDL_neg = min((Parameters.Demands.SL.wSDL).*min(Parameters.Design.SLG.Cont.minDLM_POI,[],2));
Parameters.Demands.SL.MDW_pos = max(Parameters.Demands.SL.DWearing)*Parameters.Design.SLG.Cont.maxDLM_POI;
Parameters.Demands.SL.MDW_neg = max(Parameters.Demands.SL.DWearing)*min(Parameters.Design.SLG.Cont.minDLM_POI,[],2);
Parameters.Demands.SL.VDL = (Parameters.Demands.SL.wDL+Parameters.Demands.SL.wSDL)*max(Parameters.Design.SLG.SS.maxDLV_POI,[],2);

%% Live Load (for continuous spans when multiple spans)
% Live load moments and shears
Parameters.Demands.SL.MLL_pos = Parameters.Design.SLG.Cont.maxM_POI; %short term composite;
Parameters.Demands.SL.MLL_neg = min(Parameters.Design.SLG.Cont.minM_POI,[],2);
Parameters.Demands.SL.VLL = max(Parameters.Design.SLG.Cont.maxV_POI,[],2);

%% Distribution Factors
[DF, ~] = GetLRFDDistFact(Parameters, Beam,'');
Parameters.Design.DF = DF;
DFM = max(max(DF.DFInt, DF.DFExt));
DFV = max(max(DF.DFVInt, DF.DFVExt));

% Live Load Using Distribution Factors
Parameters.LRFD.MLL_pos = Parameters.Demands.SL.MLL_pos.*max(DFM);
Parameters.LRFD.MLL_neg = Parameters.Demands.SL.MLL_neg.*max(DFM);
Parameters.LRFD.VLL = Parameters.Demands.SL.VLL.*max(DFV);

% Total Factored Moments
% Strength Limit State I
Parameters.LRFD.M_pos = 1.25*(Parameters.Demands.SL.MDL_pos+Parameters.Demands.SL.MSDL_pos)+1.5*(Parameters.Demands.SL.MDW_pos)+1.75*(Parameters.LRFD.MLL_pos); %+1.5*Parameters.Demands.SL.MDW_pos
Parameters.LRFD.M_neg = abs(1.25*(Parameters.Demands.SL.MDL_neg+Parameters.Demands.SL.MSDL_neg)+1.5*(Parameters.Demands.SL.MDW_neg)+1.75*(Parameters.LRFD.MLL_neg)); %+1.5*Parameters.Demands.SL.MDW_neg
Parameters.LRFD.V = 1.25*(Parameters.Demands.SL.VDL)+1.75*(Parameters.LRFD.VLL);




end % PSSectionForces ()