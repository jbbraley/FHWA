%              jbb -  07/10/2014
%
% Creates St7 model files with plates defining the cross section of AASHTO and BulbTee Sections
% Model Files are saved in folder entitles 'Sections' in the working folder
% St7 API Library must first be loaded (InitializeSt7())
% Designation   -   'AASHTO' or 'BulbTee'

function CreateSections(Designation)
global luINCH fuPOUNDFORCE suPSI muPOUND tuFAHRENHEIT euBTU tyPLATE kBeamTypeBeam
Units = [luINCH, fuPOUNDFORCE, suPSI, muPOUND, tuFAHRENHEIT, euBTU];
switch Designation
    case 'AASHTO'
        MaxSpan(:,1) = 1:6;
        MaxSpan(:,2) = [48 70 100 120 145 167]';
    case 'BulbTee'
        MaxSpan(:,1) = [54 63 72]';
        MaxSpan(:,2) = [114 130 146]';
    case 'PCBT'
        MaxSpan(:,1) = [29 37 45 53 61 69 77 85 93]';
        MaxSpan(:,2) = [60 80 100 115 125 135 140 150 155]';
end

for ii=1:size(MaxSpan,1)
    Type = ii;
    Name = MaxSpan(ii,1);
    
%% Girder dimensions
switch Designation
    case 'AASHTO'
        Dims = [28 36 45 54 63 72; 4 6 7 8 5 5; 0 0 0 0 3 3; 3 3 4.5 6 4 4; 0 0 0 0 0 0;5 6 7.5 9 10 10; 5 6 7 8 8 8; 12 12 16 20 42 42; 16 18 22 26 28 28; 6 6 7 8 8 8; 276 369 560 789 1013 1085; 12.59 15.83 20.27 24.73 31.96 36.38; 22750 50980 125390 260730 521180 733320; 18 28 48 66 76 76; 3 3 4.5 6 4 4; 0 0 0 0 13 13; 5 6 7.5 9 10 10]';
    case 'BulbTee'
        Dims = [54 63 72; 3.5 3.5 3.5; 2 2 2; 2 2 2; 0 0 0; 4.5 4.5 4.5; 6 6 6; 42 42 42; 26 26 26; 6 6 6; 659 713 767; 27.63 32.12 36.60; 268077 392638 545894; 36 36 36; 2 2 2; 16 16 16; 10 10 10]';
    case 'PCBT'
        Dims = [4 1.5 2 3.5 3 7 47 32 7 2 18 3.5 9];
        Dims = padarray(Dims, [size(MaxSpan,1)-1 0],'replicate','post');
        Dims = cat(2,[29 37 45 53 61 69 77 85 93]', Dims);
        Dims2 = [643.7 690.7 746.7 802.7 858.7 914.7 970.7 1026.7 1082.7; 14.66 18.43 22.23 26.06 29.92 33.79 37.67 41.57 45.58; 66800 126000 207300 312400 443100 601300 788700 1007200 1258500; 48 50 52 56 62 64 68 72 76]'; 
        Dims = [Dims(:,1:end-4) Dims2 Dims(:,end-3:end)]; 
end 

Parameters.Beam.d = Dims(Type,1); %Depth
Parameters.Beam.bft = Dims(Type,8); %width top flange
Parameters.Beam.tw = Dims(Type,10); %thickness web
Parameters.Beam.tft = [Dims(Type,2) Dims(Type,3)+Dims(Type,4)]; %thickness top flange
Parameters.Beam.tfb = [Dims(Type,7) Dims(Type,6)+Dims(Type,5)]; % thickness of bottom blange
Parameters.Beam.bfb = Dims(Type,9); % width of bottom flange
Parameters.Beam.A = Dims(Type,11); % total area
Parameters.Beam.Ix = Dims(Type,13); % Moment of inertia
Parameters.Beam.yb = Dims(Type,12); % distance from bottom to NA
Parameters.Beam.yt = Parameters.Beam.d-Parameters.Beam.yb; % distance from top to NA
Parameters.Beam.Sb = Parameters.Beam.Ix/Parameters.Beam.yb; % Section modulus measure from bottom flange
Parameters.Beam.St = Parameters.Beam.Ix/Parameters.Beam.yt; % Section modulus measured from top flange
Parameters.Beam.MaxStrands = Dims(Type,14); % Normal maximum number of strands used

%% Create Cross Section
ModelPath = pwd;
ScratchPath = 'D:\Temp\';
dir = isdir([ModelPath '\Sections\']);
if dir == 0
    mkdir(ModelPath, 'Sections');
end

uID2 = 2;
ModelPathName = [ModelPath '\Sections\' Designation num2str(Name) '.st7']; 
iErr = calllib('St7API','St7NewFile', uID2, ModelPathName, ScratchPath);
HandleError(iErr);
iErr = calllib('St7API', 'St7SaveFile', uID2);
HandleError(iErr);
iErr = calllib('St7API', 'St7SetUnits', uID2, Units);
HandleError(iErr);

% Create Nodes
Node(1).x(1) = 0;
Node(1).y(1) = 0;

Node(1).x(end+1) = 0;
Node(1).y(end+1)= Dims(Type,7);

Node(1).x(end+1) = Dims(Type,18);
Node(1).y(end+1) = Node(1).y(end)+Dims(Type,6);

if strcmp(Designation, 'PCBT')
    Node(1).x(end+1) = Node(1).x(end)+Dims(Type,17);
    Node(1).y(end+1) = Node(1).y(end)+Dims(Type,5);
end

Node(1).x(end+1) = Node(1).x(end);
Node(1).y(end+1) = Parameters.Beam.d-sum(Parameters.Beam.tft);

Node(1).x(end+1) = Node(1).x(end)-Dims(Type,15);
Node(1).y(end+1) = Node(1).y(end)+Dims(Type,4);

Node(1).x(end+1) = Node(1).x(end)-Dims(Type,16);
Node(1).y(end+1) = Node(1).y(end)+Dims(Type,3);

Node(1).x(end+1) = Node(1).x(end);
Node(1).y(end+1) = Node(1).y(end)+Dims(Type,2);

Node(2).y = Node(1).y;

Node(2).x(1) = Dims(Type,9);
Node(2).x(end+1) = Node(2).x(end);
if strcmp(Designation, 'PCBT')
    Node(2).x(end+1) = Node(2).x(end)-Dims(Type,18);
end
Node(2).x(end+1) = Node(1).x(length(Node(2).x)+1)+Dims(Type,10);
Node(2).x(end+1) = Node(2).x(end);
Node(2).x(end+1) = Node(2).x(end)+Dims(Type,15);
Node(2).x(end+1) = Node(1).x(end)+Dims(Type,8);
Node(2).x(end+1) = Node(1).x(end)+Dims(Type,8);

u=0;
for j=1:2
    for i=1:length(Node(1).x)
        u=u+1;
        iErr = calllib('St7API', 'St7SetNodeXYZ', uID2, u,[Node(j).x(i), Node(j).y(i), 0]);
        HandleError(iErr);
    end
end


% Create Elements
EltNum = 0;

for i=1:length(Node(1).x)-1
    if strcmp(Designation, 'AASHTO') && Type<5 && i==5
        continue
    end
    Connection(1) = 4; % square
    Connection(2) = i;
    Connection(3) = i+1;
    Connection(4) = length(Node(1).x)+1+i;
    Connection(5) = length(Node(1).x)+i;
    EltNum=EltNum+1;
    iErr = calllib('St7API', 'St7SetElementConnection', uID2, tyPLATE, EltNum, 1, Connection);
    HandleError(iErr);
    iErr = calllib('St7API', 'St7SetEntityGroup', uID2, tyPLATE, EltNum, 1);
    HandleError(iErr);
end
% 
% iErr = calllib('St7API', 'St7NewBeamProperty', uID2, 1,kBeamTypeBeam,'test');
% HandleError(iErr);
clear Node

SectionData = zeros(1,34);
BXSName = [Designation num2str(Name)];
[iErr, SectionData] = calllib('St7API', 'St7GenerateBXS', uID2, BXSName,SectionData);
HandleError(iErr);
% 
% iErr = calllib('St7API', 'St7AssignBXS', uID2, 1, BXSName);
% HandleError(iErr);

iErr = calllib('St7API', 'St7SaveFile', uID2);
HandleError(iErr);

try
    calllib('St7API','St7CloseFile',uID2);
catch
end

end
end