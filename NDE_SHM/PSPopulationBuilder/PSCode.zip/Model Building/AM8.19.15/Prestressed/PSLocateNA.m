function [ a, c, exitflag] = PSLocateNA( Parameters, Beam)
%PSLocateNA Find the distance from the compression face (deck top surface) to the neutral axis
%   vargin = Parameters - structure containing structure info
%   vargout = c - distance in inches to neutral axis from top of compression face
if Parameters.Deck.fc <= 4000
    beta = .85;
else
    beta = max(0.85-(Parameters.Deck.fc-4000)/1000*.05, 0.65);
end
% S5.7.3.1.1-2
k = 2*(1.04-Beam.PSSteel.Fy/Beam.PSSteel.Fu);
% NA is in deck - S5.7.3.1.1-4
c = Beam.PSSteel.At*Beam.PSSteel.Fu/...
    (0.85*Parameters.Deck.fc*beta*Parameters.Deck.beff(1)+k*Beam.PSSteel.At*Beam.PSSteel.Fu/...
    (Beam.d+Parameters.Deck.t-Beam.PSCenter));

if beta*c>Parameters.Deck.t
    % NA is in member top flange
    exitflag = 2;
    c = (Beam.PSSteel.At*Beam.PSSteel.Fu-0.85*Parameters.Deck.fc.*...
        (Parameters.Deck.beff(1)-Beam.bft*Beam.E/Parameters.Deck.E).*Parameters.Deck.t)...
        ./(0.85*Parameters.Deck.fc*beta*Beam.bft*Beam.E/Parameters.Deck.E+k*Beam.PSSteel.At*Beam.PSSteel.Fu/...
        (Beam.d+Parameters.Deck.t-Beam.PSCenter));

    if beta*c>(Parameters.Deck.t+Beam.tft(1)+Beam.tft(2)/2)
        % NA is in web
        exitflag = 3;
        c = (Beam.PSSteel.At*Beam.PSSteel.Fu-0.85*Parameters.Deck.fc.*...
        (Parameters.Deck.t*(Parameters.Deck.beff(1)-Beam.tw*Beam.E/Parameters.Deck.E)+(Beam.tft(1)+Beam.tft(2)/2)*Beam.E/Parameters.Deck.E*(Beam.bft-Beam.tw)))...
        /(0.85*Parameters.Deck.fc*beta*Beam.tw*Beam.E/Parameters.Deck.E+k*Beam.PSSteel.At*Beam.PSSteel.Fu/...
        (Beam.d+Parameters.Deck.t-Beam.PSCenter));
        
    end
else
    exitflag = 1;
end

a = beta*c;
    
end

