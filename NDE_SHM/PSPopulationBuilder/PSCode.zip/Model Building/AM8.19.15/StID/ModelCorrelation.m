function Parameters = ModelCorrelation(Parameters, Options, paraData, meshData, testData)
%% Get App Data
if isempty(Parameters)
    Parameters = getappdata(0, 'Parameters');
end
if isempty(Options)
    Options = getappdata(0, 'Options');
end
if isempty(paraData)
    paraData = get(Options.handles.EditParameters_gui.tableParameterValues, 'Data');
end
if isempty(meshData)
    meshData = getappdata(0, 'meshData');
end
if isempty(testData)
    testData = getappdata(0, 'testData');
end
Node = getappdata(0,'Node');

%% Get Parameter and Alpha List
% get alpha to be changed for group
groupList = unique(cell2mat(paraData(:,4)));
% Convert Paradata [] groups to zeros
paraData(cellfun(@isempty,paraData(:,4)),4) = num2cell(0);
for i = 1:max(groupList)
    n = find(cell2mat(paraData(:,4)) == unique(i), 1, 'first');
    Alpha(i,1) = paraData{n,8};
    Alpha(i,2:3) = cell2mat(paraData(n,9:10));
    scale(i) = paraData(n,11);
    Parameters.CorrHistory.ParaNames{i} = paraData(find(cell2mat(paraData(:,4)) == i),1);
end
% Covert back
paraData(cell2mat(paraData(:,4)) == 0,4) = {[]};

%% Get Alphas for BCs
numPara = size(Alpha,1);
paraRange = numPara+1:numPara+length(nonzeros(Parameters.Bearing.Fixed.Update(1:7))); % find range of parameter indices
doflabel = ['U1';'U2';'U3';'R1';'R2';'R3'];
if ~isempty(paraRange)
    Parameters.Bearing.Fixed.Index(find(Parameters.Bearing.Fixed.Update)) =  paraRange; % apply index
    Parameters.CorrHistory.ParaNames{paraRange} = mat2cell([padarray(['Fixed Bearing '],[length(paraRange)-1 0], 'replicate','post')...
        doflabel(find(Parameters.Bearing.Fixed.Update),:)],ones(length(paraRange),1));
    Alpha(paraRange,:) = Parameters.Bearing.Fixed.Alpha(find(Parameters.Bearing.Fixed.Update),:); % apply alpha from parameters to master alpha list
    scale(paraRange) = {'log'};
end

numPara = size(Alpha,1);
paraRange = numPara+1:numPara+length(nonzeros(Parameters.Bearing.Expansion.Update(1:7).*~Parameters.Bearing.Linked)); % find range of parameter indices
if ~isempty(paraRange)
    Parameters.Bearing.Expansion.Index(find(Parameters.Bearing.Expansion.Update(1:7).*~Parameters.Bearing.Linked)) =  paraRange; % apply index
    Parameters.CorrHistory.IndKey(paraRange) = mat2cell([padarray(['Expansion Bearing '],[length(paraRange)-1 0], 'replicate','post')...
        doflabel(find(Parameters.Bearing.Expansion.Update(1:7).*~Parameters.Bearing.Linked),:)],ones(length(paraRange),1));
    Alpha(paraRange,:) = Parameters.Bearing.Expansion.Alpha(find(Parameters.Bearing.Expansion.Update(1:7).*~Parameters.Bearing.Linked),:); % apply alpha from parameters to master alpha list
    scale(paraRange) = {'log'};
    numPara = max(Parameters.Bearing.Expansion.Index); % update number of parameters
end

%% Initialize CorrHistory Variable to empty set
Parameters.CorrHistory.ObjFun = [];
Parameters.CorrHistory.FreqRes = [];
Parameters.CorrHistory.pairedMAC = [];
Parameters.CorrHistory.pairedModes = [];
Parameters.CorrHistory.MACRes = [];
Parameters.CorrHistory.MAC = [];
Parameters.CorrHistory.AnaFreq = [];
Parameters.CorrHistory.AnaDisp = [];
Parameters.CorrHistory.COMAC = [];
Parameters.CorrHistory.Alpha = Alpha(:,1);
Parameters.CorrHistory.AlphaStart = Alpha(:,1);
Parameters.CorrHistory.AlphaBounds = Alpha(:,2:3);
Parameters.CorrHistory.AlphaScale = scale;

%% Initial Mode Pairing
% Update model to initial Alpha start state
Parameters = UpdateModelParameters(Options.St7.uID, Parameters, Node);

% Run Natural Frequency Analysis
meshData = LoadNaturalFrequencyData(Options, meshData, meshData.nodeID);
% Get MAC and pairing
pairCoord = 1;
pairMAC = 1;
meshData = NaturalFrequencyComparison(Options, meshData, testData, pairCoord, pairMAC);

%% Set App Data
setappdata(0,'Para_temp',Parameters);
setappdata(0,'Options',Options);
setappdata(0,'meshData',meshData);
setappdata(0,'paraData',paraData);

%% Set Options for Least Squares Non-Linear Optimization
TolFun = Options.Correlation.TolFun;
TolX = Options.Correlation.TolX;
DiffMinChange = Options.Correlation.DiffMinChange;

outfun = @(x, optimValues, state)OutputFunction(x, optimValues, state);

options = optimset('Algorithm','trust-region-reflective',...
    'TolFun',TolFun,'TolX',TolX,'DiffMinChange',DiffMinChange,...
    'Display','final','OutputFcn',outfun);

AA = Alpha(:,1);
objfun = @(AA)SingleModelParameterEstimation(AA);

[AA, resnorm, residual, exitflag, output, lambda]...
    = lsqnonlin(objfun, AA, Alpha(:,2), Alpha(:,3), options);

Parameters.CorrHistory.exitflag = exitflag;
end %ModelCorrelation


