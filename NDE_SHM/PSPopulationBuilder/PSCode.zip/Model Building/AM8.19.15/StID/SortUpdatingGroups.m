function paraData = SortUpdatingGroups(paraData)
%% Applies/removes updating group # based on updating status
paraData(~cell2mat(paraData(:,7)),4) = cell(1,1);

%% Sorts updating groups so they are continuous
% Get gaps
updateGroups = cell2mat(paraData(:,4)); % get group #s
group = unique(updateGroups); % find unique #s

% if 1 is not used, make lowest # = 1
if ~any(group == 1)
    updateGroups(updateGroups == min(updateGroups)) = 1;
    group = unique(updateGroups);
end

gap = group(2:end) - group(1:end-1); % get gaps between group #2
ind = find(gap > 1,1)+1; % find index of gap > 2
while ~isempty(ind)
    bigGapInd = updateGroups == group(ind); % get index of matching group #s in big list
    updateGroups(bigGapInd) = updateGroups(bigGapInd) - (gap(find(gap > 1,1))-1); % adjust gap
    group = unique(updateGroups); % repeat from line 6
    gap = group(2:end) - group(1:end-1);
    ind = find(gap > 1,1)+1;  
end

paraData(~cellfun('isempty', paraData(:,4)),4) = num2cell(updateGroups);