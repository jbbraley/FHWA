function MassRedistribution(Parameters, Node, Options, meshData, testData)
% Set deck mass to zero
Doubles = [Parameters.Deck.E 0.2 0 5.55556*10^(-6) 0 0 0.210184 0.000219881];
iErr = calllib('St7API', 'St7SetPlateIsotropicMaterial', Options.St7.uID, 1, Doubles);
HandleError(iErr);

% Set Deck with initial mass
% initial Alpha values 
Alpha = Options.MassCorr.massMulti;

% Non structural mass distribution back to 1
dynFactor = [];
offsetList = [];
loadCase = 1;

nodeNum = [];
nsMass = [];
for i = 1:length(zoneMass)
    nodeNum = vertcat(nodeNum, zoneNodes{i});
    nsMass = vertcat(nsMass, zoneMass(i)*ones(length(zoneNodes{i}),1));
end
St7SetNonStructuralMass(Options.St7.uID, nodeNum, loadCase, nsMass, dynFactor, offsetList);

% Set up mass optimization function and options
% Tolerances
TolFun = Options.Correlation.TolFun;
TolX = Options.Correlation.TolX;

% Output function definition
outfun = @(x,optimValues,state)OutputFunction(x, optimValues, state, handles, Parameters, Options);

% Options
options = optimset('Algorithm','trust-region-reflective','TolFun',TolFun,'TolX',TolX,...
    'Display','final','OutputFcn',outfun);


lB = zeros(numZones,1);
uB = length(zoneNodes)*ones(length(zoneNodes),1);

if ~Options.Correlation.ConstantTotalMass
    % Objective function definition
    objfun = @(Alpha)MassRedistributionOptimization(Alpha, handles, Options, meshData, testData, zoneNodes, zoneMass);
    
    [Alpha, resnorm, residual, exitflag, output, lambda]...
        = lsqnonlin(objfun, Alpha, lB, uB, options);
else
    % Objective function definition
    objfun = @(Alpha)MassRedistributionOptimization(Alpha, handles, Options, meshData, testData, zoneNodes, zoneMass);
    con = @(Alpha)TotalMassCheck(Alpha);
    
    [xC,fvalC,exitflagC,outputC]...
        = fmincon(objfun, Alpha, [], [], [], [], lB, uB, con, options);
end

% Non structural mass distribution back to 1
dynFactor = [];
offsetList = [];
loadCase = 1;

nodeNum = [];
nsMass = [];
for i = 1:length(zoneMass)
    nodeNum = vertcat(nodeNum, zoneNodes{i});
    nsMass = vertcat(nsMass, zeros(length(zoneNodes{i}),1));
end

St7SetNonStructuralMass(Options.St7.uID, nodeNum, loadCase, nsMass, dynFactor, offsetList);

% Set deck mass to normal
Doubles = [Parameters.Deck.E 0.2 149.827/(12^3) 5.55556*10^(-6) 0 0 0.210184 0.000219881];
iErr = calllib('St7API', 'St7SetPlateIsotropicMaterial', Options.St7.uID, 1, Doubles);
HandleError(iErr);
end

function [c, ceq] = TotalMassCheck(Alpha)
numZones = length(Alpha);
ceq = sum(Alpha) - numZones;
c = [];
end

function obj = MassRedistributionOptimization(Alpha, handles, Options, meshData, testData, zoneNodes, zoneMass)
uID = Options.St7.uID;
ExpFreq = testData.freq;
numCorrFreq = length(Options.Correlation.expModes);

%% Update Model
fprintf('Updating Model...');

% Non structural mass distribution
dynFactor = [];
offsetList = [];
loadCase = 1;

nodeNum = [];
nsMass = [];
for i = 1:length(zoneMass)
    nodeNum = vertcat(nodeNum, zoneNodes{i});
    nsMass = vertcat(nsMass, Alpha(i)*zoneMass(i)*ones(length(zoneNodes{i}),1));
end

St7SetNonStructuralMass(uID, nodeNum, loadCase, nsMass, dynFactor, offsetList);

fprintf('Done\n');

%% Obtain Frequencies and Modeshapes from St7 Model
fprintf('Getting Modal Analysis Data...');

% Nat Freq Analysis
[meshData, MAC, COMAC] = DynamicsCalc(handles, Options, meshData, testData);
St7Freq = meshData.freq(:,1);

fprintf('Done\n');

%% Pair Frequencies and Mode Shapes Based on MAC
fprintf('Calculating MAC and Objective Function...');

rePair = 1; %1 if you want to repair modes based on new MACs
meshData = PairModes(Options, meshData, MAC, rePair); % pair modes?

%% Calculate the objective function
res = zeros(numCorrFreq,2);
res(:,1)=((St7Freq(meshData.pairedModes(:,2))-ExpFreq(meshData.pairedModes(:,1)))./ExpFreq(meshData.pairedModes(:,1)));
res(:,2)=1-meshData.pairedMAC;

objFun = sqrt(sum(vertcat(abs(res(:,1)),res(:,2)).^2));

if Options.Correlation.ConstantTotalMass
    obj = objFun;
else
    obj = vertcat(abs(res(:,1)),res(:,2));
end

% Set app data
setappdata(handles.guiMassRedistributionCheck_gui, 'Alpha', Alpha);
setappdata(handles.guiMassRedistributionCheck_gui, 'meshData', meshData);
setappdata(handles.guiMassRedistributionCheck_gui, 'MAC', MAC);
setappdata(handles.guiMassRedistributionCheck_gui, 'COMAC', COMAC);
setappdata(handles.guiMassRedistributionCheck_gui, 'obj', res);
setappdata(handles.guiMassRedistributionCheck_gui, 'objFun', objFun);

OutputFunction();
end