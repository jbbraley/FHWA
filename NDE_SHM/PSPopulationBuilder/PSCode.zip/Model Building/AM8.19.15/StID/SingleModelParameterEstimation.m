function [obj, currentValues] = SingleModelParameterEstimation(Alpha)
%% Get App Data
Parameters = getappdata(0,'Para_temp');
Options = getappdata(0,'Options');
Node = getappdata(0,'Node');
paraData = getappdata(0,'paraData');
testData = getappdata(0,'testData');
meshData = getappdata(0,'meshData');
                                                                 
%% Set Alpha Values
% set blank paraData group field to 0's
paraData(cellfun(@isempty,paraData(:,4)),4) = num2cell(0);
for i = 1:size(Alpha,1)
    paraData(find(cell2mat(paraData(:,4)) == i), 8) = {Alpha(i)};
end
paraData(cell2mat(paraData(:,4)) == 0,4) = {[]};

Parameters = ConvertParameterTable(paraData, Parameters);

if any(Parameters.Bearing.Fixed.Update)
    Parameters.Bearing.Fixed.Alpha(find(Parameters.Bearing.Fixed.Update),1) = Alpha(nonzeros(Parameters.Bearing.Fixed.Index));
end
if any(Parameters.Bearing.Expansion.Update)
    if any(Parameters.Bearing.Linked)
        Parameters.Bearing.Expansion.Alpha(find(Parameters.Bearing.Linked),1) = Alpha(nonzeros(Parameters.Bearing.Fixed.Index));
    end
    if any((Parameters.Bearing.Expansion.Update(1:end-1)-Parameters.Bearing.Linked)>0)
        Parameters.Bearing.Expansion.Alpha(find(Parameters.Bearing.Expansion.Update),1) = Alpha(nonzeros(Parameters.Bearing.Expansion.Index));
    end
end

%% Update Model
fprintf('Updating Model...');
Parameters = UpdateModelParameters(Options.St7.uID, Parameters, Node);
fprintf('Done\n');

%% Obtain Frequencies and Modeshapes from St7 Model
fprintf('Getting Modal Analysis Data...');
% Run Natural Frequency Analysis
meshData = LoadNaturalFrequencyData(Options, meshData, meshData.nodeID);
fprintf('Done\n');

%% Pair Frequencies and Mode Shapes Based on MAC
fprintf('Calculating MAC and Objective Function...');
% Get MAC and pairing
pairCoord = 0;
pairMAC = Options.Correlation.RePairModes;
meshData = NaturalFrequencyComparison(Options, meshData, testData, pairCoord, pairMAC);
fprintf('Done\n');

%% Assign/Modify/Weight Objective Function
obj = zeros(length(Options.Correlation.expModes)*2,1);
obj(1:2:end-1) = meshData.freqRes;
obj(2:2:end) = 1-meshData.pairedMAC;

% Check for frequency weighting
switch Options.Correlation.stringFreqWeight
    case 'None'

    case 'Inverse Order'
        inverse = 1./(1:length(Options.Correlation.expModes)); % take inverse of order
        freqWeight = inverse./sum(inverse); % take fraction of sum of vector
        obj(1:2:end-1) = obj(1:2:end-1).*freqWeight';
end

%% Store Data
corrValues.FreqRes = obj(1:2:end-1);
corrValues.MACRes = obj(2:2:end);
corrValues.ObjFun = sqrt(sum(obj.^2));
corrValues.pairedModes = meshData.pairedModes; %{Exp, Ana}
corrValues.pairedMAC = meshData.pairedMAC;
corrValues.MAC = meshData.MAC;
corrValues.Alpha = Alpha;
corrValues.AnaDisp = meshData.U;
corrValues.AnaFreq = meshData.freq;
corrValues.COMAC = meshData.COMAC;
setappdata(0,'corrValues',corrValues);
setappdata(0,'Para_temp',Parameters);
setappdata(0,'meshData',meshData);
setappdata(0,'paraData',paraData);
fprintf('Done\n');
end %SingleModelParameterEstimation