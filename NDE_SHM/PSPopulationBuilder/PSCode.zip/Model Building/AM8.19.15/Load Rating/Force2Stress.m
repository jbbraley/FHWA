function [ Stress ] = Force2Stress( M1, M2, AF, Argin)
try
    Stress = abs(M1/Argin.SBnc) + abs(M2/Argin.S2) + abs(AF/Argin.A);
catch
    Stress = abs(M1/Argin.Sb) + abs(M2/Argin.S2) + abs(AF/Argin.A);
end
end

