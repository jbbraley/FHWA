function [Parameters, Arg] = AASHTOLoadRating(Arg, Parameters)

switch Parameters.structureType
    case 'Steel'
        if ~isfield(Parameters.Demands.Int.SL.DeadLoad,'MDL_pos')
            Parameters.Demands.Int.SL = GetSectionForces(Parameters.Beam.Int, Parameters,'None','Int');
            Parameters.Demands.Ext.SL = GetSectionForces(Parameters.Beam.Ext, Parameters,'None','Ext');
        end
    case 'Prestressed'
        if ~isfield(Parameters.Demands, 'SL') || ~isfield(Parameters.Demands.SL,'MDL_pos')
            [Parameters, Parameters.Beam] = PSSectionForces(Parameters, Parameters.Beam);
        end
end

if strcmp(Parameters.Rating.Code, 'ASD')
    Arg.Capacity.Int.FnOp = 0.75*Parameters.Beam.Fy;
    Arg.Capacity.Ext.FnOp = 0.75*Parameters.Beam.Fy;
    Arg.Capacity.Int.FnInv = 0.55*Parameters.Beam.Fy;
    Arg.Capacity.Ext.FnInv = 0.55*Parameters.Beam.Fy;
    
    Arg.IMF = 50./(Parameters.Length/12+125)+1;
    if Arg.IM > 1.3
        Arg.IM = 1.3;
    end
    
    % Lanes Manual for Bridge Evaluation 2011 6B.6.2.2 
    if Parameters.RoadWidth >= 18*12 && Parameters.RoadWidth <= 24*12
        Arg.NumLane = 2;
        Arg.LaneWidth = Parameters.RoadWidth/2;
    elseif Parameters.RoadWidth > 24*12
        Arg.NumLane = floor(Parameters.RoadWidth/144);
        Arg.LaneWidth = 12*12;
    else
        Arg.NumLane = 1;
        Arg.LaneWidth = min([12*12 Parameters.RoadWidth]);
    end
    
elseif strcmp(Parameters.Rating.Code, 'LRFD')
    if strcmp(Parameters.structureType, 'Steel')
        % Cb Value
        if Arg.useCB
            Arg.Cb_int = GetMomentGradient(Parameters.Beam.Int,Parameters.Demands.Int.SL,Parameters);
            Arg.Cb_ext = GetMomentGradient(Parameters.Beam.Ext,Parameters.Demands.Ext.SL,Parameters);
        else
            Arg.Cb_int = 1;
            Arg.Cb_ext = 1;
        end

        % Capacity Assignment
        Arg.Capacity.Int = GetLRFDResistance(Parameters.Beam.Int, Parameters.Demands.Int.SL, Parameters, 'Int',Arg.Cb_int);
        Arg.Capacity.Ext = GetLRFDResistance(Parameters.Beam.Ext, Parameters.Demands.Ext.SL, Parameters, 'Ext',Arg.Cb_ext);

        Arg.Capacity.Int.Fy = Parameters.Beam.Fy;
        Arg.Capacity.Ext.Fy = Parameters.Beam.Fy;
    elseif strcmp(Parameters.structureType, 'Prestressed')
        [Arg.Capacity.Int, Parameters.Beam] = PSGirderCapacity(Parameters, Parameters.Beam);
        Arg.Capacity.Ext = Arg.Capacity.Int;
    end
        
    % Design Truck used for Rating
    if ~isfield(Arg, 'DesignLoad')
        Arg.DesignLoad = 'A';
    end
    % Impact Factor
    Arg.IM = 1.33;    
    
    %Multipresence factors - To be used only with Lever Rule
    Arg.MulPres(1) = 1.2;
    Arg.MulPres(2) = 1;
    Arg.MulPres(3) = 0.85;
    Arg.MulPres(4) = 0.65;
    
    % Lanes LRFD 2011 6A.2.3.2 
    if Parameters.RoadWidth >= 18*12 && Parameters.RoadWidth <= 24*12
        Arg.NumLane = 2;
        Arg.LaneWidth = Parameters.RoadWidth/2;
    elseif Parameters.RoadWidth > 24*12
        Arg.NumLane = floor(Parameters.RoadWidth/144);
        Arg.LaneWidth = 12*12;
    else
        Arg.NumLane = 1;
        Arg.LaneWidth = min([12*12 Parameters.RoadWidth]);
    end
end
% Shoulder
Arg.Shldr = (Parameters.RoadWidth - Arg.NumLane*Arg.LaneWidth)/2;

% Offset to move truck to within 2' of lane edge
Arg.LaneOffset = (Arg.LaneWidth-6*12)/2-24;
end