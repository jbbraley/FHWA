function ArgOut = GetSLGRatingFactor(ArgIn1,ArgIn2,ArgIn3, Parameters,Section)
% ArgIn1 - Beam Parameters
% ArgIn2 - Demand quantities
% ArgIn3 - Capacity quantities
% Parameters - Structure Parameters
% Section - 'Int' or 'Ext'
% Parameters.Rating.(Code).SL = GetRatingFactor(Parameters.Beam.Int,Parameters.Demands.Int, Parameters, 'Interior');
if strcmp(Parameters.Rating.Code, 'ASD')
    fIInv = 0.55*Parameters.Beam.Fy; % psi - or 0.55fy
    fIOp = 0.75*Parameters.Beam.Fy; % psi - or 0.75fy
    
    % Positive
    maxDLnc = max(ArgIn2.DeadLoad.MDL_pos)/ArgIn1.SBnc;
    
    if Parameters.Deck.CompositeDesign == 1
        maxSDL = max(ArgIn2.DeadLoad.MSDL_pos)/ArgIn1.SBlt;
        maxLL = max(max(ArgIn2.LiveLoad.MLL_pos))/ArgIn1.SBst;
    else
        maxSDLnc = max(ArgIn2.DeadLoad.MSDL_pos)/ArgIn1.SBnc;
        maxLLnc = max(ArgIn2.LiveLoad.MLL_pos)/ArgIn1.SBnc;
    end
    
    % Negative
    if Parameters.Spans > 1
        if ArgIn1.CoverPlate.Length ~= 0
            minDLnc = max(abs(ArgIn2.DeadLoad.MDL_neg))/ArgIn1.CoverPlate.STnc;
            minSDLnc = max(abs(ArgIn2.DeadLoad.MSDL_neg))/ArgIn1.CoverPlate.STnc;
            minLLnc = max(max(abs(ArgIn2.LiveLoad.MLL_neg)))/ArgIn1.CoverPlate.STnc;
        else
            minDLnc = max(abs(ArgIn2.DeadLoad.MDL_neg))/ArgIn1.STnc;
            minSDLnc = max(abs(ArgIn2.DeadLoad.MSDL_neg))/ArgIn1.STnc;
            minLLnc = max(max(abs(ArgIn2.LiveLoad.MLL_neg)))/ArgIn1.STnc;
        end
    end
    
    % Positive
    if Parameters.Deck.CompositeDesign == 1
        ArgOut.St1.Op_pos = (fIOp - maxDLnc - maxSDL)/maxLL;
        ArgOut.St1.Inv_pos = (fIInv - maxDLnc - maxSDL)/maxLL;
    else
        ArgOut.St1.Op_pos = (fIOp - maxDLnc - maxSDLnc)/maxLLnc;
        ArgOut.St1.Inv_pos = (fIInv - maxDLnc - maxSDLnc)/maxLLnc;
    end
    
    % Negative
    if Parameters.Spans > 1
        ArgOut.St1.Op_neg = (fIOp - minDLnc - minSDLnc)/minLLnc;
        ArgOut.St1.Inv_neg = (fIInv - minDLnc - minSDLnc)/minLLnc;
    else
        ArgOut.St1.Op_neg = [];
        ArgOut.St1.Inv_neg = [];
    end
    ArgOut.St1.Inv = [ArgOut.St1.Inv_pos, ArgOut.St1.Inv_neg];
    ArgOut.St1.Op = [ArgOut.St1.Op_pos, ArgOut.St1.Op_neg];
    

elseif strcmp(Parameters.Rating.Code, 'LRFD')  
    % Distribution Factor
    DF = Parameters.Design.DF.(['DF' (Section)]);
    if strcmp(Parameters.structureType, 'Steel')   
        
        % Positive
        % get contributional stresses in bottom flange
        ArgOut.ftDL_pos = max(abs(ArgIn2.DeadLoad.MDL_pos)/ArgIn1.SBnc+abs(ArgIn2.DeadLoad.MSDL_pos)/ArgIn1.SBlt);
        ArgOut.ftLL_pos = max(abs(ArgIn2.LiveLoad.MLL_pos)*max(DF))/ArgIn1.SBst;
        %Strength Limit State I
        ArgOut.St1.RFOp_pos = min((ArgIn3.Mn_pos-1.25*(ArgIn2.DeadLoad.MDL_pos+ArgIn2.DeadLoad.MSDL_pos))./(1.35*ArgIn2.LiveLoad.MLL_pos*max(DF)));
        ArgOut.St1.RFInv_pos = min((ArgIn3.Mn_pos-1.25*(ArgIn2.DeadLoad.MDL_pos+ArgIn2.DeadLoad.MSDL_pos))./(1.75*ArgIn2.LiveLoad.MLL_pos*max(DF)));
        %Service Limit State II
        ArgOut.Sv2.RFOp_pos = (0.95*ArgIn3.Fn_pos-1*(ArgOut.ftDL_pos))/(1.0*ArgOut.ftLL_pos);
        ArgOut.Sv2.RFInv_pos = (0.95*ArgIn3.Fn_pos-1*(ArgOut.ftDL_pos))/(1.3*ArgOut.ftLL_pos);

        % Negative
        if Parameters.Spans > 1
            if ArgIn1.CoverPlate.Length > 0
                % get contributional stresses in bottom flange
                ArgOut.fcDL_neg = max(abs(ArgIn2.DeadLoad.MDL_neg)/ArgIn1.CoverPlate.SBnc+abs(ArgIn2.DeadLoad.MSDL_neg)/ArgIn1.CoverPlate.SBnc);
                ArgOut.fcLL_neg = max(abs(ArgIn2.LiveLoad.MLL_neg*max(DF)))/ArgIn1.CoverPlate.SBnc;
                %Strength Limit State I
                ArgOut.St1.RFOp_neg = (ArgIn3.Fn_neg-1.25*max(abs(ArgOut.fcDL_neg)))/(1.35*max(abs(ArgOut.fcLL_neg)));
                ArgOut.St1.RFInv_neg = (ArgIn3.Fn_neg-1.25*max(abs(ArgOut.fcDL_neg)))/(1.75*max(abs(ArgOut.fcLL_neg)));
                %Service Limit State II
                ArgOut.Sv2.RFOp_neg = (0.95*ArgIn3.Fn_neg-1*ArgOut.fcDL_neg)/(1.0*ArgOut.fcLL_neg);
                ArgOut.Sv2.RFInv_neg = (0.95*ArgIn3.Fn_neg-1*ArgOut.fcDL_neg)/(1.3*ArgOut.fcLL_neg);
            else
                % get contributional stresses in bottom flange
                ArgOut.fcDL_neg = max(abs(ArgIn2.DeadLoad.MDL_neg)/ArgIn1.SBnc+abs(ArgIn2.DeadLoad.MSDL_neg)/ArgIn1.SBnc);
                ArgOut.fcLL_neg = max(abs(ArgIn2.LiveLoad.MLL_neg*max(DF)))/ArgIn1.SBnc;
                %Strength Limit State I
                ArgOut.St1.RFOp_neg = (ArgIn3.Fn_neg-1.25*max(abs(ArgOut.fcDL_neg)))/(1.35*max(abs(ArgOut.fcLL_neg)));
                ArgOut.St1.RFInv_neg = (ArgIn3.Fn_neg-1.25*max(abs(ArgOut.fcDL_neg)))/(1.75*max(abs(ArgOut.fcLL_neg)));
                %Service Limit State II
                ArgOut.Sv2.RFOp_neg = (0.95*ArgIn3.Fn_neg-1*ArgOut.fcDL_neg)/(1.0*ArgOut.fcLL_neg);
                ArgOut.Sv2.RFInv_neg = (0.95*ArgIn3.Fn_neg-1*ArgOut.fcDL_neg)/(1.3*ArgOut.fcLL_neg);
            end
        else
            ArgOut.St1.RFOp_neg = [];
            ArgOut.St1.RFInv_neg = [];
            ArgOut.Sv2.RFOp_neg = [];
            ArgOut.Sv2.RFInv_neg = [];
        end
        
        %Single Line rating facotrs [Inv_pos, Op_pos, Inv_neg, Op_neg]
        ArgOut.St1.Inv = [ArgOut.St1.RFInv_pos, ArgOut.St1.RFInv_neg];
        ArgOut.St1.Op = [ArgOut.St1.RFOp_pos, ArgOut.St1.RFOp_neg];
        ArgOut.Sv2.Inv = [ArgOut.Sv2.RFInv_pos,ArgOut.Sv2.RFInv_neg];
        ArgOut.Sv2.Op = [ArgOut.Sv2.RFOp_pos, ArgOut.Sv2.RFOp_neg];
        
    elseif strcmp(Parameters.structureType, 'Prestressed')
            
        % Positive
        % get contributional stresses in bottom flange
        ArgOut.ftDL_pos = max(abs(ArgIn2.MDL_pos)/ArgIn1.Sb+max(abs(ArgIn2.MSDL_pos))./(ArgIn1.SBlt')+max(abs(ArgIn2.MDW_pos))./(ArgIn1.SBlt'));
        ArgOut.ftLL_pos = max(max(abs(ArgIn2.MLL_pos))*max(DF)./ArgIn1.SBst');
        
       % Positive 
       % Strength Limit State 1
       ArgOut.St1.RFInv_pos = min((ArgIn3.Mn_pos-1.25*(ArgIn2.MDL_pos+max(ArgIn2.MSDL_pos))-1.5*ArgIn2.MDW_pos)./(1.75*ArgIn2.MLL_pos*max(DF)));
       ArgOut.St1.RFOp_pos = min((ArgIn3.Mn_pos-1.25*(ArgIn2.MDL_pos+max(ArgIn2.MSDL_pos))-1.5*ArgIn2.MDW_pos)./(1.35*ArgIn2.MLL_pos*max(DF)));
       
       % Service III Limit State
       ArgOut.Sv3.RFInv_pos = min((ArgIn3.Fn_pos - ArgOut.ftDL_pos)/(0.8*ArgOut.ftLL_pos));
       
       % Negative
       if Parameters.Spans > 1
           ArgOut.St1.RFInv_neg = min((ArgIn3.Mn_neg-1.25*abs(ArgIn2.MDL_neg+min(ArgIn2.MSDL_neg))-1.5*abs(ArgIn2.MDW_neg))./(1.75*abs(ArgIn2.MLL_neg)*max(DF)));
           ArgOut.St1.RFOp_neg = min((ArgIn3.Mn_neg-1.25*abs(ArgIn2.MDL_neg+min(ArgIn2.MSDL_neg))-1.5*abs(ArgIn2.MDW_neg))./(1.35*abs(ArgIn2.MLL_neg)*max(DF)));
       else
           ArgOut.St1.RFInv_neg = [];
           ArgOut.St1.RFOp_neg = [];
       end
       
       %Single Line rating factors [Inv_pos, Op_pos, Inv_neg, Op_neg]
       ArgOut.St1.Inv = [ArgOut.St1.RFInv_pos, ArgOut.St1.RFInv_neg];
       ArgOut.St1.Op = [ArgOut.St1.RFOp_pos, ArgOut.St1.RFOp_neg];
       ArgOut.Sv3.Inv = ArgOut.Sv3.RFInv_pos;
       
    end 
end

    
end